<?php

namespace Drupal\easyemail\Controller;

use Drupal\Core\Access\CsrfTokenGenerator;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Drupal\Core\Datetime\DateFormatterInterface;
use Drupal\Core\Url;
use Drupal\easyemail\Service\OperationQueue;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Controller for sync error management.
 */
class SyncErrorController extends ControllerBase {

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * The operation queue service.
   *
   * @var \Drupal\easyemail\Service\OperationQueue
   */
  protected $operationQueue;

  /**
   * The date formatter service.
   *
   * @var \Drupal\Core\Datetime\DateFormatterInterface
   */
  protected $dateFormatter;

  /**
   * The CSRF token generator.
   *
   * @var \Drupal\Core\Access\CsrfTokenGenerator
   */
  protected $csrfToken;

  /**
   * Constructs a SyncErrorController object.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   * @param \Drupal\easyemail\Service\OperationQueue $operation_queue
   *   The operation queue service.
   * @param \Drupal\Core\Datetime\DateFormatterInterface $date_formatter
   *   The date formatter service.
   * @param \Drupal\Core\Access\CsrfTokenGenerator $csrf_token
   *   The CSRF token generator.
   */
  public function __construct(Connection $database, OperationQueue $operation_queue, DateFormatterInterface $date_formatter, CsrfTokenGenerator $csrf_token) {
    $this->database = $database;
    $this->operationQueue = $operation_queue;
    $this->dateFormatter = $date_formatter;
    $this->csrfToken = $csrf_token;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('database'),
      $container->get('easyemail.operation_queue'),
      $container->get('date.formatter'),
      $container->get('csrf_token')
    );
  }

  /**
   * Build a CSRF-protected URL for a state-changing action route.
   *
   * @param string $route_name
   *   The route name.
   * @param array $route_parameters
   *   Route parameters.
   *
   * @return \Drupal\Core\Url
   *   URL with ?token= query parameter attached.
   */
  protected function csrfUrl(string $route_name, array $route_parameters = []): Url {
    $url = Url::fromRoute($route_name, $route_parameters);
    $token = $this->csrfToken->get($url->getInternalPath());
    $url->setOption('query', ['token' => $token]);
    return $url;
  }

  /**
   * List all sync errors from queue.
   */
  public function listErrors() {
    $stats = $this->operationQueue->getStats();

    $build = [];

    $build['stats'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['queue-stats']],
    ];

    $build['stats']['summary'] = [
      '#markup' => '<div class="queue-summary"><strong>' . $this->t('Queue Statistics') . '</strong><br>' .
      $this->t('Total: @total', ['@total' => $stats['total']]) . ' | ' .
      $this->t('Pending: @pending', ['@pending' => $stats['pending']]) . ' | ' .
      $this->t('Completed: @completed', ['@completed' => $stats['completed']]) . ' | ' .
      $this->t('Failed: @failed', ['@failed' => $stats['failed']]) .
      '</div>',
    ];

    $query = $this->database->select('easyemail_queue', 'q')
      ->fields('q')
      ->condition('status', [
        OperationQueue::STATUS_FAILED_CONNECTION,
        OperationQueue::STATUS_FAILED_ERROR,
      ], 'IN')
      ->orderBy('created', 'DESC')
      ->range(0, 100);

    $errors = $query->execute()->fetchAll();

    $rows = [];
    foreach ($errors as $error) {
      $arguments = unserialize($error->arguments, ['allowed_classes' => FALSE]);
      $arguments_display = $this->formatArguments($arguments);

      $rows[] = [
        'id' => $error->id,
        'method' => ['data' => ['#plain_text' => $error->method]],
        'entity_id' => $error->entityId,
        'arguments' => ['data' => ['#plain_text' => $arguments_display]],
        'attempts' => $error->attempts,
        'error' => ['data' => ['#plain_text' => $error->error_message ?: (string) $this->t('Unknown error')]],
        'created' => $this->dateFormatter->format($error->created, 'short'),
        'operations' => [
          'data' => [
            '#type' => 'operations',
            '#links' => [
              'view' => [
                'title' => $this->t('View'),
                'url' => Url::fromRoute('easyemail.syncerror.view', ['id' => $error->id]),
              ],
              'retry' => [
                'title' => $this->t('Retry'),
                'url' => $this->csrfUrl('easyemail.syncerror.retry', ['id' => $error->id]),
              ],
              'delete' => [
                'title' => $this->t('Delete'),
                'url' => $this->csrfUrl('easyemail.syncerror.delete', ['id' => $error->id]),
              ],
            ],
          ],
        ],
      ];
    }

    $build['table'] = [
      '#type' => 'table',
      '#header' => [
        $this->t('ID'),
        $this->t('Method'),
        $this->t('Entity ID'),
        $this->t('Arguments'),
        $this->t('Attempts'),
        $this->t('Error'),
        $this->t('Created'),
        $this->t('Operations'),
      ],
      '#rows' => $rows,
      '#empty' => $this->t('No failed operations found.'),
    ];

    $build['#attached']['library'][] = 'easyemail/admin';

    return $build;
  }

  /**
   * View individual error details.
   */
  public function viewError($id) {
    $error = $this->database->select('easyemail_queue', 'q')
      ->fields('q')
      ->condition('id', $id)
      ->execute()
      ->fetchAssoc();

    if (!$error) {
      $this->messenger()->addError($this->t('Error not found.'));
      return new RedirectResponse(Url::fromRoute('easyemail.syncerrors')->toString());
    }

    $arguments = unserialize($error['arguments'], ['allowed_classes' => FALSE]);
    $response = unserialize($error['response'], ['allowed_classes' => FALSE]);

    $build = [];

    $build['details'] = [
      '#type' => 'details',
      '#title' => $this->t('Operation Details'),
      '#open' => TRUE,
    ];

    $build['details']['table'] = [
      '#type' => 'table',
      '#rows' => [
        [$this->t('Queue ID'), $error['id']],
        [$this->t('Method'), $error['method']],
        [$this->t('Entity ID'), $error['entityId']],
        [$this->t('Status'), $this->getStatusLabel($error['status'])],
        [$this->t('Attempts'), $error['attempts']],
        [
          $this->t('Created'),
          $this->dateFormatter->format($error['created'], 'long'),
        ],
        [
          $this->t('Processed'),
          $error['processed'] ? $this->dateFormatter->format($error['processed'], 'long') : $this->t('Never'),
        ],
      ],
    ];

    $build['arguments'] = [
      '#type' => 'details',
      '#title' => $this->t('Arguments'),
      '#open' => TRUE,
    ];

    $build['arguments']['content'] = [
      '#markup' => '<pre>' . htmlspecialchars(print_r($arguments, TRUE), ENT_QUOTES, 'UTF-8') . '</pre>',
    ];

    if (!empty($error['error_message'])) {
      $build['error'] = [
        '#type' => 'details',
        '#title' => $this->t('Error Message'),
        '#open' => TRUE,
      ];

      $build['error']['content'] = [
        '#markup' => '<div class="messages messages--error">' . htmlspecialchars($error['error_message'], ENT_QUOTES, 'UTF-8') . '</div>',
      ];
    }

    if ($response) {
      $build['response'] = [
        '#type' => 'details',
        '#title' => $this->t('Response'),
        '#open' => FALSE,
      ];

      $build['response']['content'] = [
        '#markup' => '<pre>' . htmlspecialchars(print_r($response, TRUE), ENT_QUOTES, 'UTF-8') . '</pre>',
      ];
    }

    $build['actions'] = [
      '#type' => 'actions',
    ];

    $build['actions']['retry'] = [
      '#type' => 'link',
      '#title' => $this->t('Retry Operation'),
      '#url' => $this->csrfUrl('easyemail.syncerror.retry', ['id' => $id]),
      '#attributes' => ['class' => ['button', 'button--primary']],
    ];

    $build['actions']['delete'] = [
      '#type' => 'link',
      '#title' => $this->t('Delete'),
      '#url' => $this->csrfUrl('easyemail.syncerror.delete', ['id' => $id]),
      '#attributes' => ['class' => ['button', 'button--danger']],
    ];

    $build['actions']['back'] = [
      '#type' => 'link',
      '#title' => $this->t('Back to list'),
      '#url' => Url::fromRoute('easyemail.syncerrors'),
      '#attributes' => ['class' => ['button']],
    ];

    return $build;
  }

  /**
   * Retry a failed operation.
   */
  public function retryError($id) {
    // Reset the operation to new status.
    $this->database->update('easyemail_queue')
      ->fields([
        'status' => OperationQueue::STATUS_NEW,
        'attempts' => 0,
        'error_message' => '',
      ])
      ->condition('id', $id)
      ->execute();

    $this->messenger()->addStatus($this->t('Operation reset to pending. It will be retried during the next cron run.'));

    return new RedirectResponse(Url::fromRoute('easyemail.syncerrors')->toString());
  }

  /**
   * Delete a failed operation.
   */
  public function deleteError($id) {
    $this->database->delete('easyemail_queue')
      ->condition('id', $id)
      ->execute();

    $this->messenger()->addStatus($this->t('Operation deleted.'));

    return new RedirectResponse(Url::fromRoute('easyemail.syncerrors')->toString());
  }

  /**
   * Get human-readable status label.
   */
  protected function getStatusLabel($status) {
    $labels = [
      OperationQueue::STATUS_NEW => $this->t('Pending'),
      OperationQueue::STATUS_PROCESSED => $this->t('Processed'),
      OperationQueue::STATUS_FAILED_CONNECTION => $this->t('Failed (Connection)'),
      OperationQueue::STATUS_FAILED_ERROR => $this->t('Failed (API Error)'),
      OperationQueue::STATUS_ERROR_RESOLVED => $this->t('Error Resolved'),
    ];

    return $labels[$status] ?? $this->t('Unknown');
  }

  /**
   * Format arguments for display in table.
   *
   * @param mixed $arguments
   *   The arguments to format.
   *
   * @return string
   *   Formatted string representation of arguments.
   */
  protected function formatArguments($arguments) {
    if (empty($arguments)) {
      return '';
    }

    if (is_array($arguments)) {
      // Convert array to JSON for compact display.
      $json = json_encode($arguments, JSON_UNESCAPED_UNICODE);
      // Truncate if too long.
      if (strlen($json) > 100) {
        return substr($json, 0, 97) . '...';
      }
      return $json;
    }

    if (is_object($arguments)) {
      return get_class($arguments);
    }

    return (string) $arguments;
  }

}
