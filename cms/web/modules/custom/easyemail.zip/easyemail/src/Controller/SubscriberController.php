<?php

namespace Drupal\easyemail\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Drupal\Core\Url;
use Drupal\easyemail\Entity\SubscriberInterface;
use Drupal\easyemail\Service\OperationQueue;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Controller for subscriber management.
 */
class SubscriberController extends ControllerBase {

  /**
   * The operation queue service.
   *
   * @var \Drupal\easyemail\Service\OperationQueue
   */
  protected $operationQueue;

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * Constructs a SubscriberController object.
   *
   * @param \Drupal\easyemail\Service\OperationQueue $operation_queue
   *   The operation queue service.
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   */
  public function __construct(OperationQueue $operation_queue, Connection $database) {
    $this->operationQueue = $operation_queue;
    $this->database = $database;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('easyemail.operation_queue'),
      $container->get('database')
    );
  }

  /**
   * Force synchronization of a single subscriber.
   */
  public function sync(SubscriberInterface $easyemail_subscriber) {
    $subscriptions = $easyemail_subscriber->get('subscriptions');
    $count = 0;

    if (!$subscriptions->isEmpty()) {
      $tids = [];
      foreach ($subscriptions as $item) {
        if ($item->entity) {
          $tids[] = $item->entity->id();
        }
      }

      if (!empty($tids)) {
        $result = $this->database->select('easyemail_mailinglists', 'm')
          ->fields('m', ['tid', 'mailinglist_id'])
          ->condition('tid', $tids, 'IN')
          ->condition('state', 1)
          ->execute();

        foreach ($result as $row) {
          if (!empty($row->mailinglist_id)) {
            $this->operationQueue->dispatch('subscribe', $row->tid, [
              $row->mailinglist_id,
              $easyemail_subscriber->getEmail(),
            ]);
            $count++;
          }
        }
      }
    }

    $easyemail_subscriber->set('sync_state', 'pending');
    $easyemail_subscriber->save();

    if ($count > 0) {
      $this->messenger()->addStatus($this->operationQueue->isInstant()
        ? $this->t('Synced @count subscription(s) for @email.', [
          '@count' => $count,
          '@email' => $easyemail_subscriber->getEmail(),
        ])
        : $this->t('Queued @count subscription(s) for @email. They will be processed during cron.', [
          '@count' => $count,
          '@email' => $easyemail_subscriber->getEmail(),
        ])
      );
    }
    else {
      $this->messenger()->addWarning($this->t('No subscriptions to sync for @email.', [
        '@email' => $easyemail_subscriber->getEmail(),
      ]));
    }

    return new RedirectResponse(Url::fromRoute('entity.easyemail_subscriber.collection')->toString());
  }

  /**
   * Synchronize all subscribers with remote service.
   */
  public function syncAll() {
    $storage = $this->entityTypeManager()->getStorage('easyemail_subscriber');
    $queued = 0;

    // Pre-fetch all Peytz remote IDs for synced mailing lists.
    $peytz_ids = [];
    $result = $this->database->select('easyemail_mailinglists', 'm')
      ->fields('m', ['tid', 'mailinglist_id'])
      ->condition('state', 1)
      ->execute();

    foreach ($result as $row) {
      if (!empty($row->mailinglist_id)) {
        $peytz_ids[$row->tid] = $row->mailinglist_id;
      }
    }

    // Process active subscribers in batches of 50 to avoid memory exhaustion.
    $batch_size = 50;
    $offset = 0;

    do {
      $ids = $storage->getQuery()
        ->accessCheck(FALSE)
        ->condition('status', 1)
        ->range($offset, $batch_size)
        ->execute();

      if (empty($ids)) {
        break;
      }

      /** @var \Drupal\easyemail\Entity\SubscriberInterface[] $subscribers */
      $subscribers = $storage->loadMultiple($ids);

      foreach ($subscribers as $subscriber) {
        $subscriptions = $subscriber->get('subscriptions');

        if ($subscriptions->isEmpty()) {
          continue;
        }

        $has_queued = FALSE;
        foreach ($subscriptions as $item) {
          if ($item->entity) {
            $mailinglist_tid = $item->entity->id();

            if (isset($peytz_ids[$mailinglist_tid])) {
              $this->operationQueue->put(
                'subscribe',
                $mailinglist_tid,
                [$peytz_ids[$mailinglist_tid], $subscriber->getEmail()]
              );
              $queued++;
              $has_queued = TRUE;
            }
          }
        }

        if ($has_queued) {
          $subscriber->set('sync_state', 'pending');
          $subscriber->save();
        }
      }

      $offset += $batch_size;

      // Free memory before next batch.
      $storage->resetCache(array_keys($subscribers));
    } while (count($ids) === $batch_size);

    if ($queued > 0) {
      $this->messenger()->addStatus($this->t('Queued @count subscription operations for all active subscribers. They will be processed during cron.', [
        '@count' => $queued,
      ]));
    }
    else {
      $this->messenger()->addWarning($this->t('No active subscribers with subscriptions to sync.'));
    }

    return new RedirectResponse(Url::fromRoute('entity.easyemail_subscriber.collection')->toString());
  }

}
