<?php

namespace Drupal\easyemail\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Datetime\DateFormatterInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Url;

/**
 * Controller for mailing list management.
 */
class MailinglistController extends ControllerBase {

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The date formatter service.
   *
   * @var \Drupal\Core\Datetime\DateFormatterInterface
   */
  protected $dateFormatter;

  /**
   * Constructs a MailinglistController object.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Datetime\DateFormatterInterface $date_formatter
   *   The date formatter service.
   */
  public function __construct(Connection $database, EntityTypeManagerInterface $entity_type_manager, DateFormatterInterface $date_formatter) {
    $this->database = $database;
    $this->entityTypeManager = $entity_type_manager;
    $this->dateFormatter = $date_formatter;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('database'),
      $container->get('entity_type.manager'),
      $container->get('date.formatter')
    );
  }

  /**
   * Overview page for mailing lists.
   */
  public function overview() {
    // Load all mailing list taxonomy terms.
    $term_storage = $this->entityTypeManager->getStorage('taxonomy_term');
    $terms = $term_storage->loadByProperties(['vid' => 'mailinglist']);

    if (empty($terms)) {
      return [
        '#markup' => $this->t('No mailing lists found. <a href="@url">Add a mailing list</a>.', [
          '@url' => Url::fromRoute('easyemail.mailinglist.add')->toString(),
        ]),
      ];
    }

    $tids = array_keys($terms);

    // Load all metadata in one query instead of per-term.
    $metadata_map = $this->database->select('easyemail_mailinglists', 'm')
      ->fields('m')
      ->condition('tid', $tids, 'IN')
      ->execute()
      ->fetchAllAssoc('tid', \PDO::FETCH_ASSOC);

    // Count active subscribers per mailing list in one GROUP BY query.
    // Note: join() returns the alias string, not the query — do not chain it.
    $subscriber_counts = [];
    if (!empty($tids)) {
      $count_query = $this->database->select('easyemail_subscriber__subscriptions', 's');
      $count_query->join('easyemail_subscriber', 'sub', 's.entity_id = sub.id AND sub.status = 1');
      $count_query->fields('s', ['subscriptions_target_id']);
      $count_query->addExpression('COUNT(DISTINCT s.entity_id)', 'cnt');
      $count_query->condition('s.subscriptions_target_id', $tids, 'IN');
      $count_query->groupBy('s.subscriptions_target_id');
      foreach ($count_query->execute() as $row) {
        $subscriber_counts[$row->subscriptions_target_id] = (int) $row->cnt;
      }
    }

    // Build table rows.
    $rows = [];
    foreach ($terms as $term) {
      $tid = $term->id();
      $metadata = $metadata_map[$tid] ?? [];

      $mailinglist_id = $metadata['mailinglist_id'] ?? '';
      $state = $metadata['state'] ?? 0;
      $changed = $metadata['changed'] ?? 0;
      $subscriber_count = $subscriber_counts[$tid] ?? 0;

      $rows[] = [
        'name' => [
          'data' => [
            '#type' => 'link',
            '#title' => $term->label(),
            '#url' => Url::fromRoute('entity.taxonomy_term.edit_form', ['taxonomy_term' => $term->id()]),
          ],
        ],
        'tid' => $term->id(),
        'remote_id' => $mailinglist_id ?: $this->t('Not synced'),
        'state' => $state ? $this->t('✓ Synced') : $this->t('⏳ Pending'),
        'subscribers' => $subscriber_count,
        'changed' => $changed ? $this->dateFormatter->format($changed, 'short') : $this->t('Never'),
        'operations' => [
          'data' => [
            '#type' => 'operations',
            '#links' => [
              'edit' => [
                'title' => $this->t('Edit'),
                'url' => Url::fromRoute('entity.taxonomy_term.edit_form', ['taxonomy_term' => $term->id()]),
              ],
              'delete' => [
                'title' => $this->t('Delete'),
                'url' => Url::fromRoute('entity.taxonomy_term.delete_form', ['taxonomy_term' => $term->id()]),
              ],
            ],
          ],
        ],
      ];
    }

    $build = [];

    $build['info'] = [
      '#markup' => '<p>' . $this->t('Mailing lists are synchronized with the configured mailer provider. Changes are queued and processed during cron runs.') . '</p>',
    ];

    $build['table'] = [
      '#type' => 'table',
      '#header' => [
        $this->t('Name'),
        $this->t('Term ID'),
        $this->t('Remote ID'),
        $this->t('Status'),
        $this->t('Subscribers'),
        $this->t('Last Changed'),
        $this->t('Operations'),
      ],
      '#rows' => $rows,
      '#empty' => $this->t('No mailing lists found.'),
    ];

    return $build;
  }

  /**
   * Redirect to taxonomy term add form.
   */
  public function add() {
    // Redirect to taxonomy term add form for mailinglist vocabulary.
    return new RedirectResponse(Url::fromRoute('entity.taxonomy_term.add_form', ['taxonomy_vocabulary' => 'mailinglist'])->toString());
  }

}
