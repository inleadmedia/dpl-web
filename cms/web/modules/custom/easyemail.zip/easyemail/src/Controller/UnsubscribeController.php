<?php

namespace Drupal\easyemail\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\easyemail\Service\OperationQueue;
use Symfony\Component\HttpFoundation\Request;

/**
 * Controller for public unsubscribe functionality.
 */
class UnsubscribeController extends ControllerBase {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The operation queue service.
   *
   * @var \Drupal\easyemail\Service\OperationQueue
   */
  protected $operationQueue;

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * Constructs an UnsubscribeController object.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param \Drupal\easyemail\Service\OperationQueue $operation_queue
   *   The operation queue service.
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager, ConfigFactoryInterface $config_factory, OperationQueue $operation_queue, Connection $database) {
    $this->entityTypeManager = $entity_type_manager;
    $this->configFactory = $config_factory;
    $this->operationQueue = $operation_queue;
    $this->database = $database;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager'),
      $container->get('config.factory'),
      $container->get('easyemail.operation_queue'),
      $container->get('database')
    );
  }

  /**
   * Unsubscribe user from mailing list.
   *
   * URL format: /easyemail/unsubscribe?email=...&mailinglist_id=...&cs=...
   *
   * Peytz replaces {{unsubscribe_url}} in the newsletter with this URL,
   * substituting {{subscriber.email}}, {{mailinglist.id}}, and a
   * {{checksum}} it generates from the configured unsubscribe_checksum_secret.
   *
   * Checksum formula (verified against live Peytz tokens):
   *   sha256(email + mailinglist_id + shared_secret)
   * Values are concatenated as plain strings without URL-encoding.
   */
  public function unsubscribe(Request $request) {
    $build = [];

    $email = $request->query->get('email');
    $peytz_mailinglist_id = $request->query->get('mailinglist_id');
    $checksum = $request->query->get('cs');

    // Validate required parameters.
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)
      || empty($peytz_mailinglist_id)
      || empty($checksum)) {
      $build['error'] = [
        '#markup' => '<div class="messages messages--error">' .
        $this->t('Incorrect unsubscription data is provided.') .
        '</div>',
      ];
      return $build;
    }

    // Verify the Peytz-generated checksum.
    if (!$this->verifyChecksum($email, $peytz_mailinglist_id, $checksum)) {
      $build['error'] = [
        '#markup' => '<div class="messages messages--error">' .
        $this->t('Invalid unsubscribe link. Please contact us if you need help.') .
        '</div>',
      ];
      return $build;
    }

    // Look up Drupal term ID from Peytz mailing list ID.
    $mailinglist_tid = $this->database
      ->select('easyemail_mailinglists', 'q')
      ->fields('q', ['tid'])
      ->condition('mailinglist_id', $peytz_mailinglist_id)
      ->execute()
      ->fetchField();

    if (!$mailinglist_tid) {
      $build['error'] = [
        '#markup' => '<div class="messages messages--error">' .
        $this->t('Mailing list not found.') .
        '</div>',
      ];
      return $build;
    }

    // Load mailing list term.
    $term_storage = $this->entityTypeManager->getStorage('taxonomy_term');
    $mailinglist = $term_storage->load($mailinglist_tid);

    if (!$mailinglist || $mailinglist->bundle() !== 'mailinglist') {
      $build['error'] = [
        '#markup' => '<div class="messages messages--error">' .
        $this->t('Mailing list not found.') .
        '</div>',
      ];
      return $build;
    }

    // Load subscriber.
    $subscriber_storage = $this->entityTypeManager->getStorage('easyemail_subscriber');
    $subscribers = $subscriber_storage->loadByProperties(['email' => $email]);
    $subscriber = reset($subscribers);

    if ($subscriber) {
      // Remove this mailing list from subscriptions.
      $current_subscriptions = [];
      foreach ($subscriber->get('subscriptions') as $item) {
        if ($item->target_id != $mailinglist_tid) {
          $current_subscriptions[] = ['target_id' => $item->target_id];
        }
      }

      $subscriber->set('subscriptions', $current_subscriptions);
      $subscriber->set('sync_state', 'pending');
      // Saving triggers easyemail_easyemail_subscriber_update, which detects
      // the removed subscription and queues/runs the remote unsubscribe call.
      $subscriber->save();

      $build['success'] = [
        '#markup' => '<div class="messages messages--status">' .
        $this->t('You have been successfully unsubscribed from the mailing list "@list".', [
          '@list' => $mailinglist->label(),
        ]) .
        '</div>',
      ];

      $build['info'] = [
        '#markup' => '<p>' . $this->t('Your email address: @email', ['@email' => $email]) . '</p>',
      ];
    }
    else {
      // Subscriber not found locally — still unsubscribe on remote.
      $this->operationQueue->dispatch('unsubscribe', $mailinglist_tid, [
        $peytz_mailinglist_id,
        $email,
      ]);

      $build['success'] = [
        '#markup' => '<div class="messages messages--status">' .
        $this->t('Unsubscribe request processed for mailing list "@list".', [
          '@list' => $mailinglist->label(),
        ]) .
        '</div>',
      ];
    }

    // Show remaining subscriptions if any.
    if ($subscriber && !$subscriber->get('subscriptions')->isEmpty()) {
      $remaining = [];
      foreach ($subscriber->get('subscriptions') as $item) {
        if ($item->entity) {
          $remaining[] = $item->entity->label();
        }
      }

      if (!empty($remaining)) {
        $build['remaining'] = [
          '#markup' => '<p>' .
          $this->t('You are still subscribed to: @lists', [
            '@lists' => implode(', ', $remaining),
          ]) .
          '</p>',
        ];
      }
    }

    $build['#attached']['library'][] = 'easyemail/newsletter';

    return $build;
  }

  /**
   * Handle legacy D7 path-segment unsubscribe URLs.
   *
   * Format: /easyemail/unsubscribe/{email}/{mailinglist_id}?cs={checksum}
   *
   * Normalises the path arguments into query parameters and delegates to the
   * main unsubscribe() method so both URL formats share identical logic.
   *
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   The current request.
   * @param string $email
   *   Subscriber email from the URL path (URL-decoded by Symfony router).
   * @param string $mailinglist_id
   *   Peytz mailing list ID from the URL path.
   *
   * @return array
   *   Render array.
   */
  public function unsubscribeLegacy(Request $request, string $email, string $mailinglist_id) {
    $request->query->set('email', $email);
    $request->query->set('mailinglist_id', $mailinglist_id);
    return $this->unsubscribe($request);
  }

  /**
   * Verify a Peytz-generated checksum for an unsubscribe request.
   *
   * Peytz formula (reverse-engineered from live tokens):
   *   sha256(email + mailinglist_id + shared_secret)
   *
   * Values are concatenated as-is (no URL-encoding). The D7 module called
   * rawurlencode() but never checked the return value of the verify function,
   * so that code was effectively dead — Peytz does not URL-encode the values.
   *
   * @param string $email
   *   Subscriber email (decoded).
   * @param string $mailinglist_id
   *   Peytz mailing list ID.
   * @param string $checksum
   *   Checksum provided by Peytz.
   *
   * @return bool
   *   TRUE when the checksum is valid.
   */
  protected function verifyChecksum(string $email, string $mailinglist_id, string $checksum): bool {
    $shared_secret = $this->configFactory
      ->get('easyemail.settings')
      ->get('shared_secret');

    if (empty($shared_secret)) {
      return FALSE;
    }

    $expected = hash('sha256', $email . $mailinglist_id . $shared_secret);

    return hash_equals($expected, $checksum);
  }

}
