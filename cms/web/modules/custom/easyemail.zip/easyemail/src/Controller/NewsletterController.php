<?php

namespace Drupal\easyemail\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Drupal\easyemail\Entity\NewsletterInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\easyemail\Service\OperationQueue;
use Drupal\easyemail\Service\NewsletterBuilder;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\Core\Url;
use Drupal\Component\Render\FormattableMarkup;

/**
 * Controller for newsletter management.
 */
class NewsletterController extends ControllerBase {

  /**
   * The operation queue service.
   *
   * @var \Drupal\easyemail\Service\OperationQueue
   */
  protected $operationQueue;

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * The newsletter builder service.
   *
   * @var \Drupal\easyemail\Service\NewsletterBuilder
   */
  protected $newsletterBuilder;

  /**
   * Constructs a NewsletterController object.
   *
   * @param \Drupal\easyemail\Service\OperationQueue $operation_queue
   *   The operation queue service.
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   * @param \Drupal\easyemail\Service\NewsletterBuilder $newsletter_builder
   *   The newsletter builder service.
   */
  public function __construct(OperationQueue $operation_queue, Connection $database, NewsletterBuilder $newsletter_builder) {
    $this->operationQueue = $operation_queue;
    $this->database = $database;
    $this->newsletterBuilder = $newsletter_builder;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('easyemail.operation_queue'),
      $container->get('database'),
      $container->get('easyemail.newsletter_builder')
    );
  }

  /**
   * Preview newsletter in modal (with admin UI).
   */
  public function preview(NewsletterInterface $easyemail_newsletter) {
    $build = [];

    $build['back'] = [
      '#type' => 'link',
      '#title' => $this->t('Back to newsletters'),
      '#url' => Url::fromRoute('entity.easyemail_newsletter.collection'),
      '#attributes' => [
        'class' => ['button', 'easyemail-preview__back'],
      ],
    ];

    $build['info'] = [
      '#markup' => '<div class="messages messages--status">' . $this->t('This is a preview of how the newsletter will appear. The actual email may vary slightly depending on the email client.') . '</div>',
    ];

    $html = $this->buildNewsletterHtml($easyemail_newsletter);

    $build['preview'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['easyemail-preview']],
    ];

    $build['preview']['content'] = [
      '#markup' => new FormattableMarkup($html, []),
    ];

    $build['#attached']['library'][] = 'easyemail/newsletter';

    return $build;
  }

  /**
   * Preview newsletter in clean view (for email rendering, no admin UI).
   */
  public function previewClean(NewsletterInterface $easyemail_newsletter) {
    $view_builder = $this->entityTypeManager()->getViewBuilder('easyemail_newsletter');
    $build = $view_builder->view($easyemail_newsletter, 'full');

    $build['#attached']['library'][] = 'easyemail/newsletter';

    $build['#attached']['html_head'][] = [
      [
        '#tag' => 'meta',
        '#attributes' => [
          'name' => 'robots',
          'content' => 'noindex,nofollow',
        ],
      ],
      'newsletter_noindex',
    ];

    return $build;
  }

  /**
   * Test newsletter by sending to test email.
   */
  public function test(NewsletterInterface $easyemail_newsletter) {
    $state = $easyemail_newsletter->getState();

    if (!easyemail_action_allowed('test', $state)) {
      $this->messenger()->addError($this->t('Cannot test newsletter in state "@state". Test is only allowed for draft, test_failed, or failed newsletters.', [
        '@state' => $state,
      ]));
      return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.collection')->toString());
    }

    $current_user = $this->currentUser();
    /** @var \Drupal\user\Entity\User $user */
    $user = $this->entityTypeManager()->getStorage('user')->load($current_user->id());
    $test_email = $user ? $user->get('mail')->value : '';

    if (empty($test_email)) {
      $this->messenger()->addError($this->t('Your user account does not have an email address. Please add one to test newsletters.'));
      return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.collection')->toString());
    }

    $mailinglist = $easyemail_newsletter->get('mailinglist')->entity;
    if (!$mailinglist) {
      $this->messenger()->addError($this->t('Newsletter must have a mailing list selected before testing.'));
      return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.edit_form', [
        'easyemail_newsletter' => $easyemail_newsletter->id(),
      ])->toString());
    }

    $metadata = $this->database->select('easyemail_mailinglists', 'm')
      ->fields('m', ['mailinglist_id'])
      ->condition('tid', $mailinglist->id())
      ->execute()
      ->fetchAssoc();

    $remote_mailinglist_id = $metadata['mailinglist_id'] ?? '';

    if (empty($remote_mailinglist_id)) {
      $this->messenger()->addError($this->t('Mailing list "@list" has not been synchronized with the remote service yet.', [
        '@list' => $mailinglist->label(),
      ]));
      return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.collection')->toString());
    }

    $remote_newsletter_id = $easyemail_newsletter->getPeytzId();

    if (empty($remote_newsletter_id)) {
      $this->messenger()->addError($this->t('Newsletter has not been created on the remote service yet. Please save the newsletter first.'));
      return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.edit_form', [
        'easyemail_newsletter' => $easyemail_newsletter->id(),
      ])->toString());
    }

    $html = $this->buildNewsletterHtml($easyemail_newsletter);
    $text = strip_tags($html);

    // Remote test requires content to be pushed before the test send call.
    $newsletter_data = [
      'feeds' => [
        [
          'name' => 'content',
          'data' => [
            'html' => $html,
            'text' => $text,
          ],
        ],
      ],
    ];

    $instant = $this->operationQueue->isInstant();
    $nid = $easyemail_newsletter->id();

    if ($instant) {
      try {
        $this->operationQueue->runNow(
          'updateNewsletter',
          $nid,
          [$remote_mailinglist_id, $remote_newsletter_id, $newsletter_data]
        );
        $this->operationQueue->runNow(
          'testNewsletter',
          $nid,
          [$remote_mailinglist_id, $remote_newsletter_id, $test_email]
        );
        $this->messenger()->addStatus($this->t('Test email sent to @email.', [
          '@email' => $test_email,
        ]));
      }
      catch (\Exception $e) {
        $this->messenger()->addError($this->t('Failed to send test email: @error', [
          '@error' => $e->getMessage(),
        ]));
      }
    }
    else {
      $this->operationQueue->put(
        'updateNewsletter',
        $nid,
        [$remote_mailinglist_id, $remote_newsletter_id, $newsletter_data]
      );
      $this->operationQueue->put(
        'testNewsletter',
        $nid,
        [$remote_mailinglist_id, $remote_newsletter_id, $test_email]
      );

      // Set awaiting_test only for queued mode; instant mode uses hook state.
      $easyemail_newsletter->setState('awaiting_test');
      $easyemail_newsletter->save();

      $this->messenger()->addStatus($this->t('Test newsletter queued for sending to @email. It will be processed during the next cron run.', [
        '@email' => $test_email,
      ]));
    }

    return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.collection')->toString());
  }

  /**
   * Schedule newsletter for automatic sendout.
   */
  public function schedule(NewsletterInterface $easyemail_newsletter) {
    $state = $easyemail_newsletter->getState();

    if (!easyemail_action_allowed('schedule', $state)) {
      $this->messenger()->addError($this->t('Newsletter must be in "tested" state before scheduling. Current state: "@state".', [
        '@state' => $state,
      ]));
      return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.collection')->toString());
    }

    $scheduled_send = $easyemail_newsletter->getScheduledSend();
    if (!$scheduled_send) {
      $this->messenger()->addError($this->t('No send time is configured on this newsletter. Open the newsletter edit form, set a date and time under "Scheduled sendout", then try again.'));
      return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.edit_form', [
        'easyemail_newsletter' => $easyemail_newsletter->id(),
      ])->toString());
    }

    $now = \Drupal::time()->getRequestTime();
    if ($scheduled_send <= $now) {
      $this->messenger()->addError($this->t('The scheduled send time must be in the future. Please update it on the newsletter edit form.'));
      return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.edit_form', [
        'easyemail_newsletter' => $easyemail_newsletter->id(),
      ])->toString());
    }

    $easyemail_newsletter->setState('scheduled');
    $easyemail_newsletter->save();

    $formatted = \Drupal::service('date.formatter')->format($scheduled_send, 'medium');
    $this->messenger()->addStatus($this->t('Newsletter "@title" has been scheduled for sendout on @date.', [
      '@title' => $easyemail_newsletter->getTitle(),
      '@date' => $formatted,
    ]));

    return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.collection')->toString());
  }

  /**
   * Cancel a scheduled newsletter sendout.
   */
  public function unschedule(NewsletterInterface $easyemail_newsletter) {
    if ($easyemail_newsletter->getState() !== 'scheduled') {
      $this->messenger()->addError($this->t('Only newsletters in "scheduled" state can be unscheduled.'));
      return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.collection')->toString());
    }

    $easyemail_newsletter->setState('tested');
    $easyemail_newsletter->save();

    $this->messenger()->addStatus($this->t('Scheduled sendout for "@title" has been cancelled. The newsletter remains in "tested" state.', [
      '@title' => $easyemail_newsletter->getTitle(),
    ]));

    return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.collection')->toString());
  }

  /**
   * Send newsletter to mailing list.
   */
  public function send(NewsletterInterface $easyemail_newsletter) {
    $state = $easyemail_newsletter->getState();

    if (!easyemail_action_allowed('send', $state)) {
      $this->messenger()->addError($this->t('Newsletter must be in "tested" state before sending. Current state: "@state". Please test the newsletter first.', [
        '@state' => $state,
      ]));
      return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.collection')->toString());
    }

    if (!$easyemail_newsletter->get('mailinglist')->entity) {
      $this->messenger()->addError($this->t('Newsletter must have a mailing list selected before sending.'));
      return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.edit_form', [
        'easyemail_newsletter' => $easyemail_newsletter->id(),
      ])->toString());
    }

    if (empty($easyemail_newsletter->getTitle())) {
      $this->messenger()->addError($this->t('Newsletter must have a title (email subject) before sending.'));
      return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.edit_form', [
        'easyemail_newsletter' => $easyemail_newsletter->id(),
      ])->toString());
    }

    $mailinglist = $easyemail_newsletter->get('mailinglist')->entity;
    $mailinglist_name = $mailinglist ? $mailinglist->label() : $this->t('Unknown');

    $metadata = $this->database->select('easyemail_mailinglists', 'm')
      ->fields('m', ['mailinglist_id'])
      ->condition('tid', $mailinglist->id())
      ->execute()
      ->fetchAssoc();

    $remote_mailinglist_id = $metadata['mailinglist_id'] ?? '';

    if (empty($remote_mailinglist_id)) {
      $this->messenger()->addError($this->t('Mailing list "@list" has not been synchronized with the remote service yet.', [
        '@list' => $mailinglist->label(),
      ]));
      return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.collection')->toString());
    }

    $remote_newsletter_id = $easyemail_newsletter->getPeytzId();

    if (empty($remote_newsletter_id)) {
      $this->messenger()->addError($this->t('Newsletter has not been created on the remote service yet.'));
      return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.collection')->toString());
    }

    $subscriber_count = $this->entityTypeManager()->getStorage('easyemail_subscriber')
      ->getQuery()
      ->accessCheck(TRUE)
      ->condition('subscriptions', $mailinglist->id())
      ->condition('status', 1)
      ->count()
      ->execute();

    if ($subscriber_count == 0) {
      $this->messenger()->addWarning($this->t('The mailing list "@list" has no active subscribers.', [
        '@list' => $mailinglist_name,
      ]));
    }

    $instant = $this->operationQueue->isInstant();
    $nid = $easyemail_newsletter->id();

    if ($instant) {
      // Do not push content (updateNewsletter) before send — Peytz requires
      // the newsletter to have been tested after the latest content push.
      try {
        $this->operationQueue->runNow(
          'sendNewsletter',
          $nid,
          [$remote_mailinglist_id, $remote_newsletter_id]
        );
        $this->messenger()->addStatus($this->t('Newsletter "@title" sent to @count subscribers on mailing list "@list".', [
          '@title' => $easyemail_newsletter->getTitle(),
          '@count' => $subscriber_count,
          '@list' => $mailinglist_name,
        ]));
      }
      catch (\Exception $e) {
        $this->messenger()->addError($this->t('Failed to send newsletter: @error', [
          '@error' => $e->getMessage(),
        ]));
      }
    }
    else {
      $this->operationQueue->put(
        'sendNewsletter',
        $nid,
        [$remote_mailinglist_id, $remote_newsletter_id]
      );

      // Set awaiting_sending only for queued mode; instant mode uses hook state.
      $easyemail_newsletter->setState('awaiting_sending');
      $easyemail_newsletter->save();

      $this->messenger()->addStatus($this->t('Newsletter "@title" queued for sending to @count subscribers on mailing list "@list". It will be processed during the next cron run.', [
        '@title' => $easyemail_newsletter->getTitle(),
        '@count' => $subscriber_count,
        '@list' => $mailinglist_name,
      ]));
    }

    return new RedirectResponse(Url::fromRoute('entity.easyemail_newsletter.collection')->toString());
  }

  /**
   * Build newsletter HTML for preview/sending.
   *
   * @param \Drupal\easyemail\Entity\NewsletterInterface $newsletter
   *   The newsletter entity.
   *
   * @return string
   *   The rendered HTML.
   */
  protected function buildNewsletterHtml(NewsletterInterface $newsletter) {
    return $this->newsletterBuilder->buildHtml($newsletter);
  }

}
