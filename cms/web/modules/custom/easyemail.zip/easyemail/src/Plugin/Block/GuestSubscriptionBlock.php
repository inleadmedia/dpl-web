<?php

namespace Drupal\easyemail\Plugin\Block;

use Drupal\Core\Form\FormBuilderInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\easyemail\Service\MailinglistManager;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'Guest Subscription' block for anonymous users.
 *
 * @Block(
 *   id = "easyemail_guest_subscription",
 *   admin_label = @Translation("Guest Newsletter Subscription"),
 *   category = @Translation("easyEmail")
 * )
 */
class GuestSubscriptionBlock extends SubscriptionBlockBase {

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountInterface
   */
  protected $currentUser;

  /**
   * Constructs a GuestSubscriptionBlock object.
   *
   * @param array $configuration
   *   Block configuration.
   * @param string $plugin_id
   *   Plugin ID.
   * @param mixed $plugin_definition
   *   Plugin definition.
   * @param \Drupal\Core\Session\AccountInterface $current_user
   *   The current user.
   * @param \Drupal\Core\Form\FormBuilderInterface $form_builder
   *   The form builder service.
   * @param \Drupal\easyemail\Service\MailinglistManager $mailinglist_manager
   *   The mailing list manager.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, AccountInterface $current_user, FormBuilderInterface $form_builder, MailinglistManager $mailinglist_manager) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->currentUser = $current_user;
    $this->formBuilder = $form_builder;
    $this->mailinglistManager = $mailinglist_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('current_user'),
      $container->get('form_builder'),
      $container->get('easyemail.mailinglist_manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    if (easyemail_subscription_block_route_disallowed()) {
      return [];
    }

    // Guest block is for anonymous visitors only.
    if ($this->currentUser->isAuthenticated()) {
      return [];
    }

    // Pass NULL as email for guest form (will show email field).
    return $this->buildSubscriptionForm(NULL, [], FALSE);
  }

}
