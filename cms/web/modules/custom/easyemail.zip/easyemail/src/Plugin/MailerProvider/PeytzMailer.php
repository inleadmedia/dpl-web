<?php

namespace Drupal\easyemail\Plugin\MailerProvider;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\easyemail\Plugin\MailerProviderInterface;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\RequestException;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Peytz Mailer provider plugin.
 *
 * Complete REST API integration with Peytz Mailer service.
 *
 * REAL IMPLEMENTATIONS (D7 parity):
 * - checkSettings() - Test API connection
 * - createMailingList() - Create mailing list
 * - addMailinglistsToUserGroup() - Organize MLs by site_prefix
 * - subscribe() - Add subscriber
 * - unsubscribe() - Remove subscriber
 * - createNewsletter() - Create newsletter
 * - updateNewsletter() - Push HTML content
 * - testNewsletter() - Send test email
 * - sendNewsletter() - Send to all subscribers
 *
 * @MailerProvider(
 *   id = "peytz_mailer",
 *   label = @Translation("Peytz Mailer"),
 *   description = @Translation("Integration with Peytz Mailer REST API service.")
 * )
 */
class PeytzMailer implements MailerProviderInterface, ContainerFactoryPluginInterface {

  use StringTranslationTrait;

  /**
   * The HTTP client.
   *
   * @var \GuzzleHttp\ClientInterface
   */
  protected $httpClient;

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The logger factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * Constructs a PeytzMailer plugin.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \GuzzleHttp\ClientInterface $http_client
   *   The HTTP client.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger factory.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, ClientInterface $http_client, ConfigFactoryInterface $config_factory, LoggerChannelFactoryInterface $logger_factory) {
    $this->httpClient = $http_client;
    $this->configFactory = $config_factory;
    $this->loggerFactory = $logger_factory;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('http_client'),
      $container->get('config.factory'),
      $container->get('logger.factory')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getPluginId() {
    return 'peytz_mailer';
  }

  /**
   * {@inheritdoc}
   */
  public function getPluginDefinition() {
    return [
      'id' => 'peytz_mailer',
      'label' => 'Peytz Mailer',
      'description' => 'Integration with Peytz Mailer REST API service.',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getLabel() {
    return 'Peytz Mailer';
  }

  /**
   * Make an HTTP request to the Peytz API.
   *
   * @param string $method
   *   HTTP method (GET, POST, DELETE).
   * @param string $endpoint
   *   API endpoint path (e.g., 'mailinglists.json').
   * @param array|null $data
   *   Optional data to send in request body.
   * @param array $settings
   *   Optional settings override (service_url, api_key).
   *
   * @return array
   *   Decoded JSON response.
   *
   * @throws \Exception
   *   On request failure.
   */
  protected function makeRequest($method, $endpoint, $data = NULL, array $settings = []) {
    $config = $this->configFactory->get('easyemail.settings');
    $service_url = !empty($settings['service_url']) ? $settings['service_url'] : $config->get('service_url');
    $api_key = !empty($settings['api_key']) ? $settings['api_key'] : $config->get('api_key');

    $url = rtrim($service_url, '/') . '/' . ltrim($endpoint, '/');

    $options = [
      'auth' => [$api_key, ''],
      'headers' => ['Accept' => 'application/json'],
      'verify' => TRUE,
      'timeout' => 30,
    ];

    if ($data !== NULL) {
      $options['headers']['Content-Type'] = 'application/json';
      $options['json'] = $data;
    }

    $response = $this->httpClient->request($method, $url, $options);
    return json_decode($response->getBody()->getContents(), TRUE);
  }

  /**
   * Handle HTTP request exceptions with detailed error messages.
   *
   * @param \GuzzleHttp\Exception\RequestException $e
   *   The exception.
   * @param string $operation
   *   The operation being performed.
   *
   * @throws \Exception
   *   Always throws with user-friendly message.
   */
  protected function handleRequestException(RequestException $e, $operation) {
    $error_message = $e->getMessage();
    $status_code = NULL;
    $raw_body = '';

    if ($e->hasResponse()) {
      $status_code = $e->getResponse()->getStatusCode();
      $raw_body = $e->getResponse()->getBody()->getContents();

      $error_data = json_decode($raw_body, TRUE);
      if (is_array($error_data)) {
        if (isset($error_data['error'])) {
          $error_message = $error_data['error'];
        }
        // Append any extra detail fields Peytz may include.
        foreach (['message', 'description', 'details'] as $detail_key) {
          if (!empty($error_data[$detail_key]) && $error_data[$detail_key] !== $error_message) {
            $error_message .= ': ' . $error_data[$detail_key];
            break;
          }
        }
      }
      elseif (!empty($raw_body)) {
        $error_message = $raw_body;
      }

      if ($status_code === 401 || $status_code === 403) {
        $error_message = 'Authentication failed. Check your API key.';
      }
    }

    $this->loggerFactory->get('easyemail')->error(
      'Peytz API error (@operation, HTTP @code): @message — raw response: @body',
      [
        '@operation' => $operation,
        '@code' => $status_code ?? 'N/A',
        '@message' => $error_message,
        '@body' => $raw_body,
      ]
    );

    throw new \Exception("Peytz API error [{$operation}]: " . $error_message);
  }

  /**
   * Log API operation with full response if debug is enabled.
   *
   * @param string $operation
   *   The operation name.
   * @param string $message
   *   Log message.
   * @param array $context
   *   Message context.
   * @param array|null $response
   *   Optional full response for debug logging.
   */
  protected function logApiOperation($operation, $message, array $context = [], $response = NULL) {
    $this->loggerFactory->get('easyemail')->info($message, $context);

    if ($response && $this->configFactory->get('easyemail.settings')->get('debug_enabled')) {
      $this->loggerFactory->get('easyemail')->debug(
        '[PEYTZ API] @operation response: @response',
        ['@operation' => $operation, '@response' => print_r($response, TRUE)]
      );
    }
  }

  /**
   * {@inheritdoc}
   */
  public function buildSettingsForm(array $form, FormStateInterface $form_state): array {
    $config = $this->configFactory->get('easyemail.settings');

    $form['service_url'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Service URL'),
      '#description'   => $this->t('Base URL of the Peytz Mailer REST API, e.g. <code>https://inlead.peytzmail.com/api/v1</code>.'),
      '#default_value' => $config->get('service_url'),
      '#required'      => TRUE,
    ];

    $form['api_key'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('API key'),
      '#description'   => $this->t('Peytz API key used as HTTP Basic username.'),
      '#default_value' => $config->get('api_key'),
      '#required'      => TRUE,
    ];

    $form['site_prefix'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Site prefix'),
      '#description'   => $this->t('Prefix used to namespace mailing lists in Peytz, e.g. <code>ek1</code>.'),
      '#default_value' => $config->get('site_prefix'),
      '#required'      => TRUE,
    ];

    $form['peytz_template'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Newsletter template ID'),
      '#description'   => $this->t('The template identifier sent to Peytz when creating a newsletter or mailing list (e.g. <code>inlead</code>). Contact your Peytz account manager for available values.'),
      '#default_value' => $config->get('peytz_template') ?: 'inlead',
      '#required'      => TRUE,
      '#maxlength'     => 128,
    ];

    $form['shared_secret'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Shared secret'),
      '#description'   => $this->t('Shared secret for generating unsubscribe link checksums. Auto-generated on install.'),
      '#default_value' => $config->get('shared_secret'),
      '#required'      => TRUE,
      '#attributes'    => ['readonly' => 'readonly'],
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateSettingsForm(array &$form, FormStateInterface $form_state): void {
    $settings = [
      'service_url' => $form_state->getValue('service_url'),
      'api_key'     => $form_state->getValue('api_key'),
    ];
    $error = $this->checkSettings($settings);
    if ($error !== NULL) {
      $form_state->setErrorByName('api_key', $this->t('Peytz validation failed: @msg', ['@msg' => $error]));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitSettingsForm(array &$form, FormStateInterface $form_state): void {
    $this->configFactory->getEditable('easyemail.settings')
      ->set('service_url', $form_state->getValue('service_url'))
      ->set('api_key', $form_state->getValue('api_key'))
      ->set('site_prefix', $form_state->getValue('site_prefix'))
      ->set('peytz_template', $form_state->getValue('peytz_template') ?: 'inlead')
      ->set('shared_secret', $form_state->getValue('shared_secret'))
      ->save();
  }

  /**
   * {@inheritdoc}
   */
  public function checkSettings(array $settings = []) {
    $config = $this->configFactory->get('easyemail.settings');
    $service_url = !empty($settings['service_url']) ? $settings['service_url'] : $config->get('service_url');
    $api_key = !empty($settings['api_key']) ? $settings['api_key'] : $config->get('api_key');

    if (empty($service_url)) {
      return 'Service URL is not configured';
    }

    if (empty($api_key)) {
      return 'API key is not configured';
    }

    try {
      $this->makeRequest('GET', 'mailinglists.json', NULL, $settings);
      $this->loggerFactory->get('easyemail')->info('Peytz API connection test successful');
      return NULL;
    }
    catch (RequestException $e) {
      if ($e->hasResponse()) {
        $status_code = $e->getResponse()->getStatusCode();
        if ($status_code === 401) {
          return 'Authentication failed. Check your API key.';
        }
        elseif ($status_code === 403) {
          return 'Access denied. Check API permissions.';
        }
        return 'HTTP error ' . $status_code;
      }
      return 'Connection error: ' . $e->getMessage();
    }
    catch (\Exception $e) {
      return 'Error: ' . $e->getMessage();
    }
  }

  /**
   * {@inheritdoc}
   */
  public function createMailingList(array $data) {
    // Validate required fields.
    if (empty($data['title'])) {
      throw new \Exception('Mailinglist title is required.');
    }
    if (!isset($data['send_welcome_mail'])) {
      throw new \Exception("Mailinglist parameter 'send_welcome_mail' is required.");
    }
    if (!isset($data['send_confirmation_mail'])) {
      throw new \Exception("Mailinglist parameter 'send_confirmation_mail' is required.");
    }
    if (!isset($data['default_template'])) {
      throw new \Exception("Mailinglist should have a 'default_template' specified.");
    }

    try {
      $response = $this->makeRequest('POST', 'mailinglists.json', ['mailinglist' => $data]);

      $mailinglist_id = $response['mailinglist']['id'] ?? NULL;
      if (empty($mailinglist_id)) {
        throw new \Exception('Peytz API did not return a mailinglist ID');
      }

      $this->logApiOperation('createMailingList', 'Mailing list created: @id', ['@id' => $mailinglist_id], $response);

      return [
        'id' => $mailinglist_id,
        'status' => 'created',
      ];
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'createMailingList');
    }
  }

  /**
   * {@inheritdoc}
   *
   * REAL Peytz API implementation - organizes mailing lists by site_prefix.
   */
  public function addMailinglistsToUserGroup($user_group, array $mailinglist_ids, $create_if_not_exists = TRUE) {
    if (empty($user_group)) {
      throw new \Exception("User group is required and cannot be empty.");
    }
    if (empty($mailinglist_ids)) {
      throw new \Exception("Mailinglist IDs are required and cannot be empty.");
    }

    try {
      $data = [
        'user_group' => [
          'create_if_not_exists' => $create_if_not_exists,
          'mailinglist_ids' => $mailinglist_ids,
        ],
      ];

      $this->makeRequest('PUT', "user_groups/{$user_group}/add_mailinglists.json", $data);
      $this->logApiOperation('addMailinglistsToUserGroup',
        'Mailing lists added to user group @group: @ids',
        ['@group' => $user_group, '@ids' => implode(', ', $mailinglist_ids)]);

      return ['status' => 'added_to_group'];
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'addMailinglistsToUserGroup');
    }
  }

  /**
   * {@inheritdoc}
   *
   * REAL Peytz API implementation.
   */
  public function subscribe($mailinglist_id, $email) {
    if (empty($email)) {
      throw new \Exception("Subscriber's email is required.");
    }
    if (empty($mailinglist_id)) {
      throw new \Exception("Mailinglist ID is required and cannot be empty.");
    }

    try {
      $data = [
        'subscribe' => [
          'subscriber' => ['email' => $email],
          'mailinglist_ids' => [$mailinglist_id],
        ],
      ];

      $response = $this->makeRequest('POST', 'mailinglists/subscribe.json', $data);

      // Peytz returns the subscriber object; extract the remote ID if present.
      $peytz_id = $response['subscriber']['id'] ?? NULL;

      $this->logApiOperation('subscribe', 'Subscriber @email subscribed to mailing list @ml_id (peytz_id: @pid)',
        [
          '@email' => $email,
          '@ml_id' => $mailinglist_id,
          '@pid' => $peytz_id ?? 'n/a',
        ],
        $response);

      return [
        'email' => $email,
        'status' => 'subscribed',
        'peytz_id' => $peytz_id,
      ];
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'subscribe');
    }
  }

  /**
   * {@inheritdoc}
   *
   * REAL Peytz API implementation.
   */
  public function unsubscribe($mailinglist_id, $email) {
    if (empty($email)) {
      throw new \Exception("Unsubscribe email is required.");
    }
    if (empty($mailinglist_id)) {
      throw new \Exception("Mailinglist ID is required and cannot be empty.");
    }

    try {
      $data = [
        'unsubscribe' => [
          'email' => $email,
          'mailinglist_ids' => [$mailinglist_id],
        ],
      ];

      $this->makeRequest('POST', 'mailinglists/unsubscribe.json', $data);
      $this->logApiOperation('unsubscribe', 'Subscriber @email unsubscribed from mailing list @ml_id',
        ['@email' => $email, '@ml_id' => $mailinglist_id]);

      return ['email' => $email, 'status' => 'unsubscribed'];
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'unsubscribe');
    }
  }

  /**
   * {@inheritdoc}
   *
   * REAL Peytz API implementation.
   */
  public function createNewsletter($mailinglist_id, array $data) {
    if (empty($mailinglist_id)) {
      throw new \Exception("Mailinglist ID is required and cannot be empty.");
    }
    if (empty($data['title'])) {
      throw new \Exception("Newsletter title is required.");
    }
    if (empty($data['template'])) {
      throw new \Exception("Newsletter template is required.");
    }

    try {
      $response = $this->makeRequest('POST', "mailinglists/{$mailinglist_id}/newsletters.json",
        ['newsletter' => $data]);

      $newsletter_id = $response['newsletter']['id'] ?? NULL;
      $newsletter_state = $response['newsletter']['state'] ?? 'draft';

      if (!$newsletter_id) {
        throw new \Exception('Newsletter ID not found in response');
      }

      $this->logApiOperation('createNewsletter',
        'Newsletter created on Peytz: @id (state: @state) for mailing list @ml_id',
        [
          '@id' => $newsletter_id,
          '@ml_id' => $mailinglist_id,
          '@state' => $newsletter_state,
        ],
        $response);

      return [
        'id' => $newsletter_id,
        'state' => $newsletter_state,
        'status' => 'created',
      ];
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'createNewsletter');
    }
  }

  /**
   * {@inheritdoc}
   *
   * REAL Peytz API implementation - pushes newsletter HTML content.
   */
  public function updateNewsletter($mailinglist_id, $newsletter_id, array $data) {
    if (empty($mailinglist_id)) {
      throw new \Exception("Mailinglist ID is required and cannot be empty.");
    }
    if (empty($newsletter_id)) {
      throw new \Exception("Newsletter ID is required and cannot be empty.");
    }
    if (empty($data['feeds'])) {
      throw new \Exception("Newsletter feeds are required.");
    }

    try {
      $response = $this->makeRequest('POST',
        "mailinglists/{$mailinglist_id}/newsletters/{$newsletter_id}/push_data.json",
        ['newsletter' => $data]);

      $this->logApiOperation('updateNewsletter',
        'Newsletter @nl_id content pushed to Peytz',
        ['@nl_id' => $newsletter_id],
        $response);

      return ['status' => 'updated'];
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'updateNewsletter');
    }
  }

  /**
   * {@inheritdoc}
   *
   * REAL Peytz API implementation.
   */
  public function testNewsletter($mailinglist_id, $newsletter_id, $test_email) {
    if (empty($mailinglist_id)) {
      throw new \Exception("Mailinglist ID is required and cannot be empty.");
    }
    if (empty($newsletter_id)) {
      throw new \Exception("Newsletter ID is required and cannot be empty.");
    }
    if (empty($test_email)) {
      throw new \Exception("Test email address is required.");
    }

    try {
      $endpoint = "mailinglists/{$mailinglist_id}/newsletters/{$newsletter_id}/test.json?email=" . urlencode($test_email);
      $response = $this->makeRequest('GET', $endpoint);

      $state = $response['newsletter']['state'] ?? 'test_sent';

      $this->logApiOperation('testNewsletter',
        'Test newsletter API call successful: @nl_id to @email (state: @state)',
        [
          '@nl_id' => $newsletter_id,
          '@email' => $test_email,
          '@state' => $state,
        ],
        $response);

      return [
        'status' => 'test_sent',
        'state' => $state,
        'full_response' => $response,
      ];
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'testNewsletter');
    }
  }

  /**
   * {@inheritdoc}
   *
   * REAL Peytz API implementation.
   */
  public function sendNewsletter($mailinglist_id, $newsletter_id) {
    if (empty($mailinglist_id)) {
      throw new \Exception("Mailinglist ID is required and cannot be empty.");
    }
    if (empty($newsletter_id)) {
      throw new \Exception("Newsletter ID is required and cannot be empty.");
    }

    try {
      $response = $this->makeRequest('GET', "mailinglists/{$mailinglist_id}/newsletters/{$newsletter_id}/send.json");

      $state = $response['newsletter']['state'] ?? 'cleared_for_takeoff';

      $this->logApiOperation('sendNewsletter',
        'Newsletter sent: @nl_id on mailing list @ml_id (state: @state)',
        [
          '@nl_id' => $newsletter_id,
          '@ml_id' => $mailinglist_id,
          '@state' => $state,
        ],
        $response);

      return [
        'status' => 'sending',
        'state' => $state,
      ];
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'sendNewsletter');
    }
  }

}
