<?php

namespace Drupal\easyemail\Plugin\MailerProvider;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\easyemail\Plugin\MailerProviderInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Dummy mailer provider plugin for testing.
 *
 * This provider logs all operations but doesn't send any actual emails.
 * Useful for development and testing without external API dependencies.
 *
 * @MailerProvider(
 *   id = "dummy",
 *   label = @Translation("Dummy Mailer (Testing)"),
 *   description = @Translation("Logs operations without sending emails. For testing only.")
 * )
 */
class DummyMailer implements MailerProviderInterface, ContainerFactoryPluginInterface {

  use StringTranslationTrait;

  /**
   * The logger factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * Constructs a DummyMailer plugin.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger factory.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, LoggerChannelFactoryInterface $logger_factory) {
    $this->loggerFactory = $logger_factory;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('logger.factory')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getPluginId() {
    return 'dummy';
  }

  /**
   * {@inheritdoc}
   */
  public function getPluginDefinition() {
    return [
      'id' => 'dummy',
      'label' => 'Dummy Mailer (Testing)',
      'description' => 'Logs operations without sending emails. For testing only.',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getLabel() {
    return 'Dummy Mailer (Testing)';
  }

  /**
   * {@inheritdoc}
   */
  public function buildSettingsForm(array $form, FormStateInterface $form_state): array {
    $form['dummy_notice'] = [
      '#type'       => 'html_tag',
      '#tag'        => 'p',
      '#value'      => $this->t('The Dummy Mailer has no API settings. All operations are logged locally without contacting any external service.'),
      '#attributes' => ['class' => ['description']],
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateSettingsForm(array &$form, FormStateInterface $form_state): void {}

  /**
   * {@inheritdoc}
   */
  public function submitSettingsForm(array &$form, FormStateInterface $form_state): void {}

  /**
   * {@inheritdoc}
   */
  public function checkSettings(array $settings = []) {
    $this->log('checkSettings', [
      'settings' => $settings,
      'result' => 'always valid',
    ]);
    return NULL;
  }

  /**
   * {@inheritdoc}
   */
  public function createMailingList(array $data) {
    $this->log('createMailingList', $data);
    return [
      'id' => 'dummy-ml-' . time(),
      'status' => 'created',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function addMailinglistsToUserGroup($user_group, array $mailinglist_ids, $create_if_not_exists = TRUE) {
    $this->log('addMailinglistsToUserGroup', [
      'user_group' => $user_group,
      'mailinglist_ids' => $mailinglist_ids,
      'create_if_not_exists' => $create_if_not_exists,
    ]);
    return ['status' => 'added_to_group'];
  }

  /**
   * {@inheritdoc}
   */
  public function subscribe($mailinglist_id, $email) {
    $this->log('subscribe', ['id' => $mailinglist_id, 'email' => $email]);
    // Return a simulated Peytz subscriber ID so the success hook can persist it.
    return [
      'email' => $email,
      'status' => 'subscribed',
      'peytz_id' => 'dummy-' . md5($email),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function unsubscribe($mailinglist_id, $email) {
    $this->log('unsubscribe', ['id' => $mailinglist_id, 'email' => $email]);
    return ['email' => $email, 'status' => 'unsubscribed'];
  }

  /**
   * {@inheritdoc}
   */
  public function createNewsletter($mailinglist_id, array $data) {
    $this->log('createNewsletter', [
      'mailinglist_id' => $mailinglist_id,
      'data' => $data,
    ]);
    return [
      'id' => 'dummy-nl-' . time() . '-' . rand(1000, 9999),
      'state' => 'draft',
      'status' => 'created',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function updateNewsletter($mailinglist_id, $newsletter_id, array $data) {
    $this->log('updateNewsletter', [
      'mailinglist_id' => $mailinglist_id,
      'newsletter_id' => $newsletter_id,
      'data' => $data,
    ]);
    return ['status' => 'updated'];
  }

  /**
   * {@inheritdoc}
   */
  public function testNewsletter($mailinglist_id, $newsletter_id, $test_email) {
    $this->log('testNewsletter', [
      'mailinglist_id' => $mailinglist_id,
      'newsletter_id' => $newsletter_id,
      'email' => $test_email,
    ]);
    return [
      'status' => 'test_sent',
      'state' => 'tested',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function sendNewsletter($mailinglist_id, $newsletter_id) {
    $this->log('sendNewsletter', [
      'mailinglist_id' => $mailinglist_id,
      'newsletter_id' => $newsletter_id,
    ]);
    return [
      'status' => 'sent',
      'state' => 'archived',
    ];
  }

  /**
   * Log an operation.
   *
   * @param string $operation
   *   The operation name.
   * @param array $context
   *   Additional context data.
   */
  protected function log($operation, array $context = []) {
    $this->loggerFactory->get('easyemail')->info(
      '[DUMMY MAILER] @operation: @context',
      [
        '@operation' => $operation,
        '@context' => json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
      ]
    );
  }

}
