<?php

namespace Drupal\easyemail\Plugin;

use Drupal\Component\Plugin\PluginInspectionInterface;
use Drupal\Core\Form\FormStateInterface;

/**
 * Interface for mailer provider plugins.
 */
interface MailerProviderInterface extends PluginInspectionInterface {

  /**
   * Get the provider label.
   *
   * @return string
   *   The human-readable provider name.
   */
  public function getLabel();

  /**
   * Build provider-specific settings form elements.
   *
   * Called by SettingsForm to render the provider's own fields inside the
   * "API Settings" fieldset. Elements should be flat (no nesting) so that
   * FormState values are accessible by key directly.
   *
   * @param array $form
   *   The parent form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current form state.
   *
   * @return array
   *   Render array of form elements keyed by config field name.
   */
  public function buildSettingsForm(array $form, FormStateInterface $form_state): array;

  /**
   * Validate provider-specific settings form values.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current form state (use setErrorByName() to report errors).
   */
  public function validateSettingsForm(array &$form, FormStateInterface $form_state): void;

  /**
   * Persist provider-specific settings from the form submission.
   *
   * Should write values to 'easyemail.settings' config via $config_factory.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current form state.
   */
  public function submitSettingsForm(array &$form, FormStateInterface $form_state): void;

  /**
   * Check if API settings are valid.
   *
   * @param array $settings
   *   Optional settings to validate. If empty, uses current config.
   *   Expected keys: service_url, api_key.
   *
   * @return string|null
   *   Error message if validation fails, NULL on success.
   */
  public function checkSettings(array $settings = []);

  /**
   * Create a mailing list on the remote service.
   *
   * @param array $data
   *   Mailing list data (name, from_name, from_email, reply_to, etc.).
   *
   * @return array
   *   Response with 'id' and 'status'.
   */
  public function createMailingList(array $data);

  /**
   * Add mailing lists to a user group (organizes by site_prefix).
   *
   * @param string $user_group
   *   The user group name (typically site_prefix like 'ek1').
   * @param array $mailinglist_ids
   *   Array of remote mailing list IDs to add to the group.
   * @param bool $create_if_not_exists
   *   Whether to create the user group if it doesn't exist.
   *
   * @return array
   *   Response with 'status'.
   */
  public function addMailinglistsToUserGroup($user_group, array $mailinglist_ids, $create_if_not_exists = TRUE);

  /**
   * Subscribe an email to a mailing list.
   *
   * @param string $mailinglist_id
   *   The remote mailing list ID.
   * @param string $email
   *   The subscriber email address.
   *
   * @return array
   *   Response with 'status'.
   */
  public function subscribe($mailinglist_id, $email);

  /**
   * Unsubscribe an email from a mailing list.
   *
   * @param string $mailinglist_id
   *   The remote mailing list ID.
   * @param string $email
   *   The subscriber email address.
   *
   * @return array
   *   Response with 'status'.
   */
  public function unsubscribe($mailinglist_id, $email);

  /**
   * Create a newsletter on the remote service.
   *
   * @param string $mailinglist_id
   *   The remote mailing list ID.
   * @param array $data
   *   Newsletter data (title, subject, template).
   *
   * @return array
   *   Response with 'id' and 'status'.
   */
  public function createNewsletter($mailinglist_id, array $data);

  /**
   * Update a newsletter on the remote service (push HTML content).
   *
   * @param string $mailinglist_id
   *   The remote mailing list ID.
   * @param string $newsletter_id
   *   The remote newsletter ID.
   * @param array $data
   *   Newsletter data with 'feeds' containing HTML content.
   *
   * @return array
   *   Response with 'status'.
   */
  public function updateNewsletter($mailinglist_id, $newsletter_id, array $data);

  /**
   * Send a test email for a newsletter.
   *
   * @param string $mailinglist_id
   *   The remote mailing list ID.
   * @param string $newsletter_id
   *   The remote newsletter ID.
   * @param string $test_email
   *   Email address to send test to.
   *
   * @return array
   *   Response with 'status' and 'state'.
   */
  public function testNewsletter($mailinglist_id, $newsletter_id, $test_email);

  /**
   * Send a newsletter to all subscribers.
   *
   * @param string $mailinglist_id
   *   The remote mailing list ID.
   * @param string $newsletter_id
   *   The remote newsletter ID.
   *
   * @return array
   *   Response with 'status' and 'state'.
   */
  public function sendNewsletter($mailinglist_id, $newsletter_id);

}
