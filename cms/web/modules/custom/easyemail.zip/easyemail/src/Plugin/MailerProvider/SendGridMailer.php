<?php

namespace Drupal\easyemail\Plugin\MailerProvider;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\easyemail\Plugin\MailerProviderInterface;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\RequestException;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * SendGrid Marketing API provider plugin.
 *
 * Maps easyEmail operations to the SendGrid Marketing API v3.
 *
 * Operations and their SendGrid equivalents:
 *  - checkSettings()          → GET  /v3/user/account
 *  - createMailingList()      → POST /v3/marketing/lists
 *  - addMailinglistsToUserGroup() → no-op (SendGrid has no user-group concept)
 *  - subscribe()              → PUT  /v3/marketing/contacts   (async upsert)
 *  - unsubscribe()            → DELETE /v3/marketing/lists/{id}/contacts
 *  - createNewsletter()       → POST /v3/marketing/singlesends
 *  - updateNewsletter()       → PATCH /v3/marketing/singlesends/{id}
 *  - testNewsletter()         → POST /v3/mail/send  (direct transactional send)
 *  - sendNewsletter()         → PUT  /v3/marketing/singlesends/{id}/schedule
 *
 * @MailerProvider(
 *   id = "sendgrid",
 *   label = @Translation("SendGrid"),
 *   description = @Translation("Integration with the SendGrid Marketing API v3.")
 * )
 */
class SendGridMailer implements MailerProviderInterface, ContainerFactoryPluginInterface {

  use StringTranslationTrait;

  /**
   * SendGrid Marketing API base URL.
   */
  const API_BASE = 'https://api.sendgrid.com/v3';

  /**
   * The HTTP client.
   *
   * @var \GuzzleHttp\ClientInterface
   */
  protected $httpClient;

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The logger factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * Plugin configuration.
   *
   * @var array
   */
  protected $configuration;

  /**
   * Plugin ID.
   *
   * @var string
   */
  protected $pluginId;

  /**
   * Plugin definition.
   *
   * @var mixed
   */
  protected $pluginDefinition;

  /**
   * Constructs a SendGridMailer plugin.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \GuzzleHttp\ClientInterface $http_client
   *   The HTTP client.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger factory.
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, ClientInterface $http_client, ConfigFactoryInterface $config_factory, LoggerChannelFactoryInterface $logger_factory, Connection $database) {
    $this->configuration    = $configuration;
    $this->pluginId         = $plugin_id;
    $this->pluginDefinition = $plugin_definition;
    $this->httpClient       = $http_client;
    $this->configFactory    = $config_factory;
    $this->loggerFactory    = $logger_factory;
    $this->database         = $database;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('http_client'),
      $container->get('config.factory'),
      $container->get('logger.factory'),
      $container->get('database')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getPluginId() {
    return $this->pluginId;
  }

  /**
   * {@inheritdoc}
   */
  public function getPluginDefinition() {
    return $this->pluginDefinition;
  }

  /**
   * {@inheritdoc}
   */
  public function getLabel() {
    return (string) $this->pluginDefinition['label'];
  }

  // ---------------------------------------------------------------------------
  // Interface implementation
  // ---------------------------------------------------------------------------

  /**
   * {@inheritdoc}
   */
  public function buildSettingsForm(array $form, FormStateInterface $form_state): array {
    $config = $this->configFactory->get('easyemail.settings');

    $form['api_key'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('API key'),
      '#description'   => $this->t('SendGrid API key with <em>Marketing → Full Access</em> and <em>Mail Send → Full Access</em> permissions.'),
      '#default_value' => $config->get('api_key'),
      '#required'      => TRUE,
    ];

    $form['sendgrid_sender_id'] = [
      '#type'          => 'number',
      '#title'         => $this->t('Verified sender ID'),
      '#description'   => $this->t('Numeric ID of your verified sender. Find it in SendGrid under <em>Marketing → Senders</em> — hover over a sender and copy the ID from the URL, e.g. <code>/senders/12345</code>.'),
      '#default_value' => $config->get('sendgrid_sender_id'),
      '#min'           => 1,
      '#required'      => TRUE,
    ];

    $form['sendgrid_suppression_group_id'] = [
      '#type'          => 'number',
      '#title'         => $this->t('Fallback suppression group ID'),
      '#description'   => $this->t('Optional. A suppression group is created automatically per newsletter. Set this only as a fallback if automatic creation fails (requires your API key to have <em>Suppressions → Full Access</em>).'),
      '#default_value' => $config->get('sendgrid_suppression_group_id'),
      '#min'           => 1,
      '#required'      => FALSE,
    ];

    $form['sendgrid_info'] = [
      '#type'   => 'html_tag',
      '#tag'    => 'p',
      '#value'  => $this->t('The SendGrid API endpoint is fixed at <code>https://api.sendgrid.com/v3</code>. No Service URL or Site prefix is required.'),
      '#attributes' => ['class' => ['description']],
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateSettingsForm(array &$form, FormStateInterface $form_state): void {
    $error = $this->checkSettings(['api_key' => $form_state->getValue('api_key')]);
    if ($error !== NULL) {
      $form_state->setErrorByName('api_key', $this->t('SendGrid validation failed: @msg', ['@msg' => $error]));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitSettingsForm(array &$form, FormStateInterface $form_state): void {
    $this->configFactory->getEditable('easyemail.settings')
      ->set('api_key', $form_state->getValue('api_key'))
      ->set('sendgrid_sender_id', (int) $form_state->getValue('sendgrid_sender_id'))
      ->set('sendgrid_suppression_group_id', (int) $form_state->getValue('sendgrid_suppression_group_id'))
      ->save();
  }

  /**
   * {@inheritdoc}
   */
  public function checkSettings(array $settings = []) {
    $api_key = !empty($settings['api_key'])
      ? $settings['api_key']
      : $this->configFactory->get('easyemail.settings')->get('api_key');

    if (empty($api_key)) {
      return 'SendGrid API key is required.';
    }

    try {
      $this->request('GET', '/user/account', NULL, $api_key);
      return NULL;
    }
    catch (\Exception $e) {
      return $e->getMessage();
    }
  }

  /**
   * {@inheritdoc}
   *
   * Creates a SendGrid Marketing contact list.
   * The returned 'id' is the SendGrid list UUID.
   */
  public function createMailingList(array $data) {
    if (empty($data['title'])) {
      throw new \Exception('Mailing list title is required.');
    }

    try {
      $response = $this->request('POST', '/marketing/lists', [
        'name' => $data['title'],
      ]);

      $list_id = $response['id'] ?? NULL;
      if (empty($list_id)) {
        throw new \Exception('SendGrid API did not return a list ID.');
      }

      $this->log('info', 'SendGrid mailing list created: @id (@name)', [
        '@id'   => $list_id,
        '@name' => $data['title'],
      ]);

      // Create a matching suppression group for unsubscribe management.
      $suppression_group_id = 0;
      try {
        $suppression_group_id = $this->createSuppressionGroup($data['title'], $data['description'] ?? $data['title']);
      }
      catch (\Exception $e) {
        $this->log('warning', 'Could not create suppression group for list @name: @msg', [
          '@name' => $data['title'],
          '@msg'  => $e->getMessage(),
        ]);
      }

      return [
        'id'                   => $list_id,
        'status'               => 'created',
        'suppression_group_id' => $suppression_group_id,
      ];
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'createMailingList');
    }
  }

  /**
   * {@inheritdoc}
   *
   * SendGrid has no concept of user groups / site prefixes.
   * This operation is a documented no-op for this provider.
   */
  public function addMailinglistsToUserGroup($user_group, array $mailinglist_ids, $create_if_not_exists = TRUE) {
    $this->log('info', 'SendGrid: addMailinglistsToUserGroup is a no-op (user_group=@g, lists=@l)', [
      '@g' => $user_group,
      '@l' => implode(', ', $mailinglist_ids),
    ]);

    return [
      'status' => 'skipped',
      'reason' => 'SendGrid has no user-group concept',
    ];
  }

  /**
   * {@inheritdoc}
   *
   * Upserts a contact into a SendGrid Marketing list via PUT
   * /v3/marketing/contacts. This is an async operation — SendGrid queues
   * the upsert and returns a job_id rather than a subscriber ID. We return
   * the contact's email as the 'peytz_id' equivalent since there is no
   * immediate per-subscriber ID available.
   */
  public function subscribe($mailinglist_id, $email) {
    if (empty($email)) {
      throw new \Exception('Subscribe email is required.');
    }
    if (empty($mailinglist_id)) {
      throw new \Exception('Mailing list ID is required.');
    }

    try {
      $response = $this->request('PUT', '/marketing/contacts', [
        'list_ids' => [$mailinglist_id],
        'contacts' => [['email' => $email]],
      ]);

      $job_id = $response['job_id'] ?? NULL;

      $this->log('info', 'SendGrid: subscribe queued for @email on list @list (job_id: @job)', [
        '@email' => $email,
        '@list'  => $mailinglist_id,
        '@job'   => $job_id ?? 'n/a',
      ]);

      // Use email as the remote subscriber identifier since SendGrid's async
      // contact upsert does not return a per-contact ID immediately.
      return [
        'email'     => $email,
        'status'    => 'queued',
        'peytz_id'  => $email,
        'job_id'    => $job_id,
      ];
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'subscribe');
    }
  }

  /**
   * {@inheritdoc}
   *
   * Removes a contact from a SendGrid Marketing list. The contact remains
   * in the global contacts database — this only removes the list membership.
   */
  public function unsubscribe($mailinglist_id, $email) {
    if (empty($email)) {
      throw new \Exception('Unsubscribe email is required.');
    }
    if (empty($mailinglist_id)) {
      throw new \Exception('Mailing list ID is required.');
    }

    try {
      // Look up the SendGrid contact ID by email first.
      $search = $this->request('POST', '/marketing/contacts/search/emails', [
        'emails' => [$email],
      ]);

      $contact_id = $search['result'][$email]['contact']['id'] ?? NULL;

      if (empty($contact_id)) {
        // Contact not found in SendGrid — nothing to remove.
        $this->log('info', 'SendGrid: unsubscribe skipped — contact @email not found on SendGrid', [
          '@email' => $email,
        ]);
        return ['email' => $email, 'status' => 'not_found'];
      }

      // Remove contact from the specific list.
      $this->request(
        'DELETE',
        '/marketing/lists/' . $mailinglist_id . '/contacts?contact_ids=' . $contact_id,
        NULL
      );

      $this->log('info', 'SendGrid: @email removed from list @list', [
        '@email' => $email,
        '@list'  => $mailinglist_id,
      ]);

      return ['email' => $email, 'status' => 'unsubscribed'];
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'unsubscribe');
    }
  }

  /**
   * {@inheritdoc}
   *
   * Creates a SendGrid Single Send (newsletter campaign).
   * The returned 'id' is the Single Send UUID used by subsequent calls.
   */
  public function createNewsletter($mailinglist_id, array $data) {
    if (empty($mailinglist_id)) {
      throw new \Exception('Mailing list ID is required.');
    }
    if (empty($data['title'])) {
      throw new \Exception('Newsletter title is required.');
    }

    $sender_config = $this->configFactory->get('easyemail.sender');
    $settings      = $this->configFactory->get('easyemail.settings');
    $sender_id     = (int) $settings->get('sendgrid_sender_id');

    // Look up the suppression group from the mailing list metadata.
    // Fall back to the global setting if not found.
    $suppression_id = 0;
    if (!empty($mailinglist_id)) {
      $row = $this->database->select('easyemail_mailinglists', 'm')
        ->fields('m', ['suppression_group_id'])
        ->condition('mailinglist_id', $mailinglist_id)
        ->execute()
        ->fetchAssoc();
      $suppression_id = (int) ($row['suppression_group_id'] ?? 0);
    }
    if (!$suppression_id) {
      $suppression_id = (int) $settings->get('sendgrid_suppression_group_id');
    }

    try {
      $payload = [
        'name'    => $data['title'],
        'send_to' => ['list_ids' => [$mailinglist_id]],
        'email_config' => [
          'subject'              => $data['subject'] ?? $data['title'],
          'suppression_group_id' => $suppression_id ?: NULL,
          'sender_id'            => $sender_id ?: NULL,
        ],
      ];

      // Attach sender info when configured (used for reply-to override).
      $from_email = $sender_config->get('from_email');
      if ($from_email) {
        $payload['email_config']['reply_to'] = $sender_config->get('reply_to') ?: $from_email;
      }

      $response = $this->request('POST', '/marketing/singlesends', $payload);

      $send_id = $response['id'] ?? NULL;
      if (empty($send_id)) {
        throw new \Exception('SendGrid API did not return a single send ID.');
      }

      $this->log('info', 'SendGrid single send created: @id for list @list', [
        '@id'   => $send_id,
        '@list' => $mailinglist_id,
      ]);

      return [
        'id'     => $send_id,
        'status' => 'draft',
        'state'  => 'draft',
      ];
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'createNewsletter');
    }
  }

  /**
   * {@inheritdoc}
   *
   * Pushes HTML content to an existing SendGrid Single Send via PATCH.
   */
  public function updateNewsletter($mailinglist_id, $newsletter_id, array $data) {
    if (empty($newsletter_id)) {
      throw new \Exception('Newsletter (single send) ID is required.');
    }

    // Support both the nested Peytz-style structure and a flat html key.
    $html_content = $data['feeds'][0]['data']['html']
      ?? $data['feeds'][0]['content']
      ?? $data['html']
      ?? NULL;

    if (empty($html_content)) {
      throw new \Exception('HTML content is required to update a SendGrid single send.');
    }

    $settings  = $this->configFactory->get('easyemail.settings');
    $sender_id = (int) $settings->get('sendgrid_sender_id');

    // Look up the suppression group from the mailing list that owns this
    // Single Send. Fall back to reading it from the Single Send itself, then
    // the global setting.
    $suppression_id = 0;
    if (!empty($mailinglist_id)) {
      $row = $this->database->select('easyemail_mailinglists', 'm')
        ->fields('m', ['suppression_group_id'])
        ->condition('mailinglist_id', $mailinglist_id)
        ->execute()
        ->fetchAssoc();
      $suppression_id = (int) ($row['suppression_group_id'] ?? 0);
    }
    if (!$suppression_id) {
      $suppression_id = $this->getSuppressionGroupId($newsletter_id)
        ?? (int) $settings->get('sendgrid_suppression_group_id');
    }

    try {
      $email_config = [
        'html_content'  => $html_content,
        'plain_content' => strip_tags($html_content),
      ];
      if ($suppression_id) {
        $email_config['suppression_group_id'] = $suppression_id;
      }
      if ($sender_id) {
        $email_config['sender_id'] = $sender_id;
      }

      $this->request('PATCH', '/marketing/singlesends/' . $newsletter_id, [
        'email_config' => $email_config,
      ]);

      $this->log('info', 'SendGrid single send @id content updated', ['@id' => $newsletter_id]);

      return ['status' => 'updated'];
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'updateNewsletter');
    }
  }

  /**
   * {@inheritdoc}
   *
   * Sends a test email by using the transactional mail endpoint (POST
   * /v3/mail/send) with the newsletter HTML directly to the test address.
   * SendGrid's Single Send test endpoint is not available on all plans.
   */
  public function testNewsletter($mailinglist_id, $newsletter_id, $test_email) {
    if (empty($test_email)) {
      throw new \Exception('Test email address is required.');
    }
    if (empty($newsletter_id)) {
      throw new \Exception('Newsletter (single send) ID is required.');
    }

    // Fetch the current single send to get its HTML content and subject.
    try {
      $single_send = $this->request('GET', '/marketing/singlesends/' . $newsletter_id);
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'testNewsletter');
    }

    $html = $single_send['email_config']['html_content'] ?? NULL;
    if (empty($html)) {
      throw new \Exception('No HTML content found on the single send. Run "Push content" first.');
    }

    $subject = $single_send['email_config']['subject'] ?? 'Test email';
    $from_email = $single_send['email_config']['from_email']
      ?? $this->configFactory->get('easyemail.sender')->get('from_email');
    $from_name  = $single_send['email_config']['from_name']
      ?? $this->configFactory->get('easyemail.sender')->get('from_name')
      ?: $from_email;

    if (empty($from_email)) {
      throw new \Exception('Sender from_email is not configured. Set it in easyEmail sender settings.');
    }

    try {
      $this->request('POST', '/mail/send', [
        'personalizations' => [['to' => [['email' => $test_email]]]],
        'from'    => ['email' => $from_email, 'name' => $from_name],
        'subject' => '[TEST] ' . $subject,
        'content' => [['type' => 'text/html', 'value' => $html]],
      ]);

      $this->log('info', 'SendGrid test email sent for single send @id to @email', [
        '@id'    => $newsletter_id,
        '@email' => $test_email,
      ]);

      return ['status' => 'test_sent', 'state' => 'test_sent'];
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'testNewsletter');
    }
  }

  /**
   * {@inheritdoc}
   *
   * Schedules a SendGrid Single Send to send immediately.
   */
  public function sendNewsletter($mailinglist_id, $newsletter_id) {
    if (empty($newsletter_id)) {
      throw new \Exception('Newsletter (single send) ID is required.');
    }

    try {
      $this->request('PUT', '/marketing/singlesends/' . $newsletter_id . '/schedule', [
        'send_at' => 'now',
      ]);

      $this->log('info', 'SendGrid single send @id scheduled for immediate delivery', [
        '@id' => $newsletter_id,
      ]);

      return ['status' => 'sent', 'state' => 'cleared_for_takeoff'];
    }
    catch (RequestException $e) {
      $this->handleRequestException($e, 'sendNewsletter');
    }
  }

  // ---------------------------------------------------------------------------
  // Internal helpers
  // ---------------------------------------------------------------------------

  /**
   * Creates a SendGrid suppression (unsubscribe) group for a newsletter.
   *
   * Suppression groups are capped at 30 chars for the name.
   *
   * @param string $name
   *   Newsletter title.
   * @param string $description
   *   Short description used as the group description.
   *
   * @return int
   *   The new suppression group ID.
   */
  protected function createSuppressionGroup(string $name, string $description = ''): int {
    // SendGrid caps group names at 30 chars; description allows up to 100.
    $truncated_name = mb_substr($name, 0, 30);
    $response = $this->request('POST', '/asm/groups', [
      'name'        => $truncated_name,
      'description' => mb_substr($description ?: $name, 0, 100),
      'is_default'  => FALSE,
    ]);

    $group_id = (int) ($response['id'] ?? 0);
    if (!$group_id) {
      throw new \Exception('SendGrid did not return a suppression group ID.');
    }

    $this->log('info', 'SendGrid suppression group created: @id (@name)', [
      '@id'   => $group_id,
      '@name' => $truncated_name,
    ]);

    return $group_id;
  }

  /**
   * Fetches the suppression_group_id from an existing Single Send.
   *
   * @param string $newsletter_id
   *   Single Send UUID.
   *
   * @return int|null
   *   The suppression group ID, or NULL if not set.
   */
  protected function getSuppressionGroupId(string $newsletter_id): ?int {
    try {
      $single_send = $this->request('GET', '/marketing/singlesends/' . $newsletter_id);
      $id = (int) ($single_send['email_config']['suppression_group_id'] ?? 0);
      return $id ?: NULL;
    }
    catch (\Exception $e) {
      return NULL;
    }
  }

  /**
   * Make an authenticated request to the SendGrid API.
   *
   * @param string $method
   *   HTTP method (GET, POST, PUT, PATCH, DELETE).
   * @param string $endpoint
   *   API path relative to /v3 (e.g. '/marketing/lists').
   * @param array|null $data
   *   Optional JSON payload.
   * @param string|null $api_key_override
   *   Optional API key override (used during settings validation).
   *
   * @return array
   *   Decoded JSON response body (empty array for 204 No Content).
   *
   * @throws \GuzzleHttp\Exception\RequestException
   *   On HTTP error.
   */
  protected function request($method, $endpoint, $data = NULL, $api_key_override = NULL) {
    $api_key = $api_key_override
      ?? $this->configFactory->get('easyemail.settings')->get('api_key');

    $url = rtrim(self::API_BASE, '/') . '/' . ltrim($endpoint, '/');

    $options = [
      'headers' => [
        'Authorization' => 'Bearer ' . $api_key,
        'Accept'        => 'application/json',
      ],
      'verify'  => TRUE,
      'timeout' => 30,
    ];

    if ($data !== NULL) {
      $options['headers']['Content-Type'] = 'application/json';
      $options['json'] = $data;
    }

    $response = $this->httpClient->request($method, $url, $options);
    $body = (string) $response->getBody();

    // 202 Accepted and 204 No Content return empty bodies.
    if (empty($body)) {
      return [];
    }

    return json_decode($body, TRUE) ?? [];
  }

  /**
   * Handle a Guzzle RequestException with a descriptive message.
   *
   * @param \GuzzleHttp\Exception\RequestException $e
   *   The exception.
   * @param string $operation
   *   Operation name for logging.
   *
   * @throws \Exception
   *   Always throws with a user-friendly message.
   */
  protected function handleRequestException(RequestException $e, $operation) {
    $status_code = NULL;
    $error_message = $e->getMessage();
    $raw_body = '';

    if ($e->hasResponse()) {
      $status_code = $e->getResponse()->getStatusCode();
      $raw_body    = (string) $e->getResponse()->getBody();
      $decoded     = json_decode($raw_body, TRUE);

      if (is_array($decoded)) {
        // SendGrid wraps errors in {"errors":[{"message":"..."}]}.
        if (!empty($decoded['errors'][0]['message'])) {
          $error_message = $decoded['errors'][0]['message'];
        }
        elseif (!empty($decoded['message'])) {
          $error_message = $decoded['message'];
        }
      }
      elseif (!empty($raw_body)) {
        $error_message = $raw_body;
      }

      if ($status_code === 401 || $status_code === 403) {
        $error_message = 'Authentication failed. Check your SendGrid API key and ensure it has Marketing permissions.';
      }
    }

    $this->loggerFactory->get('easyemail')->error(
      'SendGrid API error (@op, HTTP @code): @msg — raw: @body',
      [
        '@op'   => $operation,
        '@code' => $status_code ?? 'N/A',
        '@msg'  => $error_message,
        '@body' => $raw_body,
      ]
    );

    throw new \Exception("SendGrid API error [{$operation}]: " . $error_message);
  }

  /**
   * Log a message through the easyemail logger channel.
   */
  protected function log($level, $message, array $context = []) {
    $this->loggerFactory->get('easyemail')->{$level}($message, $context);
  }

}
