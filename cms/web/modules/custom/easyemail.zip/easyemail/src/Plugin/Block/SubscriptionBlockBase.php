<?php

namespace Drupal\easyemail\Plugin\Block;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Session\AccountInterface;

/**
 * Base class for newsletter subscription blocks.
 *
 * Centralizes route-based access, cache metadata and the shared logic for
 * building the subscription form from the available synced mailing lists.
 */
abstract class SubscriptionBlockBase extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * The mailing list manager.
   *
   * @var \Drupal\easyemail\Service\MailinglistManager
   */
  protected $mailinglistManager;

  /**
   * The form builder service.
   *
   * @var \Drupal\Core\Form\FormBuilderInterface
   */
  protected $formBuilder;

  /**
   * {@inheritdoc}
   */
  public function blockAccess(AccountInterface $account, $return_as_object = TRUE) {
    $access = parent::blockAccess($account, TRUE);
    if ($access->isForbidden()) {
      return $return_as_object ? $access : $access->isAllowed();
    }
    if (easyemail_subscription_block_route_disallowed()) {
      $access = AccessResult::forbidden()->addCacheContexts(['route']);
    }
    return $return_as_object ? $access : $access->isAllowed();
  }

  /**
   * Build the subscription form render array.
   *
   * @param string|null $email
   *   The subscriber email, or NULL to render the guest email field.
   * @param array $current_subscriptions
   *   Term IDs the subscriber is currently subscribed to.
   * @param bool $access_check
   *   Whether to apply entity access checks when listing mailing lists.
   *
   * @return array
   *   A render array with the subscription form, or an empty-state message.
   */
  protected function buildSubscriptionForm($email, array $current_subscriptions, bool $access_check): array {
    $options = $this->mailinglistManager->getSubscribableOptions($access_check);

    if (empty($options)) {
      return [
        '#markup' => '<p>' . $this->t('There are no mailing lists available at the moment.') . '</p>',
      ];
    }

    return $this->formBuilder->getForm('Drupal\easyemail\Form\SubscribeForm', $email, $current_subscriptions, $options);
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheMaxAge() {
    return 0;
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheContexts() {
    return array_merge(parent::getCacheContexts(), ['route', 'user.roles']);
  }

}
