<?php

namespace Drupal\easyemail\Plugin\Block;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBuilderInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\easyemail\Service\MailinglistManager;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'Manage Subscriptions' block for authenticated users.
 *
 * @Block(
 *   id = "easyemail_subscribe_block",
 *   admin_label = @Translation("Manage Newsletter Subscriptions"),
 *   category = @Translation("easyEmail")
 * )
 */
class SubscribeBlock extends SubscriptionBlockBase {

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountInterface
   */
  protected $currentUser;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Constructs a SubscribeBlock object.
   *
   * @param array $configuration
   *   Block configuration.
   * @param string $plugin_id
   *   Plugin ID.
   * @param mixed $plugin_definition
   *   Plugin definition.
   * @param \Drupal\Core\Session\AccountInterface $current_user
   *   The current user.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Form\FormBuilderInterface $form_builder
   *   The form builder service.
   * @param \Drupal\easyemail\Service\MailinglistManager $mailinglist_manager
   *   The mailing list manager.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, AccountInterface $current_user, EntityTypeManagerInterface $entity_type_manager, FormBuilderInterface $form_builder, MailinglistManager $mailinglist_manager) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->currentUser = $current_user;
    $this->entityTypeManager = $entity_type_manager;
    $this->formBuilder = $form_builder;
    $this->mailinglistManager = $mailinglist_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('current_user'),
      $container->get('entity_type.manager'),
      $container->get('form_builder'),
      $container->get('easyemail.mailinglist_manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    if (easyemail_subscription_block_route_disallowed()) {
      return [];
    }

    // Only show for authenticated users.
    if ($this->currentUser->isAnonymous()) {
      return [];
    }

    $user = $this->entityTypeManager->getStorage('user')->load($this->currentUser->id());
    $email = $user->getEmail();

    // Get user's current subscriptions.
    $subscriber_storage = $this->entityTypeManager->getStorage('easyemail_subscriber');
    $subscribers = $subscriber_storage->loadByProperties(['email' => $email]);
    $current_subscriptions = [];

    if ($subscriber = reset($subscribers)) {
      foreach ($subscriber->get('subscriptions') as $item) {
        if ($item->target_id) {
          $current_subscriptions[] = $item->target_id;
        }
      }
    }

    return $this->buildSubscriptionForm($email, $current_subscriptions, TRUE);
  }

}
