<?php

namespace Drupal\easyemail\Annotation;

use Drupal\Component\Annotation\Plugin;

/**
 * Defines a mailer provider plugin annotation object.
 *
 * @Annotation
 */
class MailerProvider extends Plugin {

  /**
   * The plugin ID.
   *
   * @var string
   */
  public $id;

  /**
   * The human-readable name of the mailer provider.
   *
   * @var \Drupal\Core\Annotation\Translation
   *
   * @ingroup plugin_translatable
   */
  public $label;

  /**
   * A brief description of the mailer provider.
   *
   * @var \Drupal\Core\Annotation\Translation
   *
   * @ingroup plugin_translatable
   */
  public $description;

}
