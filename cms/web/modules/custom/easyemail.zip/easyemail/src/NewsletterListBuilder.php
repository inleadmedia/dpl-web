<?php

namespace Drupal\easyemail;

use Drupal\Core\Access\CsrfTokenGenerator;
use Drupal\Core\Datetime\DateFormatterInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Link;
use Drupal\Core\Render\Markup;
use Drupal\Core\Url;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Defines a class to build a listing of Newsletter entities.
 */
class NewsletterListBuilder extends EntityListBuilder {

  /**
   * The date formatter service.
   *
   * @var \Drupal\Core\Datetime\DateFormatterInterface
   */
  protected $dateFormatter;

  /**
   * The CSRF token generator.
   *
   * @var \Drupal\Core\Access\CsrfTokenGenerator
   */
  protected $csrfToken;

  /**
   * Constructs a new NewsletterListBuilder object.
   *
   * @param \Drupal\Core\Entity\EntityTypeInterface $entity_type
   *   The entity type definition.
   * @param \Drupal\Core\Entity\EntityStorageInterface $storage
   *   The entity storage class.
   * @param \Drupal\Core\Datetime\DateFormatterInterface $date_formatter
   *   The date formatter service.
   * @param \Drupal\Core\Access\CsrfTokenGenerator $csrf_token
   *   The CSRF token generator.
   */
  public function __construct(EntityTypeInterface $entity_type, EntityStorageInterface $storage, DateFormatterInterface $date_formatter, CsrfTokenGenerator $csrf_token) {
    parent::__construct($entity_type, $storage);
    $this->dateFormatter = $date_formatter;
    $this->csrfToken = $csrf_token;
  }

  /**
   * {@inheritdoc}
   */
  public static function createInstance(ContainerInterface $container, EntityTypeInterface $entity_type) {
    return new static(
      $entity_type,
      $container->get('entity_type.manager')->getStorage($entity_type->id()),
      $container->get('date.formatter'),
      $container->get('csrf_token')
    );
  }

  /**
   * Build a CSRF-protected URL for a state-changing action route.
   */
  protected function csrfUrl(string $route_name, array $route_parameters = []): Url {
    $url = Url::fromRoute($route_name, $route_parameters);
    $url->setOption('query', ['token' => $this->csrfToken->get($url->getInternalPath())]);
    return $url;
  }

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['id'] = $this->t('ID');
    $header['title'] = $this->t('Title');
    $header['mailinglist'] = $this->t('Mailing List');
    $header['state'] = $this->t('State');
    $header['scheduled_send'] = $this->t('Scheduled send');
    $header['peytz_id'] = $this->t('Remote ID');
    $header['author'] = $this->t('Author');
    $header['created'] = $this->t('Created');
    $header['changed'] = $this->t('Updated');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /** @var \Drupal\easyemail\Entity\NewsletterInterface $entity */
    $row['id'] = $entity->id();
    $row['title'] = Link::createFromRoute(
      $entity->getTitle(),
      'entity.easyemail_newsletter.edit_form',
      ['easyemail_newsletter' => $entity->id()]
    );

    $row['mailinglist'] = $entity->get('mailinglist')->entity
      ? $entity->get('mailinglist')->entity->label()
      : $this->t('- None -');

    $state = $entity->getState();
    $state_labels = [
      'new' => $this->t('New'),
      'abandoned' => $this->t('Abandoned'),
      'draft' => $this->t('Draft'),
      'awaiting_test' => $this->t('Awaiting test'),
      'test_sent' => $this->t('Test sent'),
      'testing' => $this->t('Testing'),
      'tested' => $this->t('Tested'),
      'test_failed' => $this->t('Test failed'),
      'scheduled' => $this->t('Scheduled'),
      'awaiting_sending' => $this->t('Awaiting sending'),
      'cleared_for_takeoff' => $this->t('Cleared for takeoff'),
      'preparing_data' => $this->t('Preparing data'),
      'queueing' => $this->t('Queueing'),
      'waiting_for_workers' => $this->t('Waiting for workers'),
      'paused' => $this->t('Paused'),
      'sending' => $this->t('Sending'),
      'failed' => $this->t('Failed'),
      'skipped' => $this->t('Skipped'),
      'aborted' => $this->t('Aborted'),
      'archived' => $this->t('Archived'),
    ];

    $state_label = $state_labels[$state] ?? $state;

    $row['state'] = $state_label;

    $scheduled_send = $entity->getScheduledSend();
    if ($scheduled_send) {
      $date = $this->dateFormatter->format($scheduled_send, 'short');
      $sent_states = [
        'tested', 'scheduled',
        'awaiting_sending', 'cleared_for_takeoff', 'queueing',
        'waiting_for_workers', 'paused', 'sending',
        'failed', 'skipped', 'aborted', 'archived',
      ];
      if (!in_array($state, $sent_states)) {
        $row['scheduled_send'] = [
          'data' => [
            '#markup' => Markup::create($date . '<br><small style="color: orange;">' . $this->t('Not ready — newsletter must be tested first') . '</small>'),
          ],
        ];
      }
      else {
        $row['scheduled_send'] = $date;
      }
    }
    else {
      $row['scheduled_send'] = $this->t('—');
    }

    $peytz_id = $entity->getPeytzId();
    $row['peytz_id'] = $peytz_id ?: $this->t('Not synced');

    $row['author'] = $entity->getOwner()
      ? $entity->getOwner()->getDisplayName()
      : $this->t('Anonymous');

    $row['created'] = $this->dateFormatter->format($entity->getCreatedTime(), 'short');
    $row['changed'] = $this->dateFormatter->format($entity->getChangedTime(), 'short');

    return $row + parent::buildRow($entity);
  }

  /**
   * {@inheritdoc}
   */
  public function getDefaultOperations(EntityInterface $entity) {
    /** @var \Drupal\easyemail\Entity\NewsletterInterface $entity */
    $operations = [];
    $state = $entity->getState();

    $operations['preview'] = [
      'title' => $this->t('Preview'),
      'weight' => 5,
      'url' => Url::fromRoute('easyemail.newsletter.preview', [
        'easyemail_newsletter' => $entity->id(),
      ]),
    ];

    if ($entity->access('update') && $entity->hasLinkTemplate('edit-form') && easyemail_action_allowed('edit', $state)) {
      $operations['edit'] = [
        'title' => $this->t('Edit'),
        'weight' => 10,
        'url' => $entity->toUrl('edit-form'),
      ];
    }

    if (easyemail_action_allowed('test', $state)) {
      $operations['test'] = [
        'title' => $this->t('Test'),
        'weight' => 20,
        'url' => $this->csrfUrl('easyemail.newsletter.test', [
          'easyemail_newsletter' => $entity->id(),
        ]),
      ];
    }

    if (easyemail_action_allowed('send', $state)) {
      $operations['send'] = [
        'title' => $this->t('Send'),
        'weight' => 30,
        'url' => $this->csrfUrl('easyemail.newsletter.send', [
          'easyemail_newsletter' => $entity->id(),
        ]),
      ];
    }

    if (easyemail_action_allowed('schedule', $state)) {
      $operations['schedule'] = [
        'title' => $this->t('Schedule sendout'),
        'weight' => 35,
        'url' => $this->csrfUrl('easyemail.newsletter.schedule', [
          'easyemail_newsletter' => $entity->id(),
        ]),
      ];
    }

    if ($state === 'scheduled') {
      $operations['unschedule'] = [
        'title' => $this->t('Cancel schedule'),
        'weight' => 36,
        'url' => $this->csrfUrl('easyemail.newsletter.unschedule', [
          'easyemail_newsletter' => $entity->id(),
        ]),
      ];
    }

    if ($entity->access('delete') && $entity->hasLinkTemplate('delete-form')) {
      $operations['delete'] = [
        'title' => $this->t('Delete'),
        'weight' => 100,
        'url' => $entity->toUrl('delete-form'),
      ];
    }

    return $operations;
  }

}
