<?php

namespace Drupal\easyemail;

use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Plugin\DefaultPluginManager;

/**
 * Manages mailer provider plugins.
 */
class MailerProviderPluginManager extends DefaultPluginManager {

  /**
   * Constructs a MailerProviderPluginManager object.
   *
   * @param \Traversable $namespaces
   *   An object that implements \Traversable which contains the root paths
   *   keyed by the corresponding namespace to look for plugin implementations.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache_backend
   *   Cache backend instance to use.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler.
   */
  public function __construct(\Traversable $namespaces, CacheBackendInterface $cache_backend, ModuleHandlerInterface $module_handler) {
    parent::__construct(
      'Plugin/MailerProvider',
      $namespaces,
      $module_handler,
      'Drupal\easyemail\Plugin\MailerProviderInterface',
      'Drupal\easyemail\Annotation\MailerProvider'
    );
    $this->alterInfo('easyemail_mailer_provider_info');
    $this->setCacheBackend($cache_backend, 'easyemail_mailer_provider_plugins');
  }

}
