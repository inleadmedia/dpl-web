<?php

namespace Drupal\easyemail\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\user\EntityOwnerTrait;

/**
 * Defines the Newsletter entity.
 *
 * @ContentEntityType(
 *   id = "easyemail_newsletter",
 *   label = @Translation("Newsletter"),
 *   label_collection = @Translation("Newsletters"),
 *   label_singular = @Translation("newsletter"),
 *   label_plural = @Translation("newsletters"),
 *   label_count = @PluralTranslation(
 *     singular = "@count newsletter",
 *     plural = "@count newsletters",
 *   ),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\easyemail\NewsletterListBuilder",
 *     "views_data" = "Drupal\views\EntityViewsData",
 *     "form" = {
 *       "default" = "Drupal\easyemail\Form\NewsletterForm",
 *       "add" = "Drupal\easyemail\Form\NewsletterForm",
 *       "edit" = "Drupal\easyemail\Form\NewsletterForm",
 *       "delete" = "Drupal\Core\Entity\ContentEntityDeleteForm",
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider",
 *     },
 *     "access" = "Drupal\easyemail\NewsletterAccessControlHandler",
 *   },
 *   base_table = "easyemail_newsletter",
 *   translatable = FALSE,
 *   admin_permission = "manage newsletters",
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "title",
 *     "owner" = "uid",
 *   },
 *   links = {
 *     "canonical" = "/admin/easyemail/newsletter/{easyemail_newsletter}",
 *     "add-form" = "/admin/easyemail/newsletter/add",
 *     "edit-form" = "/admin/easyemail/newsletter/{easyemail_newsletter}/edit",
 *     "delete-form" = "/admin/easyemail/newsletter/{easyemail_newsletter}/delete",
 *     "collection" = "/admin/easyemail/newsletters",
 *   },
 *   field_ui_base_route = "easyemail.settings",
 * )
 */
class Newsletter extends ContentEntityBase implements NewsletterInterface {

  use EntityChangedTrait;
  use EntityOwnerTrait;

  /**
   * {@inheritdoc}
   */
  public function getTitle() {
    return $this->get('title')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setTitle($title) {
    $this->set('title', $title);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getState() {
    return $this->get('state')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setState($state) {
    $this->set('state', $state);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getPeytzId() {
    return $this->get('peytz_id')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setPeytzId($peytz_id) {
    $this->set('peytz_id', $peytz_id);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getScheduledSend() {
    $value = $this->get('scheduled_send')->value;
    if (!$value) {
      return NULL;
    }
    // Datetime fields store values as 'Y-m-d\TH:i:s' strings (UTC).
    return (new \DateTime($value, new \DateTimeZone('UTC')))->getTimestamp();
  }

  /**
   * {@inheritdoc}
   */
  public function setScheduledSend($timestamp) {
    if ($timestamp === NULL) {
      $this->set('scheduled_send', NULL);
    }
    else {
      $dt = new \DateTime('@' . $timestamp);
      $dt->setTimezone(new \DateTimeZone('UTC'));
      $this->set('scheduled_send', $dt->format('Y-m-d\TH:i:s'));
    }
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getCreatedTime() {
    return $this->get('created')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setCreatedTime($timestamp) {
    $this->set('created', $timestamp);
    return $this;
  }

  /**
   * Default value callback for 'uid' field.
   */
  public static function getCurrentUserId() {
    return [\Drupal::currentUser()->id()];
  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields = parent::baseFieldDefinitions($entity_type);

    // Add owner trait fields.
    $fields += static::ownerBaseFieldDefinitions($entity_type);

    $fields['title'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Newsletter title'))
      ->setDescription(t('The title of the newsletter (used as email subject).'))
      ->setRequired(TRUE)
      ->setSetting('max_length', 255)
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'string',
        'weight' => -5,
      ])
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -5,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['body'] = BaseFieldDefinition::create('text_long')
      ->setLabel(t('Introduction'))
      ->setDescription(t('Introduction text shown at the top of the newsletter.'))
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'text_default',
        'weight' => 0,
      ])
      ->setDisplayOptions('form', [
        'type' => 'text_textarea',
        'weight' => 0,
        'rows' => 6,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['header_image'] = BaseFieldDefinition::create('image')
      ->setLabel(t('Header image'))
      ->setDescription(t('Image shown in the newsletter header.'))
      ->setSettings([
        'file_directory' => 'easyemail/headers',
        'alt_field_required' => FALSE,
        'file_extensions' => 'png jpg jpeg gif',
      ])
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'image',
        'weight' => -3,
      ])
      ->setDisplayOptions('form', [
        'type' => 'image_image',
        'weight' => 5,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['footer'] = BaseFieldDefinition::create('text_long')
      ->setLabel(t('Footer text'))
      ->setDescription(t('Text shown at the bottom of the newsletter.'))
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'text_default',
        'weight' => 10,
      ])
      ->setDisplayOptions('form', [
        'type' => 'text_textarea',
        'weight' => 10,
        'rows' => 4,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['components'] = BaseFieldDefinition::create('entity_reference_revisions')
      ->setLabel(t('Components'))
      ->setDescription(t('Add sections to structure the newsletter content.'))
      ->setSetting('target_type', 'paragraph')
      ->setSetting('handler', 'default:paragraph')
      ->setSetting('handler_settings', [
        'negate' => 0,
        'target_bundles' => ['newsletter_section' => 'newsletter_section'],
        'target_bundles_drag_drop' => [
          'newsletter_section' => ['enabled' => TRUE, 'weight' => 1],
        ],
      ])
      ->setCardinality(BaseFieldDefinition::CARDINALITY_UNLIMITED)
      ->setDisplayOptions('form', [
        'type' => 'paragraphs',
        'weight' => 5,
        'settings' => [
          'title' => 'Section',
          'title_plural' => 'Sections',
          'edit_mode' => 'open',
          'closed_mode' => 'summary',
          'autocollapse' => 'none',
          'add_mode' => 'dropdown',
          'form_display_mode' => 'default',
          'default_paragraph_type' => 'newsletter_section',
          'features' => [
            'add_above' => '0',
            'collapse_edit_all' => 'collapse_edit_all',
            'duplicate' => 'duplicate',
          ],
        ],
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['mailinglist'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Mailing list'))
      ->setDescription(t('Select which mailing list to send this newsletter to.'))
      ->setSetting('target_type', 'taxonomy_term')
      ->setSetting('handler', 'default')
      ->setSetting('handler_settings', ['target_bundles' => ['mailinglist' => 'mailinglist']])
      ->setRequired(TRUE)
      ->setDisplayOptions('view', [
        'label' => 'above',
        'type' => 'entity_reference_label',
        'weight' => 2,
      ])
      ->setDisplayOptions('form', [
        'type' => 'options_select',
        'weight' => 2,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['peytz_id'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Peytz Newsletter ID'))
      ->setDescription(t('Remote newsletter ID from Peytz Mailer service.'))
      ->setSetting('max_length', 255)
      ->setReadOnly(TRUE)
      ->setDisplayOptions('view', [
        'label' => 'inline',
        'type' => 'string',
        'weight' => 20,
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['state'] = BaseFieldDefinition::create('list_string')
      ->setLabel(t('State'))
      ->setDescription(t('Current state of the newsletter.'))
      ->setSetting('allowed_values', [
        // Local draft states.
        'new' => 'New',
        'abandoned' => 'Abandoned',
        'draft' => 'Draft',
        // Test workflow states.
        'awaiting_test' => 'Awaiting test',
        'test_sent' => 'Test sent',
        'testing' => 'Testing',
        'tested' => 'Tested',
        'test_failed' => 'Test failed',
        // Send workflow states.
        'scheduled' => 'Scheduled',
        'awaiting_sending' => 'Awaiting sending',
        'cleared_for_takeoff' => 'Cleared for takeoff',
        'preparing_data' => 'Preparing data',
        'queueing' => 'Queueing',
        'waiting_for_workers' => 'Waiting for workers',
        'paused' => 'Paused',
        'sending' => 'Sending',
        // Final states.
        'failed' => 'Failed',
        'skipped' => 'Skipped',
        'aborted' => 'Aborted',
        'archived' => 'Archived',
      ])
      ->setDefaultValue('new')
      ->setDisplayOptions('view', [
        'label' => 'inline',
        'type' => 'list_default',
        'weight' => 15,
      ])
      ->setDisplayOptions('form', [
        'type' => 'options_select',
        'weight' => 15,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['created'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Created'))
      ->setDescription(t('The time that the newsletter was created.'));

    $fields['scheduled_send'] = BaseFieldDefinition::create('datetime')
      ->setLabel(t('Scheduled send time'))
      ->setDescription(t('Date and time to automatically send this newsletter. Only takes effect after the newsletter has passed testing and the schedule is activated.'))
      ->setRequired(FALSE)
      ->setDisplayOptions('form', [
        'type' => 'datetime_default',
        'weight' => 91,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('view', [
        'label' => 'inline',
        'type' => 'datetime_default',
        'weight' => 21,
        'settings' => ['format_type' => 'medium'],
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Changed'))
      ->setDescription(t('The time that the newsletter was last edited.'));

    $fields['uid']
      ->setLabel(t('Author'))
      ->setDescription(t('The user who created the newsletter.'))
      ->setDisplayOptions('view', [
        'label' => 'inline',
        'type' => 'author',
        'weight' => 18,
      ])
      ->setDisplayOptions('form', [
        'type' => 'entity_reference_autocomplete',
        'weight' => 18,
        'settings' => [
          'match_operator' => 'CONTAINS',
          'size' => 60,
          'placeholder' => '',
        ],
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    return $fields;
  }

}
