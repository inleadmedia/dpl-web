<?php

namespace Drupal\easyemail\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;

/**
 * Defines the Subscriber entity.
 *
 * @ContentEntityType(
 *   id = "easyemail_subscriber",
 *   label = @Translation("Subscriber"),
 *   label_collection = @Translation("Subscribers"),
 *   label_singular = @Translation("subscriber"),
 *   label_plural = @Translation("subscribers"),
 *   label_count = @PluralTranslation(
 *     singular = "@count subscriber",
 *     plural = "@count subscribers",
 *   ),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\easyemail\SubscriberListBuilder",
 *     "views_data" = "Drupal\views\EntityViewsData",
 *     "form" = {
 *       "default" = "Drupal\easyemail\Form\SubscriberForm",
 *       "add" = "Drupal\easyemail\Form\SubscriberForm",
 *       "edit" = "Drupal\easyemail\Form\SubscriberForm",
 *       "delete" = "Drupal\Core\Entity\ContentEntityDeleteForm",
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider",
 *     },
 *     "access" = "Drupal\easyemail\SubscriberAccessControlHandler",
 *   },
 *   base_table = "easyemail_subscriber",
 *   translatable = FALSE,
 *   admin_permission = "manage newsletters",
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "email",
 *   },
 *   links = {
 *     "canonical" = "/admin/easyemail/subscriber/{easyemail_subscriber}",
 *     "add-form" = "/admin/easyemail/subscriber/add",
 *     "edit-form" = "/admin/easyemail/subscriber/{easyemail_subscriber}/edit",
 *     "delete-form" = "/admin/easyemail/subscriber/{easyemail_subscriber}/delete",
 *     "collection" = "/admin/easyemail/subscribers",
 *   },
 *   field_ui_base_route = "easyemail.settings",
 * )
 */
class Subscriber extends ContentEntityBase implements SubscriberInterface {

  use EntityChangedTrait;

  /**
   * {@inheritdoc}
   */
  public function getEmail() {
    return $this->get('email')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setEmail($email) {
    $this->set('email', $email);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function isActive() {
    return (bool) $this->get('status')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setStatus($status) {
    $this->set('status', $status);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getSource() {
    return $this->get('source')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setSource($source) {
    $this->set('source', $source);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getPeytzId() {
    return $this->get('peytz_id')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setPeytzId($peytz_id) {
    $this->set('peytz_id', $peytz_id);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getCreatedTime() {
    return $this->get('created')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setCreatedTime($timestamp) {
    $this->set('created', $timestamp);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function label() {
    return $this->getEmail();
  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['email'] = BaseFieldDefinition::create('email')
      ->setLabel(t('Email address'))
      ->setDescription(t('The email address of the subscriber.'))
      ->setRequired(TRUE)
      ->setSetting('max_length', 255)
      ->addConstraint('UniqueField')
      ->setDisplayOptions('view', [
        'label' => 'inline',
        'type' => 'email_mailto',
        'weight' => -5,
      ])
      ->setDisplayOptions('form', [
        'type' => 'email_default',
        'weight' => -5,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['subscriptions'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Subscriptions'))
      ->setDescription(t('Mailing lists this subscriber is subscribed to.'))
      ->setSetting('target_type', 'taxonomy_term')
      ->setSetting('handler', 'default')
      ->setSetting('handler_settings', ['target_bundles' => ['mailinglist' => 'mailinglist']])
      ->setCardinality(BaseFieldDefinition::CARDINALITY_UNLIMITED)
      ->setDisplayOptions('view', [
        'label' => 'above',
        'type' => 'entity_reference_label',
        'weight' => 0,
      ])
      ->setDisplayOptions('form', [
        'type' => 'options_buttons',
        'weight' => 0,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['status'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Active'))
      ->setDescription(t('Whether the subscriber is active.'))
      ->setDefaultValue(TRUE)
      ->setDisplayOptions('view', [
        'label' => 'inline',
        'type' => 'boolean',
        'weight' => 5,
        'settings' => [
          'format' => 'yes-no',
        ],
      ])
      ->setDisplayOptions('form', [
        'type' => 'boolean_checkbox',
        'weight' => 5,
        'settings' => [
          'display_label' => TRUE,
        ],
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['source'] = BaseFieldDefinition::create('list_string')
      ->setLabel(t('Source'))
      ->setDescription(t('How this subscriber was added.'))
      ->setSetting('allowed_values', [
        'user' => 'User subscription (authenticated)',
        'guest' => 'Guest subscription',
        'admin' => 'Admin added',
        'import' => 'Imported',
        'api' => 'API sync',
      ])
      ->setDefaultValue('admin')
      ->setDisplayOptions('view', [
        'label' => 'inline',
        'type' => 'list_default',
        'weight' => 10,
      ])
      ->setDisplayOptions('form', [
        'type' => 'options_select',
        'weight' => 10,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['peytz_id'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Peytz Subscriber ID'))
      ->setDescription(t('Remote subscriber ID from Peytz Mailer service.'))
      ->setSetting('max_length', 255)
      ->setReadOnly(TRUE)
      ->setDisplayOptions('view', [
        'label' => 'inline',
        'type' => 'string',
        'weight' => 15,
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['sync_state'] = BaseFieldDefinition::create('list_string')
      ->setLabel(t('Sync state'))
      ->setDescription(t('Synchronization state with Peytz Mailer.'))
      ->setSetting('allowed_values', [
        'new' => 'New (not synced)',
        'synced' => 'Synced',
        'pending' => 'Sync pending',
        'error' => 'Sync error',
      ])
      ->setDefaultValue('new')
      ->setDisplayOptions('view', [
        'label' => 'inline',
        'type' => 'list_default',
        'weight' => 18,
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['created'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Created'))
      ->setDescription(t('The time that the subscriber was created.'))
      ->setDisplayOptions('view', [
        'label' => 'inline',
        'type' => 'timestamp',
        'weight' => 20,
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Changed'))
      ->setDescription(t('The time that the subscriber was last edited.'))
      ->setDisplayOptions('view', [
        'label' => 'inline',
        'type' => 'timestamp',
        'weight' => 22,
      ])
      ->setDisplayConfigurable('view', TRUE);

    return $fields;
  }

}
