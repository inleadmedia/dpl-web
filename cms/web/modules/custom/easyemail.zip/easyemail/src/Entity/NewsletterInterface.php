<?php

namespace Drupal\easyemail\Entity;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Provides an interface for Newsletter entities.
 */
interface NewsletterInterface extends ContentEntityInterface, EntityChangedInterface, EntityOwnerInterface {

  /**
   * Gets the newsletter title.
   *
   * @return string
   *   The newsletter title.
   */
  public function getTitle();

  /**
   * Sets the newsletter title.
   *
   * @param string $title
   *   The newsletter title.
   *
   * @return \Drupal\easyemail\Entity\NewsletterInterface
   *   The newsletter entity.
   */
  public function setTitle($title);

  /**
   * Gets the newsletter state.
   *
   * @return string
   *   The state (new, draft, test, sent, abandoned).
   */
  public function getState();

  /**
   * Sets the newsletter state.
   *
   * @param string $state
   *   The state.
   *
   * @return \Drupal\easyemail\Entity\NewsletterInterface
   *   The newsletter entity.
   */
  public function setState($state);

  /**
   * Gets the Peytz remote newsletter ID.
   *
   * @return string|null
   *   The remote ID or NULL if not synced.
   */
  public function getPeytzId();

  /**
   * Sets the Peytz remote newsletter ID.
   *
   * @param string $peytz_id
   *   The remote ID.
   *
   * @return \Drupal\easyemail\Entity\NewsletterInterface
   *   The newsletter entity.
   */
  public function setPeytzId($peytz_id);

  /**
   * Gets the newsletter creation timestamp.
   *
   * @return int
   *   The creation timestamp.
   */
  public function getCreatedTime();

  /**
   * Sets the newsletter creation timestamp.
   *
   * @param int $timestamp
   *   The creation timestamp.
   *
   * @return \Drupal\easyemail\Entity\NewsletterInterface
   *   The newsletter entity.
   */
  public function setCreatedTime($timestamp);

  /**
   * Gets the scheduled send timestamp.
   *
   * @return int|null
   *   The scheduled send timestamp, or NULL if not set.
   */
  public function getScheduledSend();

  /**
   * Sets the scheduled send timestamp.
   *
   * @param int|null $timestamp
   *   The scheduled send timestamp, or NULL to clear.
   *
   * @return \Drupal\easyemail\Entity\NewsletterInterface
   *   The newsletter entity.
   */
  public function setScheduledSend($timestamp);

}
