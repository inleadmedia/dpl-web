<?php

namespace Drupal\easyemail\Entity;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;

/**
 * Provides an interface for Subscriber entities.
 */
interface SubscriberInterface extends ContentEntityInterface, EntityChangedInterface {

  /**
   * Gets the subscriber email address.
   *
   * @return string
   *   The email address.
   */
  public function getEmail();

  /**
   * Sets the subscriber email address.
   *
   * @param string $email
   *   The email address.
   *
   * @return \Drupal\easyemail\Entity\SubscriberInterface
   *   The subscriber entity.
   */
  public function setEmail($email);

  /**
   * Gets the subscriber status.
   *
   * @return bool
   *   TRUE if active, FALSE if inactive.
   */
  public function isActive();

  /**
   * Sets the subscriber status.
   *
   * @param bool $status
   *   TRUE for active, FALSE for inactive.
   *
   * @return \Drupal\easyemail\Entity\SubscriberInterface
   *   The subscriber entity.
   */
  public function setStatus($status);

  /**
   * Gets the subscriber source.
   *
   * @return string
   *   The source (user, guest, admin, import).
   */
  public function getSource();

  /**
   * Sets the subscriber source.
   *
   * @param string $source
   *   The source.
   *
   * @return \Drupal\easyemail\Entity\SubscriberInterface
   *   The subscriber entity.
   */
  public function setSource($source);

  /**
   * Gets the Peytz remote subscriber ID.
   *
   * @return string|null
   *   The remote ID or NULL if not synced.
   */
  public function getPeytzId();

  /**
   * Sets the Peytz remote subscriber ID.
   *
   * @param string $peytz_id
   *   The remote ID.
   *
   * @return \Drupal\easyemail\Entity\SubscriberInterface
   *   The subscriber entity.
   */
  public function setPeytzId($peytz_id);

  /**
   * Gets the subscriber creation timestamp.
   *
   * @return int
   *   The creation timestamp.
   */
  public function getCreatedTime();

  /**
   * Sets the subscriber creation timestamp.
   *
   * @param int $timestamp
   *   The creation timestamp.
   *
   * @return \Drupal\easyemail\Entity\SubscriberInterface
   *   The subscriber entity.
   */
  public function setCreatedTime($timestamp);

}
