<?php

namespace Drupal\easyemail;

use Drupal\Core\Access\CsrfTokenGenerator;
use Drupal\Core\Datetime\DateFormatterInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Form\FormBuilderInterface;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Defines a class to build a listing of Subscriber entities.
 */
class SubscriberListBuilder extends EntityListBuilder {

  /**
   * The request stack.
   *
   * @var \Symfony\Component\HttpFoundation\RequestStack
   */
  protected $requestStack;

  /**
   * The form builder.
   *
   * @var \Drupal\Core\Form\FormBuilderInterface
   */
  protected $formBuilder;

  /**
   * The date formatter service.
   *
   * @var \Drupal\Core\Datetime\DateFormatterInterface
   */
  protected $dateFormatter;

  /**
   * The CSRF token generator.
   *
   * @var \Drupal\Core\Access\CsrfTokenGenerator
   */
  protected $csrfToken;

  /**
   * Constructs a new SubscriberListBuilder object.
   *
   * @param \Drupal\Core\Entity\EntityTypeInterface $entity_type
   *   The entity type definition.
   * @param \Drupal\Core\Entity\EntityStorageInterface $storage
   *   The entity storage class.
   * @param \Symfony\Component\HttpFoundation\RequestStack $request_stack
   *   The request stack.
   * @param \Drupal\Core\Form\FormBuilderInterface $form_builder
   *   The form builder.
   * @param \Drupal\Core\Datetime\DateFormatterInterface $date_formatter
   *   The date formatter service.
   * @param \Drupal\Core\Access\CsrfTokenGenerator $csrf_token
   *   The CSRF token generator.
   */
  public function __construct(EntityTypeInterface $entity_type, EntityStorageInterface $storage, RequestStack $request_stack, FormBuilderInterface $form_builder, DateFormatterInterface $date_formatter, CsrfTokenGenerator $csrf_token) {
    parent::__construct($entity_type, $storage);
    $this->requestStack = $request_stack;
    $this->formBuilder = $form_builder;
    $this->dateFormatter = $date_formatter;
    $this->csrfToken = $csrf_token;
  }

  /**
   * {@inheritdoc}
   */
  public static function createInstance(ContainerInterface $container, EntityTypeInterface $entity_type) {
    return new static(
      $entity_type,
      $container->get('entity_type.manager')->getStorage($entity_type->id()),
      $container->get('request_stack'),
      $container->get('form_builder'),
      $container->get('date.formatter'),
      $container->get('csrf_token')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function load() {
    $entity_ids = $this->getEntityIds();
    return $this->storage->loadMultiple($entity_ids);
  }

  /**
   * {@inheritdoc}
   */
  protected function getEntityIds() {
    $query = $this->getStorage()->getQuery()
      ->accessCheck(TRUE)
      ->sort('created', 'DESC');

    $q = $this->requestStack->getCurrentRequest()->query;

    // Mailing list.
    $mailinglist = $q->get('mailinglist', 'all');
    if ($mailinglist && $mailinglist !== 'all') {
      $query->condition('subscriptions', $mailinglist);
    }

    // Active / inactive status.
    $status = $q->get('status', 'all');
    if ($status !== NULL && $status !== 'all') {
      $query->condition('status', (bool) $status);
    }

    // Source.
    $source = $q->get('source', 'all');
    if ($source && $source !== 'all') {
      $query->condition('source', $source);
    }

    // Sync state.
    $sync_state = $q->get('sync_state', 'all');
    if ($sync_state && $sync_state !== 'all') {
      $query->condition('sync_state', $sync_state);
    }

    // Email — partial, case-insensitive CONTAINS search.
    $email = trim((string) $q->get('email', ''));
    if ($email !== '') {
      $query->condition('email', '%' . $email . '%', 'LIKE');
    }

    // Created date range — convert YYYY-MM-DD strings to midnight timestamps.
    $created_min = trim((string) $q->get('created_min', ''));
    if ($created_min !== '') {
      $ts = strtotime($created_min);
      if ($ts !== FALSE) {
        $query->condition('created', $ts, '>=');
      }
    }

    $created_max = trim((string) $q->get('created_max', ''));
    if ($created_max !== '') {
      // Include the whole end day by adding one day minus one second.
      $ts = strtotime($created_max . ' +1 day') - 1;
      if ($ts !== FALSE) {
        $query->condition('created', $ts, '<=');
      }
    }

    if ($this->limit) {
      $query->pager($this->limit);
    }

    return $query->execute();
  }

  /**
   * {@inheritdoc}
   */
  public function render() {
    $build = parent::render();

    // Attach library for styling.
    $build['#attached']['library'][] = 'easyemail/admin';

    // Add filter form.
    $build['filters'] = [
      '#type' => 'container',
      '#weight' => -10,
      '#attributes' => ['class' => ['subscriber-filters']],
    ];

    $build['filters']['form'] = $this->formBuilder->getForm('Drupal\easyemail\Form\SubscriberFilterForm');

    // Add count of filtered results.
    $entities = $this->load();
    $total_count = count($entities);
    $build['filters']['count'] = [
      '#markup' => '<div class="subscriber-count">' . $this->formatPlural($total_count, '1 subscriber', '@count subscribers') . '</div>',
      '#weight' => 10,
    ];

    return $build;
  }

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['id'] = $this->t('ID');
    $header['email'] = $this->t('Email');
    $header['subscriptions'] = $this->t('Subscriptions');
    $header['status'] = $this->t('Status');
    $header['source'] = $this->t('Source');
    $header['peytz_id'] = $this->t('Remote ID');
    $header['sync_state'] = $this->t('Sync State');
    $header['created'] = $this->t('Created');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /** @var \Drupal\easyemail\Entity\SubscriberInterface $entity */
    $row['id'] = $entity->id();

    $row['email'] = Link::createFromRoute(
      $entity->getEmail(),
      'entity.easyemail_subscriber.edit_form',
      ['easyemail_subscriber' => $entity->id()]
    );

    // Subscriptions - show list names.
    $subscriptions = [];
    if (!$entity->get('subscriptions')->isEmpty()) {
      foreach ($entity->get('subscriptions') as $item) {
        if ($item->entity) {
          $subscriptions[] = $item->entity->label();
        }
      }
    }
    $row['subscriptions'] = $subscriptions ? implode(', ', $subscriptions) : $this->t('None');

    // Status with visual indicator.
    $row['status'] = $entity->isActive()
      ? $this->t('✓ Active')
      : $this->t('✗ Inactive');

    // Source.
    $source_labels = [
      'user' => $this->t('User'),
      'guest' => $this->t('Guest'),
      'admin' => $this->t('Admin'),
      'import' => $this->t('Import'),
      'api' => $this->t('API'),
    ];
    $source = $entity->getSource();
    $row['source'] = $source_labels[$source] ?? $source;

    // Peytz ID.
    $peytz_id = $entity->getPeytzId();
    $row['peytz_id'] = $peytz_id ?: $this->t('Not synced');

    // Sync state.
    $sync_state = $entity->get('sync_state')->value;
    $sync_labels = [
      'new' => $this->t('New'),
      'synced' => $this->t('✓ Synced'),
      'pending' => $this->t('⏳ Pending'),
      'error' => $this->t('❌ Error'),
    ];
    $row['sync_state'] = $sync_labels[$sync_state] ?? $sync_state;

    $row['created'] = $this->dateFormatter->format($entity->getCreatedTime(), 'short');

    return $row + parent::buildRow($entity);
  }

  /**
   * {@inheritdoc}
   */
  public function getDefaultOperations(EntityInterface $entity) {
    $operations = [];

    // Edit operation.
    if ($entity->access('update') && $entity->hasLinkTemplate('edit-form')) {
      $operations['edit'] = [
        'title' => $this->t('Edit'),
        'weight' => 10,
        'url' => $entity->toUrl('edit-form'),
      ];
    }

    // Delete operation.
    if ($entity->access('delete') && $entity->hasLinkTemplate('delete-form')) {
      $operations['delete'] = [
        'title' => $this->t('Delete'),
        'weight' => 100,
        'url' => $entity->toUrl('delete-form'),
      ];
    }

    // Sync operation.
    $syncUrl = Url::fromRoute('easyemail.subscriber.sync', ['easyemail_subscriber' => $entity->id()]);
    $syncUrl->setOption('query', ['token' => $this->csrfToken->get($syncUrl->getInternalPath())]);
    $operations['sync'] = [
      'title' => $this->t('Force sync'),
      'weight' => 50,
      'url' => $syncUrl,
    ];

    return $operations;
  }

}
