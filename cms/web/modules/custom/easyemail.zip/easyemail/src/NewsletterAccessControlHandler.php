<?php

namespace Drupal\easyemail;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Entity\EntityAccessControlHandler;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;

/**
 * Access controller for the Newsletter entity.
 */
class NewsletterAccessControlHandler extends EntityAccessControlHandler {

  /**
   * {@inheritdoc}
   */
  protected function checkAccess(EntityInterface $entity, $operation, AccountInterface $account) {
    /** @var \Drupal\easyemail\Entity\NewsletterInterface $entity */
    switch ($operation) {
      case 'view':
        return AccessResult::allowedIfHasPermission($account, 'manage newsletters');

      case 'update':
        // Check permission first.
        $permission_check = AccessResult::allowedIfHasPermission($account, 'manage newsletters');
        if (!$permission_check->isAllowed()) {
          return $permission_check;
        }

        // Check if state allows editing (matches D7 _easyemail_action_allowed).
        // Can't edit when operations are in progress or newsletter is archived.
        $locked_states = [
          'awaiting_test',
          'test_sent',
          'testing',
          'awaiting_sending',
          'cleared_for_takeoff',
          'preparing_data',
          'queueing',
          'waiting_for_workers',
          'paused',
          'sending',
          'archived',
        ];

        if (in_array($entity->getState(), $locked_states)) {
          return AccessResult::forbidden('Newsletter cannot be edited in current state: ' . $entity->getState())
            ->addCacheableDependency($entity);
        }

        return $permission_check->addCacheableDependency($entity);

      case 'delete':
        return AccessResult::allowedIfHasPermission($account, 'manage newsletters');
    }

    return AccessResult::neutral();
  }

  /**
   * {@inheritdoc}
   */
  protected function checkCreateAccess(AccountInterface $account, array $context, $entity_bundle = NULL) {
    return AccessResult::allowedIfHasPermission($account, 'manage newsletters');
  }

}
