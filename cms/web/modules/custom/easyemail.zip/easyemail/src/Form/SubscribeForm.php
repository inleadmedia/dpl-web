<?php

namespace Drupal\easyemail\Form;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\easyemail\Service\MailinglistManager;
use Drupal\easyemail\Service\OperationQueue;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a form for managing newsletter subscriptions.
 */
class SubscribeForm extends FormBase {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The operation queue service.
   *
   * @var \Drupal\easyemail\Service\OperationQueue
   */
  protected $operationQueue;

  /**
   * The mailing list manager.
   *
   * @var \Drupal\easyemail\Service\MailinglistManager
   */
  protected $mailinglistManager;

  /**
   * Constructs a SubscribeForm object.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\easyemail\Service\OperationQueue $operation_queue
   *   The operation queue.
   * @param \Drupal\easyemail\Service\MailinglistManager $mailinglist_manager
   *   The mailing list manager.
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager, OperationQueue $operation_queue, MailinglistManager $mailinglist_manager) {
    $this->entityTypeManager = $entity_type_manager;
    $this->operationQueue = $operation_queue;
    $this->mailinglistManager = $mailinglist_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager'),
      $container->get('easyemail.operation_queue'),
      $container->get('easyemail.mailinglist_manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'easyemail_subscribe_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $email = NULL, array $current_subscriptions = [], array $options = []) {
    // Store options for use in submit handler.
    $form_state->set('options', $options);

    // Email field - show only for guests.
    if (empty($email)) {
      $form['email'] = [
        '#type' => 'email',
        '#title' => $this->t('Email'),
        '#required' => TRUE,
      ];
    }
    else {
      $form['email'] = [
        '#type' => 'hidden',
        '#value' => $email,
      ];
    }

    // Mailing list checkboxes.
    $form['mailinglists'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Mailing lists'),
      '#options' => $options,
      '#default_value' => $current_subscriptions,
    ];

    $form['actions'] = [
      '#type' => 'actions',
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save'),
      '#attributes' => ['class' => ['btn-primary', 'btn-outline', 'btn-medium']],
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $email = $form_state->getValue('email');

    if (empty($email)) {
      $form_state->setErrorByName('email', $this->t('Email address is required.'));
    }
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $form_state->setErrorByName('email', $this->t('Please enter a valid email address.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $email = $form_state->getValue('email');
    $selected_tids = array_filter($form_state->getValue('mailinglists'));
    $options = $form_state->get('options');

    // Get mailing list IDs from metadata.
    $selected_ml_ids = [];
    $unselected_ml_ids = [];

    if (!empty($options)) {
      $all_tids = array_keys($options);
      $ml_data = $this->mailinglistManager->getRemoteIds($all_tids);

      foreach ($all_tids as $tid) {
        if (isset($ml_data[$tid])) {
          if (in_array($tid, $selected_tids)) {
            $selected_ml_ids[] = $ml_data[$tid];
          }
          else {
            $unselected_ml_ids[] = $ml_data[$tid];
          }
        }
      }
    }

    // Load or create subscriber entity.
    $subscriber_storage = $this->entityTypeManager->getStorage('easyemail_subscriber');
    $subscribers = $subscriber_storage->loadByProperties(['email' => $email]);

    if ($subscriber = reset($subscribers)) {
      // Update existing subscriber.
      $subscriber->set('subscriptions', $selected_tids);
      $subscriber->set('status', !empty($selected_tids));
      $subscriber->save();
    }
    else {
      // Create new subscriber.
      $subscriber = $subscriber_storage->create([
        'email' => $email,
        'subscriptions' => $selected_tids,
        'status' => !empty($selected_tids),
        'source' => $this->currentUser()->isAuthenticated() ? 'user' : 'guest',
      ]);
      $subscriber->save();
    }

    foreach ($selected_ml_ids as $ml_id) {
      $this->operationQueue->dispatch('subscribe', $subscriber->id(), [
        $ml_id,
        $email,
      ]);
    }

    foreach ($unselected_ml_ids as $ml_id) {
      $this->operationQueue->dispatch('unsubscribe', $subscriber->id(), [
        $ml_id,
        $email,
      ]);
    }

    $this->messenger()->addStatus($this->t('Your subscription preferences have been saved.'));
  }

}
