<?php

namespace Drupal\easyemail\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Configure template tokens for easyEmail.
 */
class TemplateTokensForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['easyemail.tokens'];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'easyemail_template_tokens_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('easyemail.tokens');

    $form['settings'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Template tokens'),
      '#description' => $this->t('These tokens can be used in email templates and will be replaced with the values below.'),
      '#collapsible' => FALSE,
    ];

    $form['settings']['library_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Library name'),
      '#description' => $this->t('Placeholder in template: {library-name}'),
      '#default_value' => $config->get('library_name'),
      '#required' => TRUE,
    ];

    $form['settings']['address'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Address'),
      '#description' => $this->t('Placeholder in template: {address}'),
      '#default_value' => $config->get('address'),
      '#required' => TRUE,
    ];

    $form['settings']['city'] = [
      '#type' => 'textfield',
      '#title' => $this->t('City'),
      '#description' => $this->t('Placeholder in template: {city}'),
      '#default_value' => $config->get('city'),
      '#required' => TRUE,
    ];

    $form['settings']['postal_code'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Postal code'),
      '#description' => $this->t('Placeholder in template: {postal-code}'),
      '#default_value' => $config->get('postal_code'),
    ];

    $form['settings']['phone'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Phone'),
      '#description' => $this->t('Placeholder in template: {phone}'),
      '#default_value' => $config->get('phone'),
      '#required' => TRUE,
    ];

    $form['settings']['email'] = [
      '#type' => 'email',
      '#title' => $this->t('Email'),
      '#description' => $this->t('Placeholder in template: {email}'),
      '#default_value' => $config->get('email'),
      '#required' => TRUE,
    ];

    $form['tokens_help'] = [
      '#type' => 'details',
      '#title' => $this->t('Available tokens'),
      '#open' => FALSE,
    ];

    $form['tokens_help']['list'] = [
      '#markup' => '<ul><li><code>{library-name}</code> - ' . $this->t('Library name') . '</li>' .
      '<li><code>{address}</code> - ' . $this->t('Address') . '</li>' .
      '<li><code>{city}</code> - ' . $this->t('City') . '</li>' .
      '<li><code>{postal-code}</code> - ' . $this->t('Postal code') . '</li>' .
      '<li><code>{phone}</code> - ' . $this->t('Phone') . '</li>' .
      '<li><code>{email}</code> - ' . $this->t('Email') . '</li>' .
      '<li><code>{unsubscribe-link}</code> - ' . $this->t('Unsubscribe link (auto-generated)') . '</li>' .
      '</ul>',
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('easyemail.tokens')
      ->set('library_name', $form_state->getValue('library_name'))
      ->set('address', $form_state->getValue('address'))
      ->set('city', $form_state->getValue('city'))
      ->set('postal_code', $form_state->getValue('postal_code'))
      ->set('phone', $form_state->getValue('phone'))
      ->set('email', $form_state->getValue('email'))
      ->save();

    parent::submitForm($form, $form_state);
  }

}
