<?php

namespace Drupal\easyemail\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Configure sender information for easyEmail.
 */
class SenderInfoForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['easyemail.sender'];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'easyemail_sender_info_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('easyemail.sender');

    $form['settings'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Sender info'),
      '#description' => $this->t('These settings will be used to identify email sender.'),
      '#collapsible' => FALSE,
    ];

    $form['settings']['from_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('From name'),
      '#description' => $this->t('Sender name that will appear in the email "From" field.'),
      '#default_value' => $config->get('from_name'),
      '#required' => TRUE,
    ];

    $form['settings']['from_email'] = [
      '#type' => 'textfield',
      '#title' => $this->t('From email'),
      '#description' => $this->t('Email address that will appear in the email "From" field.'),
      '#default_value' => $config->get('from_email'),
      '#required' => TRUE,
    ];

    $form['settings']['reply_to'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Reply to email'),
      '#description' => $this->t('Email address for replies. Leave empty to use the same as "From email".'),
      '#default_value' => $config->get('reply_to'),
    ];

    $form['notice'] = [
      '#markup' => '<div class="messages messages--warning">' .
      $this->t('Settings will take effect on newly created mailing lists.') .
      '</div>',
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    // Validate emails using PHP's filter_var which properly supports + and other valid characters.
    $from_email = $form_state->getValue('from_email');
    if ($from_email && !filter_var($from_email, FILTER_VALIDATE_EMAIL)) {
      $form_state->setErrorByName('from_email', $this->t('Please enter a valid email address.'));
    }

    $reply_to = $form_state->getValue('reply_to');
    if ($reply_to && !filter_var($reply_to, FILTER_VALIDATE_EMAIL)) {
      $form_state->setErrorByName('reply_to', $this->t('Please enter a valid email address.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('easyemail.sender')
      ->set('from_name', $form_state->getValue('from_name'))
      ->set('from_email', $form_state->getValue('from_email'))
      ->set('reply_to', $form_state->getValue('reply_to'))
      ->save();

    parent::submitForm($form, $form_state);
  }

}
