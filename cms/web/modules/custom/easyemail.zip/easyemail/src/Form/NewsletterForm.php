<?php

namespace Drupal\easyemail\Form;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Entity\ContentEntityForm;
use Drupal\Core\Form\FormStateInterface;

/**
 * Form controller for Newsletter entities.
 */
class NewsletterForm extends ContentEntityForm {

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildForm($form, $form_state);
    $form['#attached']['library'][] = 'easyemail/admin';
    $form['#attributes']['class'][] = 'easyemail-newsletter-form';

    /** @var \Drupal\easyemail\Entity\NewsletterInterface $entity */
    $entity = $this->entity;
    $state = $entity->getState();

    $form['newsletter_id_wrapper'] = [
      '#type' => 'details',
      '#title' => $this->t('Newsletter ID'),
      '#weight' => 100,
      '#open' => FALSE,
    ];

    $peytz_id = $entity->getPeytzId();
    $form['newsletter_id_wrapper']['newsletter_id'] = [
      '#type' => 'textfield',
      '#title' => $this->t('ID on the server'),
      '#description' => $this->t('Will be generated automatically after synchronisation with mailer service.'),
      '#default_value' => $peytz_id ?: '',
      '#attributes' => ['readonly' => 'readonly'],
    ];

    $form['state_info'] = [
      '#type' => 'item',
      '#title' => $this->t('Status'),
      '#markup' => $this->t('Current state: <strong>@state</strong>', [
        '@state' => $state,
      ]),
      '#weight' => 90,
    ];

    // Customise the scheduled_send widget that parent::buildForm() added via
    // the field's form display options. Move it into a collapsible details
    // wrapper and add context-sensitive help text.
    if (isset($form['scheduled_send'])) {
      $scheduled_send = $entity->isNew() ? NULL : $entity->getScheduledSend();

      if ($state === 'scheduled' && $scheduled_send) {
        $dt = DrupalDateTime::createFromTimestamp($scheduled_send);
        $description = $this->t('This newsletter is <strong>scheduled to send on @date</strong>. Saving any content changes will cancel the schedule and reset the newsletter to draft.', [
          '@date' => $dt->format('Y-m-d H:i'),
        ]);
      }
      else {
        $description = $this->t('Set a date and time to automatically send this newsletter. The schedule only takes effect after the newsletter has passed testing and you explicitly activate it using the <em>Schedule sendout</em> action.');
      }

      // Wrap in a collapsible details group.
      $widget = $form['scheduled_send'];
      $widget['#description'] = $description;
      $widget['#disabled'] = !easyemail_action_allowed('edit', $state);
      unset($form['scheduled_send']);

      $form['scheduled_send_wrapper'] = [
        '#type' => 'details',
        '#title' => $this->t('Scheduled sendout'),
        '#weight' => 92,
        '#open' => $scheduled_send !== NULL,
        'scheduled_send' => $widget,
      ];
    }

    // Disable title editing once a newsletter has been tested or sent.
    $locked_title_states = [
      'tested', 'scheduled', 'test_sent', 'testing',
      'awaiting_sending', 'cleared_for_takeoff', 'preparing_data',
      'queueing', 'waiting_for_workers', 'paused', 'sending',
      'archived', 'skipped', 'aborted',
    ];
    if (!$entity->isNew() && in_array($state, $locked_title_states)) {
      $form['title']['widget'][0]['value']['#disabled'] = TRUE;
      $form['title']['widget'][0]['value']['#description'] = $this->t('Title cannot be changed after newsletter has been tested or sent.');
    }

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {
    $entity = $this->entity;
    $status = parent::save($form, $form_state);

    switch ($status) {
      case SAVED_NEW:
        $this->messenger()->addStatus($this->t('Created newsletter %label.', [
          '%label' => $entity->label(),
        ]));
        break;

      default:
        $this->messenger()->addStatus($this->t('Updated newsletter %label.', [
          '%label' => $entity->label(),
        ]));
    }

    $form_state->setRedirect('entity.easyemail_newsletter.collection');
    return $status;
  }

}
