<?php

namespace Drupal\easyemail\Form;

use Drupal\Core\Url;
use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\easyemail\Service\SubscriberManager;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Form for adding subscribers manually from the admin UI.
 */
class SubscriberAddForm extends FormBase {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * The subscriber manager service.
   *
   * @var \Drupal\easyemail\Service\SubscriberManager
   */
  protected $subscriberManager;

  /**
   * Constructs a SubscriberAddForm object.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   * @param \Drupal\easyemail\Service\SubscriberManager $subscriber_manager
   *   The subscriber manager service.
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager, Connection $database, SubscriberManager $subscriber_manager) {
    $this->entityTypeManager = $entity_type_manager;
    $this->database = $database;
    $this->subscriberManager = $subscriber_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager'),
      $container->get('database'),
      $container->get('easyemail.subscriber_manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'easyemail_subscriber_add_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['email'] = [
      '#type' => 'email',
      '#title' => $this->t('Email Address'),
      '#description' => $this->t('Enter the subscriber email address.'),
      '#required' => TRUE,
    ];

    // Load synced mailing lists for options.
    $options = $this->getMailingListOptions();

    $form['mailing_lists'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Mailing Lists'),
      '#description' => $this->t('Select which mailing lists to subscribe this email to.'),
      '#options' => $options,
      '#required' => TRUE,
    ];

    if (empty($options)) {
      $form['mailing_lists']['#disabled'] = TRUE;
      $form['mailing_lists']['#description'] = $this->t('No synced mailing lists available.');
    }

    $form['actions'] = [
      '#type' => 'actions',
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Add Subscriber'),
    ];

    $form['actions']['cancel'] = [
      '#type' => 'link',
      '#title' => $this->t('Cancel'),
      '#url' => Url::fromRoute('easyemail.subscribers'),
      '#attributes' => ['class' => ['button']],
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    $email = $form_state->getValue('email');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $form_state->setErrorByName('email', $this->t('Please enter a valid email address.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $email = $form_state->getValue('email');
    $mailing_list_tids = array_filter($form_state->getValue('mailing_lists'));

    $imported = 0;
    $failed = 0;

    foreach ($mailing_list_tids as $tid) {
      $subscriber = $this->subscriberManager->subscribe($email, (int) $tid, 'admin');
      if ($subscriber) {
        $imported++;
      }
      else {
        $failed++;
      }
    }

    if ($imported > 0) {
      $this->messenger()->addStatus($this->t('Subscriber @email added to @count mailing list(s).', [
        '@email' => $email,
        '@count' => $imported,
      ]));
    }

    if ($failed > 0) {
      $this->messenger()->addWarning($this->t('@count mailing list(s) could not be subscribed (list may not be synced).', [
        '@count' => $failed,
      ]));
    }

    $form_state->setRedirect('easyemail.subscribers');
  }

  /**
   * Load synced mailing list options for the checkboxes element.
   *
   * @return array
   *   Associative array of tid => label for synced mailing lists.
   */
  protected function getMailingListOptions(): array {
    $term_storage = $this->entityTypeManager->getStorage('taxonomy_term');
    $tids = $term_storage->getQuery()
      ->condition('vid', 'mailinglist')
      ->accessCheck(FALSE)
      ->sort('name', 'ASC')
      ->execute();

    if (empty($tids)) {
      return [];
    }

    $synced_tids = $this->database->select('easyemail_mailinglists', 'm')
      ->fields('m', ['tid'])
      ->condition('tid', $tids, 'IN')
      ->condition('state', 1)
      ->execute()
      ->fetchCol();

    if (empty($synced_tids)) {
      return [];
    }

    $options = [];
    $terms = $term_storage->loadMultiple($synced_tids);
    foreach ($terms as $term) {
      $options[$term->id()] = $term->label();
    }

    return $options;
  }

}
