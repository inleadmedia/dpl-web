<?php

namespace Drupal\easyemail\Form;

use Drupal\Core\Entity\ContentEntityForm;
use Drupal\Core\Form\FormStateInterface;

/**
 * Form controller for Subscriber entities.
 */
class SubscriberForm extends ContentEntityForm {

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildForm($form, $form_state);

    /** @var \Drupal\easyemail\Entity\SubscriberInterface $entity */
    $entity = $this->entity;

    // Add remote ID fieldset (readonly, matches pattern from other entities).
    $form['subscriber_id_wrapper'] = [
      '#type' => 'details',
      '#title' => $this->t('Subscriber ID'),
      '#weight' => 100,
      '#open' => FALSE,
    ];

    $peytz_id = $entity->getPeytzId();
    $form['subscriber_id_wrapper']['subscriber_id'] = [
      '#type' => 'textfield',
      '#title' => $this->t('ID on the server'),
      '#description' => $this->t('Will be generated automatically after synchronisation with mailer service.'),
      '#default_value' => $peytz_id ?: '',
      '#attributes' => ['readonly' => 'readonly'],
    ];

    // Add sync state display.
    $sync_state = $entity->get('sync_state')->value;
    $sync_labels = [
      'new' => $this->t('New (not synced yet)'),
      'synced' => $this->t('Synced successfully'),
      'pending' => $this->t('Sync pending in queue'),
      'error' => $this->t('Sync error - check queue errors'),
    ];

    $form['sync_info'] = [
      '#type' => 'item',
      '#title' => $this->t('Sync Status'),
      '#markup' => $this->t('Current sync state: <strong>@state</strong>', [
        '@state' => $sync_labels[$sync_state] ?? $sync_state,
      ]),
      '#weight' => 90,
    ];

    // Disable email editing on existing subscribers (to prevent desync).
    if (!$entity->isNew() && $entity->getPeytzId()) {
      $form['email']['widget'][0]['value']['#disabled'] = TRUE;
      $form['email']['widget'][0]['value']['#description'] = $this->t('Email cannot be changed after synchronization. Delete and recreate if needed.');
    }

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    $entity = $this->entity;
    $email = $form_state->getValue('email')[0]['value'] ?? '';

    // Check for duplicate email (manual check since constraint might not work).
    if ($email && $entity->isNew()) {
      $existing = $this->entityTypeManager
        ->getStorage('easyemail_subscriber')
        ->loadByProperties(['email' => $email]);

      if ($existing) {
        $form_state->setErrorByName('email', $this->t('A subscriber with email @email already exists.', [
          '@email' => $email,
        ]));
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {
    $entity = $this->entity;
    $status = parent::save($form, $form_state);

    switch ($status) {
      case SAVED_NEW:
        $this->messenger()->addStatus($this->t('Created subscriber %label.', [
          '%label' => $entity->label(),
        ]));
        break;

      default:
        $this->messenger()->addStatus($this->t('Updated subscriber %label.', [
          '%label' => $entity->label(),
        ]));
    }

    $form_state->setRedirect('entity.easyemail_subscriber.collection');
    return $status;
  }

}
