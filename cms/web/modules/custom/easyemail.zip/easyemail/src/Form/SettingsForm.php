<?php

namespace Drupal\easyemail\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\TypedConfigManagerInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\easyemail\MailerProviderPluginManager;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Configure easyEmail settings.
 *
 * Provider-specific fields (API key, service URL, etc.) are rendered by each
 * plugin via MailerProviderInterface::buildSettingsForm(). The main form
 * handles only general/cross-provider settings (appearance, debug, cron, etc.)
 * and uses AJAX to swap the provider fieldset when the dropdown changes.
 */
class SettingsForm extends ConfigFormBase {

  /**
   * The mailer provider plugin manager.
   *
   * @var \Drupal\easyemail\MailerProviderPluginManager
   */
  protected $providerManager;

  /**
   * Constructs a SettingsForm object.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param \Drupal\Core\Config\TypedConfigManagerInterface $typed_config_manager
   *   The typed config manager.
   * @param \Drupal\easyemail\MailerProviderPluginManager $provider_manager
   *   The mailer provider plugin manager.
   */
  public function __construct(ConfigFactoryInterface $config_factory, TypedConfigManagerInterface $typed_config_manager, MailerProviderPluginManager $provider_manager) {
    parent::__construct($config_factory, $typed_config_manager);
    $this->providerManager = $provider_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('config.typed'),
      $container->get('plugin.manager.easyemail.mailer_provider')
    );
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['easyemail.settings', 'easyemail.sender'];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'easyemail_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('easyemail.settings');

    // Determine the active provider: prefer form state (AJAX rebuild) then config.
    $saved_provider = $config->get('mailer_provider') ?: 'peytz_mailer';
    $active_provider = $form_state->getValue('mailer_provider', $saved_provider);

    // Build provider options.
    $provider_options = [];
    foreach ($this->providerManager->getDefinitions() as $plugin_id => $definition) {
      $provider_options[$plugin_id] = $definition['label'];
    }

    $form['provider_wrapper'] = [
      '#type'   => 'fieldset',
      '#title'  => $this->t('Mailer provider'),
    ];

    $form['provider_wrapper']['mailer_provider'] = [
      '#type'          => 'select',
      '#title'         => $this->t('Provider'),
      '#description'   => $this->t('Select which email service provider to use for sending newsletters.'),
      '#options'       => $provider_options,
      '#default_value' => $active_provider,
      '#required'      => TRUE,
      '#ajax'          => [
        'callback'        => '::providerSettingsCallback',
        'wrapper'         => 'provider-settings-wrapper',
        'effect'          => 'fade',
      ],
    ];

    $form['provider_settings'] = [
      '#type'       => 'fieldset',
      '#title'      => $this->t('Provider settings'),
      '#prefix'     => '<div id="provider-settings-wrapper">',
      '#suffix'     => '</div>',
    ];

    try {
      $plugin = $this->providerManager->createInstance($active_provider, []);
      $form['provider_settings'] = $plugin->buildSettingsForm(
        $form['provider_settings'],
        $form_state
      );
      // Re-apply the wrapper and fieldset keys after plugin may have replaced them.
      $form['provider_settings']['#type']   = 'fieldset';
      $form['provider_settings']['#title']  = $this->t('Provider settings');
      $form['provider_settings']['#prefix'] = '<div id="provider-settings-wrapper">';
      $form['provider_settings']['#suffix'] = '</div>';
    }
    catch (\Exception $e) {
      $form['provider_settings']['error'] = [
        '#markup' => '<p class="messages messages--error">' . $this->t('Could not load provider settings: @msg', ['@msg' => $e->getMessage()]) . '</p>',
      ];
    }

    // ---- General settings (shared across all providers) ------------------- //
    $form['general'] = [
      '#type'  => 'fieldset',
      '#title' => $this->t('General settings'),
    ];

    $form['general']['newsletter_base_url'] = [
      '#type'        => 'textfield',
      '#title'       => $this->t('Newsletter base URL override'),
      '#description' => $this->t('Optional. Rewrites all absolute links in newsletter HTML to this base URL. Use in local/dev environments where the site is not publicly reachable. Leave empty on production.'),
      '#default_value' => $config->get('newsletter_base_url'),
      '#placeholder'   => 'https://staging.example.com',
    ];

    $form['general']['debug_enabled'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Debug mode'),
      '#description'   => $this->t('Log extended information for all API requests.'),
      '#default_value' => $config->get('debug_enabled'),
    ];

    $form['general']['instant_execution'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Instant API execution'),
      '#description'   => $this->t('When enabled, Test and Send actions call the API immediately. Disable on high-traffic sites to use cron-based queueing instead.'),
      '#default_value' => $config->get('instant_execution') ?? FALSE,
    ];

    // ---- Sender identity -------------------------------------------------- //
    $sender = $this->config('easyemail.sender');

    $form['sender'] = [
      '#type'        => 'fieldset',
      '#title'       => $this->t('Sender identity'),
      '#description' => $this->t('The "From" address used when sending newsletters. Must match a verified sender or domain in your email provider.'),
    ];

    $form['sender']['from_name'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Sender name'),
      '#description'   => $this->t('Displayed as the sender name in recipients\' email clients (e.g. <em>Inlead Newsletter</em>).'),
      '#default_value' => $sender->get('from_name'),
      '#required'      => TRUE,
      '#maxlength'     => 255,
    ];

    $form['sender']['from_email'] = [
      '#type'          => 'email',
      '#title'         => $this->t('Sender email'),
      '#description'   => $this->t('Must be verified with your email provider before newsletters can be sent.'),
      '#default_value' => $sender->get('from_email'),
      '#required'      => TRUE,
    ];

    $form['sender']['reply_to'] = [
      '#type'          => 'email',
      '#title'         => $this->t('Reply-to email'),
      '#description'   => $this->t('Optional. Defaults to the sender email if left blank.'),
      '#default_value' => $sender->get('reply_to'),
    ];

    // ---- Email appearance ------------------------------------------------- //
    $form['appearance'] = [
      '#type'  => 'fieldset',
      '#title' => $this->t('Email appearance'),
    ];

    $form['appearance']['primary_color'] = [
      '#type'          => 'color',
      '#title'         => $this->t('Primary colour'),
      '#description'   => $this->t('Header bar, section headings, and "Read more" buttons.'),
      '#default_value' => $config->get('primary_color') ?: '#005a87',
    ];

    $form['appearance']['text_color'] = [
      '#type'          => 'color',
      '#title'         => $this->t('Body text colour'),
      '#description'   => $this->t('Article titles, body text, and summaries.'),
      '#default_value' => $config->get('text_color') ?: '#333333',
    ];

    $form['appearance']['link_color'] = [
      '#type'          => 'color',
      '#title'         => $this->t('Link / accent colour'),
      '#description'   => $this->t('Event dates, "Read more" buttons in list items, and material links.'),
      '#default_value' => $config->get('link_color') ?: '#005a87',
    ];

    $form['appearance']['background_color'] = [
      '#type'          => 'color',
      '#title'         => $this->t('Content background colour'),
      '#description'   => $this->t('Background of the main content area.'),
      '#default_value' => $config->get('background_color') ?: '#ffffff',
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * AJAX callback — returns the provider-specific settings fieldset.
   */
  public function providerSettingsCallback(array &$form, FormStateInterface $form_state) {
    return $form['provider_settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    $provider_id = $form_state->getValue('mailer_provider');

    try {
      $plugin = $this->providerManager->createInstance($provider_id, []);
      $plugin->validateSettingsForm($form, $form_state);
    }
    catch (\Exception $e) {
      $form_state->setErrorByName('mailer_provider', $this->t('Provider error: @msg', ['@msg' => $e->getMessage()]));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $provider_id = $form_state->getValue('mailer_provider');

    // Save the selected provider.
    $this->config('easyemail.settings')
      ->set('mailer_provider', $provider_id)
      ->save();

    // Let the plugin persist its own settings.
    try {
      $plugin = $this->providerManager->createInstance($provider_id, []);
      $plugin->submitSettingsForm($form, $form_state);
    }
    catch (\Exception $e) {
      $this->messenger()->addError($this->t('Could not save provider settings: @msg', ['@msg' => $e->getMessage()]));
    }

    // Save sender identity.
    $this->config('easyemail.sender')
      ->set('from_name', $form_state->getValue('from_name'))
      ->set('from_email', $form_state->getValue('from_email'))
      ->set('reply_to', $form_state->getValue('reply_to') ?: $form_state->getValue('from_email'))
      ->save();

    // Save general / appearance settings.
    $this->config('easyemail.settings')
      ->set('newsletter_base_url', rtrim($form_state->getValue('newsletter_base_url') ?? '', '/'))
      ->set('debug_enabled', (bool) $form_state->getValue('debug_enabled'))
      ->set('instant_execution', (bool) $form_state->getValue('instant_execution'))
      ->set('primary_color', $form_state->getValue('primary_color') ?: '#005a87')
      ->set('text_color', $form_state->getValue('text_color') ?: '#333333')
      ->set('link_color', $form_state->getValue('link_color') ?: '#005a87')
      ->set('background_color', $form_state->getValue('background_color') ?: '#ffffff')
      ->save();

    parent::submitForm($form, $form_state);
  }

}
