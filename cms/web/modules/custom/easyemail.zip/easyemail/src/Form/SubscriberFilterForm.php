<?php

namespace Drupal\easyemail\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Provides a filter form for subscribers.
 */
class SubscriberFilterForm extends FormBase {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Constructs a new SubscriberFilterForm.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager) {
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'easyemail_subscriber_filter_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $q = $this->getRequest()->query;

    $current_mailinglist = $q->get('mailinglist', 'all');
    $current_status      = $q->get('status', 'all');
    $current_email       = $q->get('email', '');
    $current_source      = $q->get('source', 'all');
    $current_sync_state  = $q->get('sync_state', 'all');
    $current_created_min = $q->get('created_min', '');
    $current_created_max = $q->get('created_max', '');

    $form['#method'] = 'get';
    $form['#attributes']['class'][] = 'subscriber-filter-form';

    // ── Row 1: dropdowns ─────────────────────────────────────────────────────
    $form['row1'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['ekf-row']],
    ];

    $terms = $this->entityTypeManager
      ->getStorage('taxonomy_term')
      ->loadByProperties(['vid' => 'mailinglist']);

    $mailinglist_options = ['all' => $this->t('- All mailing lists -')];
    foreach ($terms as $term) {
      $mailinglist_options[$term->id()] = $term->label();
    }

    $form['row1']['mailinglist'] = [
      '#type' => 'select',
      '#title' => $this->t('Mailing list'),
      '#options' => $mailinglist_options,
      '#default_value' => $current_mailinglist,
    ];

    $form['row1']['status'] = [
      '#type' => 'select',
      '#title' => $this->t('Status'),
      '#options' => [
        'all' => $this->t('- All statuses -'),
        '1'   => $this->t('Active'),
        '0'   => $this->t('Inactive'),
      ],
      '#default_value' => $current_status,
    ];

    $form['row1']['source'] = [
      '#type' => 'select',
      '#title' => $this->t('Source'),
      '#options' => [
        'all'    => $this->t('- All sources -'),
        'user'   => $this->t('User'),
        'guest'  => $this->t('Guest'),
        'admin'  => $this->t('Admin'),
        'import' => $this->t('Import'),
        'api'    => $this->t('API'),
      ],
      '#default_value' => $current_source,
    ];

    $form['row1']['sync_state'] = [
      '#type' => 'select',
      '#title' => $this->t('Sync state'),
      '#options' => [
        'all'     => $this->t('- All sync states -'),
        'new'     => $this->t('New'),
        'pending' => $this->t('Pending'),
        'synced'  => $this->t('Synced'),
        'error'   => $this->t('Error'),
      ],
      '#default_value' => $current_sync_state,
    ];

    // ── Row 2: text / date inputs + submit button ─────────────────────────────
    $form['row2'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['ekf-row']],
    ];

    $form['row2']['email'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Email'),
      '#default_value' => $current_email,
      '#placeholder' => $this->t('Search by email…'),
      '#size' => 30,
      '#maxlength' => 254,
    ];

    $form['row2']['created_min'] = [
      '#type' => 'date',
      '#title' => $this->t('Created from'),
      '#default_value' => $current_created_min,
    ];

    $form['row2']['created_max'] = [
      '#type' => 'date',
      '#title' => $this->t('Created to'),
      '#default_value' => $current_created_max,
    ];

    // Actions sit in row 2 so the button aligns with the inputs.
    $form['row2']['actions'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['ekf-actions']],
    ];

    $form['row2']['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Filter'),
    ];

    $has_active_filter =
      $current_mailinglist !== 'all' ||
      $current_status !== 'all' ||
      $current_source !== 'all' ||
      $current_sync_state !== 'all' ||
      $current_email !== '' ||
      $current_created_min !== '' ||
      $current_created_max !== '';

    if ($has_active_filter) {
      $form['row2']['actions']['reset'] = [
        '#type' => 'link',
        '#title' => $this->t('Reset'),
        '#url' => Url::fromRoute('entity.easyemail_subscriber.collection'),
        '#attributes' => ['class' => ['button']],
      ];
    }

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // The form uses GET method; values are carried as query parameters.
  }

}
