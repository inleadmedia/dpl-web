<?php

namespace Drupal\easyemail\Service;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Lock\LockBackendInterface;
use Drupal\Component\Datetime\TimeInterface;

/**
 * Operation queue service for Peytz Mailer operations.
 *
 * Queues operations in the database for async processing via cron.
 */
class OperationQueue {

  /**
   * Queue status: New operation.
   */
  const STATUS_NEW = 0;

  /**
   * Queue status: Successfully processed.
   */
  const STATUS_PROCESSED = 1;

  /**
   * Queue status: Failed (any error — connection or API).
   *
   * Note: STATUS_FAILED_CONNECTION (2) is kept as an alias for backwards
   * compatibility with any existing queue rows, but all new failures are
   * written as STATUS_FAILED_ERROR.
   */
  const STATUS_FAILED_CONNECTION = 2;

  /**
   * Queue status: Failed (API error).
   */
  const STATUS_FAILED_ERROR = 3;

  /**
   * Queue status: Error resolved.
   */
  const STATUS_ERROR_RESOLVED = 4;

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * The mailer service.
   *
   * @var \Drupal\easyemail\Service\MailerService
   */
  protected $mailerService;

  /**
   * The lock service.
   *
   * @var \Drupal\Core\Lock\LockBackendInterface
   */
  protected $lock;

  /**
   * The module handler.
   *
   * @var \Drupal\Core\Extension\ModuleHandlerInterface
   */
  protected $moduleHandler;

  /**
   * The time service.
   *
   * @var \Drupal\Component\Datetime\TimeInterface
   */
  protected $time;

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * Constructs an OperationQueue object.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   * @param \Drupal\easyemail\Service\MailerService $mailer_service
   *   The mailer service.
   * @param \Drupal\Core\Lock\LockBackendInterface $lock
   *   The lock service.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler.
   * @param \Drupal\Component\Datetime\TimeInterface $time
   *   The time service.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   */
  public function __construct(
    Connection $database,
    MailerService $mailer_service,
    LockBackendInterface $lock,
    ModuleHandlerInterface $module_handler,
    TimeInterface $time,
    ConfigFactoryInterface $config_factory
  ) {
    $this->database = $database;
    $this->mailerService = $mailer_service;
    $this->lock = $lock;
    $this->moduleHandler = $module_handler;
    $this->time = $time;
    $this->configFactory = $config_factory;
  }

  /**
   * Whether operations should run instantly instead of via the cron queue.
   *
   * @return bool
   *   TRUE when instant execution is enabled in module settings.
   */
  public function isInstant(): bool {
    return (bool) $this->configFactory->get('easyemail.settings')->get('instant_execution');
  }

  /**
   * Dispatch an operation, honoring the instant_execution setting.
   *
   * Runs the operation immediately when instant execution is enabled,
   * otherwise enqueues it for the next cron run. This is the preferred entry
   * point for callers that do not need to branch on the execution mode.
   *
   * @param string $method
   *   The mailer method name to call.
   * @param int $entity_id
   *   The entity ID this operation relates to.
   * @param array $arguments
   *   Arguments to pass to the method.
   *
   * @return mixed
   *   The API response when run instantly, or the queue item ID when queued.
   *
   * @throws \InvalidArgumentException
   *   If the method does not exist on the mailer service.
   * @throws \Exception
   *   When run instantly and the API or connection fails.
   */
  public function dispatch(string $method, int $entity_id, array $arguments) {
    return $this->isInstant()
      ? $this->runNow($method, $entity_id, $arguments)
      : $this->put($method, $entity_id, $arguments);
  }

  /**
   * Execute an operation immediately, bypassing the database queue.
   *
   * Calls the mailer service method directly and fires the same
   * success / failure hooks as the cron-based processOperation() flow.
   * Throws on failure so the caller can surface the error to the user.
   *
   * @param string $method
   *   The mailer method name to call.
   * @param int $entity_id
   *   The entity ID this operation relates to.
   * @param array $arguments
   *   Arguments to pass to the method.
   *
   * @return mixed
   *   The API response on success.
   *
   * @throws \InvalidArgumentException
   *   If the method does not exist on the mailer service.
   * @throws \Exception
   *   On API or connection error, after invoking the failure hook.
   */
  public function runNow($method, $entity_id, array $arguments) {
    if (!method_exists($this->mailerService, $method)) {
      throw new \InvalidArgumentException("Unknown mailer method: {$method}");
    }

    try {
      $response = call_user_func_array([$this->mailerService, $method], $arguments);

      $hook = $this->hookName($method);
      $this->moduleHandler->invokeAll(
        "{$hook}_success",
        [$entity_id, $response]
      );

      return $response;
    }
    catch (\Exception $e) {
      $hook = $this->hookName($method);
      $this->moduleHandler->invokeAll(
        "{$hook}_failure",
        [$entity_id, $e->getMessage()]
      );

      throw $e;
    }
  }

  /**
   * Add an operation to the queue.
   *
   * @param string $method
   *   The mailer method name to call.
   * @param int $entity_id
   *   The entity ID this operation relates to.
   * @param array $arguments
   *   Arguments to pass to the method.
   *
   * @return int
   *   The queue item ID.
   *
   * @throws \InvalidArgumentException
   *   If the method doesn't exist.
   */
  public function put($method, $entity_id, array $arguments) {
    // Verify method exists on mailer service.
    if (!method_exists($this->mailerService, $method)) {
      throw new \InvalidArgumentException("Unknown mailer method: {$method}");
    }

    // Insert into queue.
    return $this->database->insert('easyemail_queue')
      ->fields([
        'entityId' => $entity_id,
        'method' => $method,
        'arguments' => serialize($arguments),
        'response' => '',
        'created' => $this->time->getRequestTime(),
        'status' => self::STATUS_NEW,
        'attempts' => 0,
        'error_message' => '',
      ])
      ->execute();
  }

  /**
   * Process all pending operations in the queue.
   *
   * @param int $limit
   *   Maximum number of items to process.
   *
   * @return array
   *   Array with 'processed' and 'failed' counts.
   */
  public function processAll($limit = 50) {
    // Acquire lock to prevent concurrent processing.
    $lock_name = 'easyemail_queue_processing';
    if (!$this->lock->acquire($lock_name, 300)) {
      return [
        'processed' => 0,
        'failed' => 0,
        'message' => 'Could not acquire lock',
      ];
    }

    $stats = ['processed' => 0, 'failed' => 0];

    try {
      // Get pending operations (new or previously failed with < 3 attempts).
      $operations = $this->database->select('easyemail_queue', 'q')
        ->fields('q')
        ->condition('status', [
          self::STATUS_NEW,
          self::STATUS_FAILED_CONNECTION,
          self::STATUS_FAILED_ERROR,
        ], 'IN')
        ->condition('attempts', 3, '<')
        ->orderBy('created', 'ASC')
        ->range(0, $limit)
        ->execute()
        ->fetchAll();

      foreach ($operations as $operation) {
        $success = $this->processOperation($operation);
        if ($success) {
          $stats['processed']++;
        }
        else {
          $stats['failed']++;
        }
      }
    }
    finally {
      $this->lock->release($lock_name);
    }

    return $stats;
  }

  /**
   * Build the base hook name for a mailer method.
   *
   * Converts the camelCase mailer method name (e.g. "createMailingList")
   * into a Drupal-style snake_case hook prefix (e.g.
   * "easyemail_create_mailing_list").
   *
   * @param string $method
   *   The mailer method name.
   *
   * @return string
   *   The base hook name, without the "_success" / "_failure" suffix.
   */
  protected function hookName($method) {
    $snake = strtolower(preg_replace('/(?<!^)[A-Z]/', '_$0', $method));
    return 'easyemail_' . $snake;
  }

  /**
   * Process a single operation.
   *
   * @param object $operation
   *   The operation database record.
   *
   * @return bool
   *   TRUE if successful, FALSE otherwise.
   */
  protected function processOperation($operation) {
    $method = $operation->method;
    $arguments = unserialize($operation->arguments, ['allowed_classes' => FALSE]);

    // Update processed timestamp and increment attempts.
    $this->database->update('easyemail_queue')
      ->fields([
        'processed' => $this->time->getRequestTime(),
        'attempts' => $operation->attempts + 1,
      ])
      ->condition('id', $operation->id)
      ->execute();

    try {
      // Call the mailer service method.
      $response = call_user_func_array([$this->mailerService, $method], $arguments);

      // Mark as processed.
      $this->database->update('easyemail_queue')
        ->fields([
          'status' => self::STATUS_PROCESSED,
          'response' => serialize($response),
          'error_message' => '',
        ])
        ->condition('id', $operation->id)
        ->execute();

      // Fire success hook.
      $hook = $this->hookName($method) . '_success';
      $this->moduleHandler->invokeAll($hook, [$operation->entityId, $response]);

      return TRUE;
    }
    catch (\Exception $e) {
      // Mark as failed.
      $this->database->update('easyemail_queue')
        ->fields([
          'status' => self::STATUS_FAILED_ERROR,
          'error_message' => $e->getMessage(),
        ])
        ->condition('id', $operation->id)
        ->execute();

      // Fire failure hook.
      $hook = $this->hookName($method) . '_failure';
      $this->moduleHandler->invokeAll($hook, [
        $operation->entityId,
        $e->getMessage(),
      ]);

      return FALSE;
    }
  }

  /**
   * Get queue statistics.
   *
   * @return array
   *   Array with status counts.
   */
  public function getStats() {
    $query = $this->database->select('easyemail_queue', 'q');
    $query->fields('q', ['status']);
    $query->addExpression('COUNT(*)', 'count');
    $query->groupBy('q.status');
    $result = $query->execute()->fetchAllKeyed(0, 1);

    $new = (int) ($result[self::STATUS_NEW] ?? 0);
    $processed = (int) ($result[self::STATUS_PROCESSED] ?? 0);
    $failed_connection = (int) ($result[self::STATUS_FAILED_CONNECTION] ?? 0);
    $failed_error = (int) ($result[self::STATUS_FAILED_ERROR] ?? 0);
    $error_resolved = (int) ($result[self::STATUS_ERROR_RESOLVED] ?? 0);

    return [
      'new' => $new,
      'processed' => $processed,
      'failed_connection' => $failed_connection,
      'failed_error' => $failed_error,
      'error_resolved' => $error_resolved,
      // Computed/aggregate values for display.
      'pending' => $new,
      'completed' => $processed,
      'failed' => $failed_connection + $failed_error,
      'total' => $new + $processed + $failed_connection + $failed_error + $error_resolved,
    ];
  }

  /**
   * Clear successfully processed operations older than specified time.
   *
   * @param int $age
   *   Age in seconds (default: 30 days).
   *
   * @return int
   *   Number of deleted records.
   */
  public function clearOld($age = 2592000) {
    $cutoff = $this->time->getRequestTime() - $age;

    return $this->database->delete('easyemail_queue')
      ->condition('status', self::STATUS_PROCESSED)
      ->condition('processed', $cutoff, '<')
      ->execute();
  }

}
