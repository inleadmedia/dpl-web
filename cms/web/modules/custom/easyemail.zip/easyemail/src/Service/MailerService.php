<?php

namespace Drupal\easyemail\Service;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\easyemail\MailerProviderPluginManager;

/**
 * Mailer service that delegates to the configured provider plugin.
 */
class MailerService {

  /**
   * The mailer provider plugin manager.
   *
   * @var \Drupal\easyemail\MailerProviderPluginManager
   */
  protected $pluginManager;

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The active mailer provider plugin instance.
   *
   * @var \Drupal\easyemail\Plugin\MailerProviderInterface
   */
  protected $provider;

  /**
   * Constructs a MailerService object.
   *
   * @param \Drupal\easyemail\MailerProviderPluginManager $plugin_manager
   *   The mailer provider plugin manager.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   */
  public function __construct(MailerProviderPluginManager $plugin_manager, ConfigFactoryInterface $config_factory) {
    $this->pluginManager = $plugin_manager;
    $this->configFactory = $config_factory;
  }

  /**
   * Get the active mailer provider plugin.
   *
   * @return \Drupal\easyemail\Plugin\MailerProviderInterface
   *   The active provider plugin instance.
   */
  protected function getProvider() {
    if (!isset($this->provider)) {
      $config = $this->configFactory->get('easyemail.settings');
      $provider_id = $config->get('mailer_provider') ?: 'peytz_mailer';

      $this->provider = $this->pluginManager->createInstance($provider_id);
    }

    return $this->provider;
  }

  /**
   * Get available mailer providers.
   *
   * @return array
   *   Array of provider definitions keyed by plugin ID.
   */
  public function getAvailableProviders() {
    return $this->pluginManager->getDefinitions();
  }

  /**
   * Check if API settings are valid.
   *
   * @param array $settings
   *   Optional settings to validate. If empty, uses current config.
   *   Expected keys: service_url, api_key.
   *
   * @return string|null
   *   Error message if validation fails, NULL on success.
   */
  public function checkSettings(array $settings = []) {
    return $this->getProvider()->checkSettings($settings);
  }

  /**
   * Create a mailing list on the remote service.
   *
   * @param array $data
   *   Mailing list data.
   *
   * @return array
   *   Response array.
   */
  public function createMailingList(array $data) {
    return $this->getProvider()->createMailingList($data);
  }

  /**
   * Add mailing lists to a user group (organizes by site_prefix).
   *
   * @param string $user_group
   *   The user group name (typically site_prefix).
   * @param array $mailinglist_ids
   *   Array of remote mailing list IDs.
   * @param bool $create_if_not_exists
   *   Whether to create the user group if it doesn't exist.
   *
   * @return array
   *   Response array.
   */
  public function addMailinglistsToUserGroup($user_group, array $mailinglist_ids, $create_if_not_exists = TRUE) {
    return $this->getProvider()->addMailinglistsToUserGroup($user_group, $mailinglist_ids, $create_if_not_exists);
  }

  /**
   * Subscribe an email to a mailing list.
   *
   * @param string $mailinglist_id
   *   The remote mailing list ID.
   * @param string $email
   *   The subscriber email.
   *
   * @return array
   *   Response array.
   */
  public function subscribe($mailinglist_id, $email) {
    return $this->getProvider()->subscribe($mailinglist_id, $email);
  }

  /**
   * Unsubscribe an email from a mailing list.
   *
   * @param string $mailinglist_id
   *   The remote mailing list ID.
   * @param string $email
   *   The subscriber email.
   *
   * @return array
   *   Response array.
   */
  public function unsubscribe($mailinglist_id, $email) {
    return $this->getProvider()->unsubscribe($mailinglist_id, $email);
  }

  /**
   * Create a newsletter on the remote service.
   *
   * @param string $mailinglist_id
   *   The remote mailing list ID.
   * @param array $data
   *   Newsletter data (title, subject, template).
   *
   * @return array
   *   Response array.
   */
  public function createNewsletter($mailinglist_id, array $data) {
    return $this->getProvider()->createNewsletter($mailinglist_id, $data);
  }

  /**
   * Update a newsletter on the remote service.
   *
   * @param string $mailinglist_id
   *   The remote mailing list ID.
   * @param string $newsletter_id
   *   The remote newsletter ID.
   * @param array $data
   *   Updated data.
   *
   * @return array
   *   Response array.
   */
  public function updateNewsletter($mailinglist_id, $newsletter_id, array $data) {
    return $this->getProvider()->updateNewsletter($mailinglist_id, $newsletter_id, $data);
  }

  /**
   * Send a test email for a newsletter.
   *
   * @param string $mailinglist_id
   *   The remote mailing list ID.
   * @param string $newsletter_id
   *   The remote newsletter ID.
   * @param string $test_email
   *   Test email address.
   *
   * @return array
   *   Response array.
   */
  public function testNewsletter($mailinglist_id, $newsletter_id, $test_email) {
    return $this->getProvider()->testNewsletter($mailinglist_id, $newsletter_id, $test_email);
  }

  /**
   * Send a newsletter to all subscribers.
   *
   * @param string $mailinglist_id
   *   The remote mailing list ID.
   * @param string $newsletter_id
   *   The remote newsletter ID.
   *
   * @return array
   *   Response array.
   */
  public function sendNewsletter($mailinglist_id, $newsletter_id) {
    return $this->getProvider()->sendNewsletter($mailinglist_id, $newsletter_id);
  }

}
