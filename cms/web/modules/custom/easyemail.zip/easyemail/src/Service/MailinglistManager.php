<?php

namespace Drupal\easyemail\Service;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\Url;
use Drupal\Component\Datetime\TimeInterface;
use Symfony\Component\HttpFoundation\RequestStack;
use Drupal\taxonomy\TermInterface;

/**
 * Service for managing mailing lists.
 */
class MailinglistManager {

  use StringTranslationTrait;

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The operation queue service.
   *
   * @var \Drupal\easyemail\Service\OperationQueue
   */
  protected $operationQueue;

  /**
   * The messenger service.
   *
   * @var \Drupal\Core\Messenger\MessengerInterface
   */
  protected $messenger;

  /**
   * The logger factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountProxyInterface
   */
  protected $currentUser;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The time service.
   *
   * @var \Drupal\Component\Datetime\TimeInterface
   */
  protected $time;

  /**
   * The request stack.
   *
   * @var \Symfony\Component\HttpFoundation\RequestStack
   */
  protected $requestStack;

  /**
   * Constructs a MailinglistManager object.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param \Drupal\easyemail\Service\OperationQueue $operation_queue
   *   The operation queue service.
   * @param \Drupal\Core\Messenger\MessengerInterface $messenger
   *   The messenger service.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger factory.
   * @param \Drupal\Core\Session\AccountProxyInterface $current_user
   *   The current user.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Component\Datetime\TimeInterface $time
   *   The time service.
   * @param \Symfony\Component\HttpFoundation\RequestStack $request_stack
   *   The request stack.
   */
  public function __construct(
    Connection $database,
    ConfigFactoryInterface $config_factory,
    OperationQueue $operation_queue,
    MessengerInterface $messenger,
    LoggerChannelFactoryInterface $logger_factory,
    AccountProxyInterface $current_user,
    EntityTypeManagerInterface $entity_type_manager,
    TimeInterface $time,
    RequestStack $request_stack
  ) {
    $this->database = $database;
    $this->configFactory = $config_factory;
    $this->operationQueue = $operation_queue;
    $this->messenger = $messenger;
    $this->loggerFactory = $logger_factory;
    $this->currentUser = $current_user;
    $this->entityTypeManager = $entity_type_manager;
    $this->time = $time;
    $this->requestStack = $request_stack;
  }

  /**
   * Load mailing list metadata for taxonomy terms.
   *
   * @param array $terms
   *   Array of taxonomy terms keyed by term ID.
   */
  public function loadMetadata(array $terms) {
    $tids = [];
    foreach ($terms as $term) {
      if ($term->bundle() === 'mailinglist') {
        $tids[] = $term->id();
      }
    }

    if (empty($tids)) {
      return;
    }

    // Load metadata from custom table.
    $result = $this->database->select('easyemail_mailinglists', 'm')
      ->fields('m')
      ->condition('tid', $tids, 'IN')
      ->execute();

    foreach ($result as $record) {
      // Attach metadata to term object.
      $terms[$record->tid]->mailinglist_id = $record->mailinglist_id;
      $terms[$record->tid]->mailinglist_sync = $record->state;
      $terms[$record->tid]->mailinglist_access_rules = unserialize($record->access_rules, ['allowed_classes' => FALSE]);
      $terms[$record->tid]->mailinglist_changed = $record->changed;
    }
  }

  /**
   * Get the remote (Peytz) mailing list ID for a synced taxonomy term.
   *
   * @param int $tid
   *   The mailing list taxonomy term ID.
   *
   * @return string|null
   *   The remote mailing list ID, or NULL when the list is not synced.
   */
  public function getRemoteId($tid): ?string {
    $remote_id = $this->database->select('easyemail_mailinglists', 'm')
      ->fields('m', ['mailinglist_id'])
      ->condition('tid', $tid)
      ->condition('state', 1)
      ->execute()
      ->fetchField();

    return $remote_id !== FALSE && $remote_id !== '' ? $remote_id : NULL;
  }

  /**
   * Get remote (Peytz) mailing list IDs for multiple synced terms.
   *
   * @param array $tids
   *   Mailing list taxonomy term IDs.
   *
   * @return array
   *   Remote mailing list IDs keyed by taxonomy term ID. Only synced lists
   *   with a non-empty remote ID are included.
   */
  public function getRemoteIds(array $tids): array {
    if (empty($tids)) {
      return [];
    }

    $result = $this->database->select('easyemail_mailinglists', 'm')
      ->fields('m', ['tid', 'mailinglist_id'])
      ->condition('tid', $tids, 'IN')
      ->condition('state', 1)
      ->execute();

    $map = [];
    foreach ($result as $row) {
      if (!empty($row->mailinglist_id)) {
        $map[$row->tid] = $row->mailinglist_id;
      }
    }

    return $map;
  }

  /**
   * Get subscribable mailing list options for the current user.
   *
   * Returns synced mailing lists the current user is allowed to subscribe to,
   * suitable for use as form #options.
   *
   * @param bool $access_check
   *   Whether to apply entity access checks when listing the terms.
   *
   * @return array
   *   Term labels keyed by taxonomy term ID, sorted by name.
   */
  public function getSubscribableOptions(bool $access_check = TRUE): array {
    $term_storage = $this->entityTypeManager->getStorage('taxonomy_term');
    $tids = $term_storage->getQuery()
      ->condition('vid', 'mailinglist')
      ->accessCheck($access_check)
      ->sort('name', 'ASC')
      ->execute();

    if (!$tids) {
      return [];
    }

    $synced = $this->getRemoteIds($tids);
    if (empty($synced)) {
      return [];
    }

    $options = [];
    $terms = $term_storage->loadMultiple(array_keys($synced));
    foreach ($terms as $tid => $term) {
      if ($this->canSubscribe($term)) {
        $options[$tid] = $term->label();
      }
    }

    return $options;
  }

  /**
   * Handle mailing list creation.
   *
   * @param \Drupal\taxonomy\TermInterface $term
   *   The taxonomy term.
   */
  public function onCreate(TermInterface $term) {
    if ($term->bundle() !== 'mailinglist') {
      return;
    }

    $config = $this->configFactory->get('easyemail.settings');
    $prefix = $config->get('site_prefix');

    // Warn when prefix is missing (it prefixes the remote name) but do not
    // block creation — an unnamed prefix just means the list name is used as-is.
    if (empty($prefix)) {
      $this->messenger->addWarning($this->t('Site prefix is not configured. The mailing list will be created without a prefix. Configure it at <a href="@url">settings</a>.', [
        '@url' => Url::fromRoute('easyemail.settings')->toString(),
      ]));
    }

    // Get access rules from term or use defaults.
    $access_rules = $term->easyemail_access_rules ?? $this->getDefaultPermissions();

    // Create metadata record for this mailing list.
    $this->database->insert('easyemail_mailinglists')
      ->fields([
        'tid' => $term->id(),
        'mailinglist_id' => '',
        'state' => 0,
        'access_rules' => serialize($access_rules),
        'changed' => $this->time->getRequestTime(),
      ])
      ->execute();

    // Build the custom unsubscribe URL template that Peytz injects into
    // {{unsubscribe_url}} per recipient. Peytz replaces {{subscriber.email}},
    // {{mailinglist.id}}, and {{checksum}} — the checksum is generated by
    // Peytz using the unsubscribe_checksum_secret we provide below.
    // Formula (verified against D7): sha256(rawurlencode(sorted_query_values)
    // + secret). Query params must be sorted alphabetically by key.
    // Sort order: cs < email < mailinglist_id — so values concatenated are
    // email_encoded + mailinglist_id_encoded + secret (cs is excluded).
    $request = $this->requestStack->getCurrentRequest();
    $base_url = $request ? rtrim($request->getSchemeAndHttpHost() . $request->getBasePath(), '/') : '';
    $unsubscribe_url = $base_url . '/easyemail/unsubscribe?email={{subscriber.email}}&mailinglist_id={{mailinglist.id}}&cs={{checksum}}';

    // Build mailing list configuration for Peytz API.
    $sender_config = $this->configFactory->get('easyemail.sender');
    $mailinglist = [
      'title' => $prefix ? $prefix . ' ' . $term->getName() : $term->getName(),
      'send_welcome_mail' => FALSE,
      'send_confirmation_mail' => FALSE,
      'default_template' => $this->configFactory->get('easyemail.settings')->get('peytz_template') ?: 'inlead',
      'description' => strip_tags($term->getDescription() ?? ''),
      'unsubscribe_settings_override' => TRUE,
      'enable_unsubscribe_custom_link' => TRUE,
      'unsubscribe_custom_link_url' => $unsubscribe_url,
      'unsubscribe_checksum_secret' => $config->get('shared_secret'),
    ];

    // Add sender info if configured.
    if ($from_name = $sender_config->get('from_name')) {
      $mailinglist['from_name'] = $from_name;
    }
    if ($from_email = $sender_config->get('from_email')) {
      $mailinglist['from_email'] = $from_email;
    }
    if ($reply_to = $sender_config->get('reply_to')) {
      $mailinglist['reply_to'] = $reply_to;
    }

    try {
      $this->operationQueue->dispatch('createMailingList', $term->id(), [$mailinglist]);
      $this->messenger->addStatus($this->operationQueue->isInstant()
        ? $this->t('Mailing list "@name" created on Peytz.', ['@name' => $term->getName()])
        : $this->t('Mailing list "@name" queued for creation on Peytz. It will be created during the next cron run.', ['@name' => $term->getName()])
      );
    }
    catch (\Exception $e) {
      $this->messenger->addError($this->t('Unable to create mailing list on Peytz: @error', [
        '@error' => $e->getMessage(),
      ]));
      $this->loggerFactory->get('easyemail')->error('Failed to create mailing list: @message', ['@message' => $e->getMessage()]);
    }
  }

  /**
   * Handle mailing list update.
   *
   * @param \Drupal\taxonomy\TermInterface $term
   *   The taxonomy term.
   */
  public function onUpdate(TermInterface $term) {
    if ($term->bundle() !== 'mailinglist') {
      return;
    }

    // Update changed timestamp.
    // Note: D7 does NOT sync updates to Peytz (name changes are disabled).
    $this->database->update('easyemail_mailinglists')
      ->fields([
        'changed' => $this->time->getRequestTime(),
      ])
      ->condition('tid', $term->id())
      ->execute();
  }

  /**
   * Handle mailing list deletion.
   *
   * @param \Drupal\taxonomy\TermInterface $term
   *   The taxonomy term.
   */
  public function onDelete(TermInterface $term) {
    if ($term->bundle() !== 'mailinglist') {
      return;
    }

    // Note: D7 does NOT queue deletion on Peytz (mailing lists remain on server).
    // This allows safe re-linking if term is recreated with same Peytz ID.
    // Delete local metadata.
    $this->database->delete('easyemail_mailinglists')
      ->condition('tid', $term->id())
      ->execute();

    // Mark all newsletters using this list as abandoned.
    try {
      $newsletter_storage = $this->entityTypeManager->getStorage('easyemail_newsletter');
      $newsletter_ids = $newsletter_storage->getQuery()
        ->accessCheck(FALSE)
        ->condition('mailinglist', $term->id())
        ->execute();

      foreach ($newsletter_ids as $newsletter_id) {
        $newsletter = $newsletter_storage->load($newsletter_id);
        if ($newsletter) {
          $newsletter->setState('abandoned');
          $newsletter->save();
        }
      }
    }
    catch (\Exception $e) {
      $this->loggerFactory->get('easyemail')->error('Failed to mark newsletters as abandoned: @message', ['@message' => $e->getMessage()]);
    }
  }

  /**
   * Update access rules for a mailing list.
   *
   * @param int $tid
   *   The taxonomy term ID.
   * @param array $access_rules
   *   Array of role IDs that can subscribe.
   */
  public function updateAccessRules($tid, array $access_rules) {
    $this->database->update('easyemail_mailinglists')
      ->fields([
        'access_rules' => serialize($access_rules),
        'changed' => $this->time->getRequestTime(),
      ])
      ->condition('tid', $tid)
      ->execute();
  }

  /**
   * Check if current user can subscribe to a mailing list.
   *
   * @param \Drupal\taxonomy\TermInterface $term
   *   The mailing list taxonomy term.
   *
   * @return bool
   *   TRUE if user can subscribe, FALSE otherwise.
   */
  public function canSubscribe(TermInterface $term) {
    $user_roles = $this->currentUser->getRoles();

    // Load mailing list metadata if not already loaded.
    if (!isset($term->mailinglist_access_rules)) {
      $metadata = $this->database->select('easyemail_mailinglists', 'm')
        ->fields('m', ['access_rules'])
        ->condition('tid', $term->id())
        ->execute()
        ->fetchField();

      if ($metadata) {
        $term->mailinglist_access_rules = unserialize($metadata, ['allowed_classes' => FALSE]);
      }
      else {
        // Default to authenticated users.
        $term->mailinglist_access_rules = $this->getDefaultPermissions();
      }
    }

    // Check if any of user's roles are in the access rules.
    return !empty(array_intersect($term->mailinglist_access_rules, $user_roles));
  }

  /**
   * Get default subscribe permissions (authenticated users).
   *
   * @return array
   *   Array of role IDs.
   */
  public function getDefaultPermissions() {
    return ['authenticated' => 'authenticated'];
  }

}
