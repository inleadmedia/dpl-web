<?php

namespace Drupal\easyemail\Service;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Url;

/**
 * Service for managing newsletter subscribers and synchronization.
 */
class SubscriberManager {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The operation queue service.
   *
   * @var \Drupal\easyemail\Service\OperationQueue
   */
  protected $operationQueue;

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The logger factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * The mailing list manager.
   *
   * @var \Drupal\easyemail\Service\MailinglistManager
   */
  protected $mailinglistManager;

  /**
   * Constructs a SubscriberManager service.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\easyemail\Service\OperationQueue $operation_queue
   *   The operation queue.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger factory.
   * @param \Drupal\easyemail\Service\MailinglistManager $mailinglist_manager
   *   The mailing list manager.
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager, OperationQueue $operation_queue, ConfigFactoryInterface $config_factory, LoggerChannelFactoryInterface $logger_factory, MailinglistManager $mailinglist_manager) {
    $this->entityTypeManager = $entity_type_manager;
    $this->operationQueue = $operation_queue;
    $this->configFactory = $config_factory;
    $this->loggerFactory = $logger_factory;
    $this->mailinglistManager = $mailinglist_manager;
  }

  /**
   * Subscribe an email to a mailing list.
   *
   * Creates subscriber entity and queues remote subscription.
   *
   * @param string $email
   *   The subscriber email address.
   * @param int $mailinglist_tid
   *   The mailing list taxonomy term ID.
   * @param string $source
   *   The subscription source (user/guest/admin/import).
   *
   * @return \Drupal\easyemail\Entity\SubscriberInterface|null
   *   The subscriber entity or NULL on failure.
   */
  public function subscribe($email, $mailinglist_tid, $source = 'user') {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $this->loggerFactory->get('easyemail')->error('Invalid email address: @email', ['@email' => $email]);
      return NULL;
    }

    // Verify the mailing list is synced with the remote service.
    if (!$this->mailinglistManager->getRemoteId($mailinglist_tid)) {
      $this->loggerFactory->get('easyemail')->error('Mailing list @tid not synced', ['@tid' => $mailinglist_tid]);
      return NULL;
    }

    // Do not call runNow()/put() here — entity hooks already queue the remote call.
    $subscriber_storage = $this->entityTypeManager->getStorage('easyemail_subscriber');
    $subscribers = $subscriber_storage->loadByProperties(['email' => $email]);

    if ($subscriber = reset($subscribers)) {
      $subscriptions = array_column($subscriber->get('subscriptions')->getValue(), 'target_id');
      if (!in_array($mailinglist_tid, $subscriptions)) {
        $subscriptions[] = $mailinglist_tid;
        $subscriber->set('subscriptions', $subscriptions);
        $subscriber->set('status', TRUE);
        $subscriber->save();
      }
    }
    else {
      $subscriber = $subscriber_storage->create([
        'email' => $email,
        'subscriptions' => [$mailinglist_tid],
        'status' => TRUE,
        'source' => $source,
        'sync_state' => 'pending',
      ]);
      $subscriber->save();
    }

    return $subscriber;
  }

  /**
   * Unsubscribe an email from a mailing list.
   *
   * Updates subscriber entity and queues remote unsubscription.
   *
   * @param string $email
   *   The subscriber email address.
   * @param int $mailinglist_tid
   *   The mailing list taxonomy term ID.
   *
   * @return bool
   *   TRUE if unsubscribed, FALSE otherwise.
   */
  public function unsubscribe($email, $mailinglist_tid) {
    // Verify the mailing list is synced with the remote service.
    if (!$this->mailinglistManager->getRemoteId($mailinglist_tid)) {
      return FALSE;
    }

    $subscriber_storage = $this->entityTypeManager->getStorage('easyemail_subscriber');
    $subscribers = $subscriber_storage->loadByProperties(['email' => $email]);

    if ($subscriber = reset($subscribers)) {
      // Do not call runNow()/put() here — entity hooks already queue the remote call.
      $subscriptions = array_column($subscriber->get('subscriptions')->getValue(), 'target_id');
      $subscriptions = array_diff($subscriptions, [$mailinglist_tid]);

      $subscriber->set('subscriptions', $subscriptions);
      $subscriber->set('status', !empty($subscriptions));
      $subscriber->save();
      return TRUE;
    }

    return FALSE;
  }

  /**
   * Bulk import subscribers to a mailing list.
   *
   * @param int $mailinglist_tid
   *   The mailing list taxonomy term ID.
   * @param array $emails
   *   Array of email addresses to import.
   * @param string $source
   *   The import source (default: 'import').
   *
   * @return array
   *   Array with 'imported' and 'failed' counts.
   */
  public function importBulk($mailinglist_tid, array $emails, $source = 'import') {
    $imported = 0;
    $failed = 0;

    foreach ($emails as $email) {
      $email = trim($email);
      if (empty($email)) {
        continue;
      }

      if ($this->subscribe($email, $mailinglist_tid, $source)) {
        $imported++;
      }
      else {
        $failed++;
      }
    }

    $this->loggerFactory->get('easyemail')->info(
      'Bulk import completed: @imported imported, @failed failed',
      ['@imported' => $imported, '@failed' => $failed]
    );

    return ['imported' => $imported, 'failed' => $failed];
  }

  /**
   * Sync subscribers from remote (Peytz) to local.
   *
   * @param int $mailinglist_tid
   *   The mailing list taxonomy term ID.
   *
   * @return int
   *   Number of subscribers synced.
   *
   * @todo Implement when Peytz provides subscriber list API endpoint.
   */
  public function syncFromRemote($mailinglist_tid) {
    // This would require a Peytz API method to fetch subscribers.
    // D7 used findSubscribers() method.
    // For now, log that this feature is not yet implemented.
    $this->loggerFactory->get('easyemail')->warning(
      'syncFromRemote not yet implemented for mailing list @tid',
      ['@tid' => $mailinglist_tid]
    );

    return 0;
  }

  /**
   * Sync subscribers to remote (Peytz).
   *
   * Queues subscribe operations for all local subscribers of a mailing list.
   *
   * @param int $mailinglist_tid
   *   The mailing list taxonomy term ID.
   *
   * @return int
   *   Number of subscribers queued for sync.
   */
  public function syncToRemote($mailinglist_tid) {
    // Get Peytz mailing list ID.
    $remote_id = $this->mailinglistManager->getRemoteId($mailinglist_tid);

    if (!$remote_id) {
      return 0;
    }

    // Find all subscribers for this mailing list.
    $subscriber_storage = $this->entityTypeManager->getStorage('easyemail_subscriber');
    $query = $subscriber_storage->getQuery()
      ->condition('subscriptions', $mailinglist_tid)
      ->condition('status', 1)
      ->accessCheck(FALSE);
    $ids = $query->execute();

    if (empty($ids)) {
      return 0;
    }

    $subscribers = $subscriber_storage->loadMultiple($ids);
    $count = 0;

    foreach ($subscribers as $subscriber) {
      $this->operationQueue->put('subscribe', $subscriber->id(), [
        $remote_id,
        $subscriber->getEmail(),
      ]);
      $count++;
    }

    $this->loggerFactory->get('easyemail')->info(
      'Queued @count subscribers for sync to mailing list @tid',
      ['@count' => $count, '@tid' => $mailinglist_tid]
    );

    return $count;
  }

  /**
   * Generate unsubscribe URL with checksum.
   *
   * @param string $email
   *   Subscriber email.
   * @param int $mailinglist_tid
   *   Mailing list taxonomy term ID.
   *
   * @return string
   *   The unsubscribe URL.
   */
  public function generateUnsubscribeUrl($email, $mailinglist_tid) {
    $config = $this->configFactory->get('easyemail.settings');
    $shared_secret = $config->get('shared_secret');

    if (empty($shared_secret)) {
      $shared_secret = bin2hex(random_bytes(32));
      $this->configFactory->getEditable('easyemail.settings')
        ->set('shared_secret', $shared_secret)
        ->save();
    }

    $checksum = hash('sha256', $email . $mailinglist_tid . $shared_secret);

    return Url::fromRoute('easyemail.unsubscribe', [
      'email' => $email,
      'mailinglist_tid' => $mailinglist_tid,
      'checksum' => $checksum,
    ], ['absolute' => TRUE])->toString();
  }

  /**
   * Verify unsubscribe checksum.
   *
   * @param string $email
   *   Subscriber email.
   * @param int $mailinglist_tid
   *   Mailing list taxonomy term ID.
   * @param string $checksum
   *   The provided checksum.
   *
   * @return bool
   *   TRUE if checksum is valid, FALSE otherwise.
   */
  public function verifyUnsubscribeChecksum($email, $mailinglist_tid, $checksum) {
    $config = $this->configFactory->get('easyemail.settings');
    $shared_secret = $config->get('shared_secret');

    if (empty($shared_secret)) {
      return FALSE;
    }

    $expected = hash('sha256', $email . $mailinglist_tid . $shared_secret);
    return hash_equals($expected, $checksum);
  }

}
