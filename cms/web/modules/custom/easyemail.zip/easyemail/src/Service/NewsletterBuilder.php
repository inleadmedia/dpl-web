<?php

namespace Drupal\easyemail\Service;

use Drupal\media\Entity\Media;
use Drupal\Component\Datetime\TimeInterface;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Datetime\DateFormatterInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\File\FileUrlGeneratorInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Render\RendererInterface;
use Drupal\Core\Theme\ThemeManagerInterface;
use Drupal\Core\Url;
use Drupal\dpl_fbi\Fbi;
use Drupal\easyemail\Entity\NewsletterInterface;
use Drupal\node\NodeInterface;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Service for building newsletter HTML using Twig templates.
 */
class NewsletterBuilder {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The renderer service.
   *
   * @var \Drupal\Core\Render\RendererInterface
   */
  protected $renderer;

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The theme manager.
   *
   * @var \Drupal\Core\Theme\ThemeManagerInterface
   */
  protected $themeManager;

  /**
   * The file URL generator.
   *
   * @var \Drupal\Core\File\FileUrlGeneratorInterface
   */
  protected $fileUrlGenerator;

  /**
   * The FBI service.
   *
   * @var \Drupal\dpl_fbi\Fbi|null
   */
  protected $fbiService;

  /**
   * The cache backend.
   *
   * @var \Drupal\Core\Cache\CacheBackendInterface
   */
  protected $cache;

  /**
   * The date formatter service.
   *
   * @var \Drupal\Core\Datetime\DateFormatterInterface
   */
  protected $dateFormatter;

  /**
   * The logger channel.
   *
   * @var \Drupal\Core\Logger\LoggerChannelInterface
   */
  protected $logger;

  /**
   * The request stack.
   *
   * @var \Symfony\Component\HttpFoundation\RequestStack
   */
  protected $requestStack;

  /**
   * The time service.
   *
   * @var \Drupal\Component\Datetime\TimeInterface
   */
  protected $time;

  /**
   * Constructs a NewsletterBuilder service.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Render\RendererInterface $renderer
   *   The renderer.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param \Drupal\Core\Theme\ThemeManagerInterface $theme_manager
   *   The theme manager.
   * @param \Drupal\Core\File\FileUrlGeneratorInterface $file_url_generator
   *   The file URL generator.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger factory.
   * @param \Drupal\Core\Datetime\DateFormatterInterface $date_formatter
   *   The date formatter.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache
   *   The cache backend.
   * @param \Symfony\Component\HttpFoundation\RequestStack $request_stack
   *   The request stack.
   * @param \Drupal\Component\Datetime\TimeInterface $time
   *   The time service.
   * @param \Drupal\dpl_fbi\Fbi|null $fbi_service
   *   The FBI service (optional, if dpl_fbi module is enabled).
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager, RendererInterface $renderer, ConfigFactoryInterface $config_factory, ThemeManagerInterface $theme_manager, FileUrlGeneratorInterface $file_url_generator, LoggerChannelFactoryInterface $logger_factory, DateFormatterInterface $date_formatter, CacheBackendInterface $cache, RequestStack $request_stack, TimeInterface $time, Fbi $fbi_service = NULL) {
    $this->entityTypeManager = $entity_type_manager;
    $this->renderer = $renderer;
    $this->configFactory = $config_factory;
    $this->themeManager = $theme_manager;
    $this->fileUrlGenerator = $file_url_generator;
    $this->logger = $logger_factory->get('easyemail');
    $this->dateFormatter = $date_formatter;
    $this->cache = $cache;
    $this->requestStack = $request_stack;
    $this->time = $time;
    $this->fbiService = $fbi_service;
  }

  /**
   * Build newsletter HTML using Twig templates.
   *
   * @param \Drupal\easyemail\Entity\NewsletterInterface $newsletter
   *   The newsletter entity.
   * @param string|null $subscriber_email
   *   Optional subscriber email for unsubscribe link generation.
   *
   * @return string
   *   The rendered HTML.
   */
  public function buildHtml(NewsletterInterface $newsletter, $subscriber_email = NULL) {
    $token_config = $this->configFactory->get('easyemail.tokens');
    $tokens = [
      'library_name' => $token_config->get('library_name') ?? '',
      'address' => $token_config->get('address') ?? '',
      'city' => $token_config->get('city') ?? '',
      'postal_code' => $token_config->get('postal_code') ?? '',
      'phone' => $token_config->get('phone') ?? '',
      'email' => $token_config->get('email') ?? '',
    ];

    // Peytz injects a per-subscriber unsubscribe URL at send time via the
    // {{unsubscribe_url}} merge tag. SendGrid manages unsubscribes itself
    // through the suppression group, so we omit our footer button for it.
    $unsubscribe_url = NULL;
    $active_provider = $this->configFactory->get('easyemail.settings')->get('mailer_provider');
    $is_peytz = ($active_provider === 'peytz_mailer' || empty($active_provider));
    if ($is_peytz && $newsletter->hasField('mailinglist') && $newsletter->get('mailinglist')->entity) {
      $unsubscribe_url = '{{unsubscribe_url}}';
    }

    $appearance       = $this->configFactory->get('easyemail.settings');
    $primary_color    = $appearance->get('primary_color') ?: '#005a87';
    $text_color       = $appearance->get('text_color') ?: '#333333';
    $link_color       = $appearance->get('link_color') ?: '#005a87';
    $background_color = $appearance->get('background_color') ?: '#ffffff';

    $site_config = $this->configFactory->get('system.site');
    $theme_config = $this->configFactory->get('system.theme');
    $default_theme = $theme_config->get('default');
    $logo_url = theme_get_setting('logo.url', $default_theme);

    // Convert logo to absolute URL for email compatibility.
    if ($logo_url && strpos($logo_url, 'http') !== 0) {
      $logo_url = Url::fromUri('base:' . ltrim($logo_url, '/'), ['absolute' => TRUE])->toString();
    }

    $header_render = [
      '#theme'         => 'easyemail_newsletter_header',
      '#site_logo'     => $logo_url,
      '#site_name'     => $site_config->get('name') ?? 'Site',
      '#primary_color' => $primary_color,
      '#text_color'    => $text_color,
    ];

    $sections = $this->buildSections($newsletter, $text_color, $link_color);

    $body_html = '';
    if (!$newsletter->get('body')->isEmpty()) {
      $body_value = $newsletter->get('body')->value;
      $body_format = $newsletter->get('body')->format ?? 'basic_html';
      $body_html = check_markup($body_value, $body_format);
    }

    $header_image_url = NULL;
    if (!$newsletter->get('header_image')->isEmpty()) {
      $image = $newsletter->get('header_image')->entity;
      if ($image) {
        $header_image_url = $this->fileUrlGenerator->generateAbsoluteString($image->getFileUri());
      }
    }

    $body_render = [
      '#theme'            => 'easyemail_newsletter_body',
      '#newsletter'       => [
        'title'            => $newsletter->getTitle(),
        'body'             => $body_html,
        'header_image_url' => $header_image_url,
      ],
      '#sections'         => $sections,
      '#unsubscribe_url'  => $unsubscribe_url,
      '#primary_color'    => $primary_color,
      '#text_color'       => $text_color,
      '#link_color'       => $link_color,
      '#background_color' => $background_color,
    ];

    $footer_render = [
      '#theme'           => 'easyemail_newsletter_footer',
      '#tokens'          => $tokens,
      '#unsubscribe_url' => $unsubscribe_url,
    ];

    $header_html = $this->renderer->renderPlain($header_render);
    $body_html = $this->renderer->renderPlain($body_render);
    $footer_html = $this->renderer->renderPlain($footer_render);

    $newsletter_render = [
      '#theme' => 'easyemail_newsletter',
      '#newsletter' => [
        'title' => $newsletter->getTitle(),
      ],
      '#header' => $header_html,
      '#body' => $body_html,
      '#footer' => $footer_html,
      '#tokens' => $tokens,
      '#unsubscribe_url' => $unsubscribe_url,
    ];

    $html = (string) $this->renderer->renderPlain($newsletter_render);

    // Strip HTML comments (Twig debug comments, IE conditionals, etc.) so that
    // Peytz receives clean HTML regardless of the local Twig debug setting.
    $html = preg_replace('/<!--.*?-->/s', '', $html);

    // If a newsletter_base_url override is configured, rewrite all absolute
    // links from the current site URL to the override URL. This is needed in
    // local/dev environments (e.g. ddev) where the site is not publicly
    // reachable — Peytz validates and rewrites links for click-tracking and
    // will refuse to send emails that contain unreachable URLs.
    $override_base = $this->configFactory->get('easyemail.settings')->get('newsletter_base_url');
    if (!empty($override_base)) {
      $request = $this->requestStack->getCurrentRequest();
      $current_base = $request ? rtrim($request->getSchemeAndHttpHost(), '/') : '';
      $html = str_replace($current_base, rtrim($override_base, '/'), $html);
      $this->logger->info('NewsletterBuilder: replaced base URL @from → @to in newsletter HTML', [
        '@from' => $current_base,
        '@to' => $override_base,
      ]);
    }

    return $html;
  }

  /**
   * Build sections from the newsletter's paragraph-based components field.
   *
   * Iterates newsletter_section paragraphs; within each section iterates
   * newsletter_text / newsletter_article / newsletter_event /
   * newsletter_material components.
   *
   * @return array
   *   Array of sections: [['heading' => string|null, 'description' => string|null, 'layout' => string, 'items' => [...]], ...]
   */
  protected function buildSections(NewsletterInterface $newsletter, string $text_color = '#333333', string $link_color = '#005a87') {
    $sections = [];

    if (!$newsletter->hasField('components') || $newsletter->get('components')->isEmpty()) {
      return $sections;
    }

    foreach ($newsletter->get('components') as $section_ref) {
      $section = $section_ref->entity;
      if (!$section || $section->bundle() !== 'newsletter_section') {
        continue;
      }

      $section_title = $section->hasField('field_nl_title') && !$section->get('field_nl_title')->isEmpty()
        ? $section->get('field_nl_title')->value
        : NULL;

      $section_description = NULL;
      if ($section->hasField('field_nl_description') && !$section->get('field_nl_description')->isEmpty()) {
        $desc = $section->get('field_nl_description')->first();
        $section_description = check_markup($desc->value, $desc->format ?? 'basic_html');
      }

      // Ordered slots: each entry is either a 'list' slot (text/article/event)
      // or a 'grid' slot (materials). We flush accumulated items into a slot
      // whenever the component type changes, preserving the editor-defined order.
      $ordered_slots = [];
      $current_list  = [];
      $current_grid  = [];

      $flush_list = function () use (&$current_list, &$ordered_slots) {
        if (!empty($current_list)) {
          $ordered_slots[] = ['type' => 'list', 'items' => $current_list];
          $current_list = [];
        }
      };
      $flush_grid = function () use (&$current_grid, &$ordered_slots) {
        if (!empty($current_grid)) {
          $ordered_slots[] = ['type' => 'grid', 'items' => $current_grid];
          $current_grid = [];
        }
      };

      if ($section->hasField('field_nl_components') && !$section->get('field_nl_components')->isEmpty()) {
        foreach ($section->get('field_nl_components') as $component_ref) {
          $component = $component_ref->entity;
          if (!$component) {
            continue;
          }

          switch ($component->bundle()) {

            case 'newsletter_text':
              $flush_grid();
              if (!$component->get('field_nl_text')->isEmpty()) {
                $text_field = $component->get('field_nl_text')->first();
                $html = (string) check_markup($text_field->value, $text_field->format ?? 'basic_html');
                $row = '<tr><td width="30"><br /></td><td style="padding: 15px 0; font-family: Helvetica, Arial, sans-serif; font-size: 15px; line-height: 22px; color: ' . htmlspecialchars($text_color) . ';">' . $html . '</td><td width="30"><br /></td></tr>';
                $current_list[] = ['label' => NULL, 'html' => $row];
              }
              break;

            case 'newsletter_article':
              $flush_grid();
              if (!$component->get('field_nl_article')->isEmpty()) {
                $node = $component->get('field_nl_article')->entity;
                if ($node) {
                  $current_list[] = [
                    'label' => (string) t('Article'),
                    'html' => $this->renderNodeItem($node, $text_color, $link_color),
                  ];
                }
              }
              break;

            case 'newsletter_event':
              $flush_grid();
              if (!$component->get('field_nl_event')->isEmpty()) {
                $event = $component->get('field_nl_event')->entity;
                if ($event) {
                  $current_list[] = [
                    'label' => (string) t('Event'),
                    'html' => $this->renderEventItem($event, $text_color, $link_color),
                  ];
                }
              }
              break;

            case 'newsletter_material':
              $flush_list();
              if ($component->hasField('field_nl_material') && !$component->get('field_nl_material')->isEmpty()) {
                foreach ($component->get('field_nl_material') as $work_id_item) {
                  $data = $this->fetchMaterialData($work_id_item->value ?? '');
                  if ($data) {
                    $current_grid[] = $data;
                  }
                }
              }
              break;
          }
        }
      }

      $flush_list();
      $flush_grid();

      // Heading and description attach only to the first slot so they are not repeated.
      $heading_used = FALSE;

      foreach ($ordered_slots as $slot) {
        $heading      = $heading_used ? NULL : $section_title;
        $description  = $heading_used ? NULL : $section_description;
        $heading_used = TRUE;

        if ($slot['type'] === 'list') {
          $sections[] = [
            'heading'     => $heading,
            'description' => $description,
            'layout'      => 'list',
            'items'       => $slot['items'],
          ];
        }
        else {
          $sections[] = [
            'heading'     => $heading,
            'description' => $description,
            'type_label'  => (string) t('Materials'),
            'layout'      => 'grid',
            'columns'     => 2,
            'items'       => $slot['items'],
          ];
        }
      }
    }

    return $sections;
  }

  /**
   * Render a node as a newsletter item render array.
   */
  protected function renderNodeItem($node, string $text_color, string $link_color): string {
    $render = [
      '#theme'      => 'easyemail_newsletter_item',
      '#node'       => [
        'label'     => $node->label(),
        'url'       => $node->toUrl('canonical', ['absolute' => TRUE])->toString(),
        'image_url' => $this->getNodeImageUrl($node),
        'summary'   => $this->getNodeSummary($node),
        'date'      => $this->getNodeDate($node),
      ],
      '#text_color' => $text_color,
      '#link_color' => $link_color,
    ];
    return (string) $this->renderer->renderPlain($render);
  }

  /**
   * Render an event instance as a newsletter item render array.
   */
  protected function renderEventItem($event, string $text_color, string $link_color): string {
    $render = [
      '#theme'      => 'easyemail_newsletter_item',
      '#node'       => [
        'label'     => $event->label(),
        'url'       => $event->toUrl('canonical', ['absolute' => TRUE])->toString(),
        'image_url' => $this->getEventImageUrl($event),
        'summary'   => $this->getEventSummary($event),
        'date'      => $this->getEventDate($event),
      ],
      '#text_color' => $text_color,
      '#link_color' => $link_color,
    ];
    return (string) $this->renderer->renderPlain($render);
  }

  /**
   * Fetch material data for a Work ID, with caching and retry.
   */
  protected function fetchMaterialData(string $work_id): ?array {
    if (empty($work_id) || !$this->fbiService) {
      return NULL;
    }

    $cid = 'easyemail:material:' . $work_id;
    $cached = $this->cache->get($cid);
    if ($cached) {
      return $cached->data;
    }

    $material_url = Url::fromRoute('dpl_react_apps.work', ['wid' => $work_id], ['absolute' => TRUE])->toString();
    $last_exception = NULL;

    for ($attempt = 1; $attempt <= 3; $attempt++) {
      try {
        $title      = $this->fbiService->getWorkTitle($work_id);
        $cover_info = $this->fbiService->getWorkCoverInfo($work_id);
        $data       = [
          'label'     => !empty($title) ? $title : (string) t('Material: @id', ['@id' => $work_id]),
          'url'       => $material_url,
          'image_url' => $cover_info ? $cover_info->url : NULL,
        ];
        $this->cache->set($cid, $data, $this->time->getRequestTime() + 86400);
        return $data;
      }
      catch (\Exception $e) {
        $last_exception = $e;
        if ($attempt < 3) {
          usleep(500000);
        }
      }
    }

    $this->logger->error('Failed to fetch material @id after 3 attempts: @error', [
      '@id'    => $work_id,
      '@error' => $last_exception?->getMessage(),
    ]);
    return [
      'label' => (string) t('Material: @id', ['@id' => $work_id]),
      'url' => $material_url,
      'image_url' => NULL,
    ];
  }

  /**
   * Get the teaser image URL for a node.
   *
   * Node image fields may reference either a File entity or a Media entity.
   * When the referenced entity is a Media entity the underlying File must be
   * resolved through the media's own image/file field before the URI can be
   * generated.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node entity.
   *
   * @return string|null
   *   Absolute image URL or NULL.
   */
  protected function getNodeImageUrl(NodeInterface $node) {
    $image_fields = [
      'field_teaser_image',
      'field_ding_news_list_image',
      'field_list_image',
    ];
    foreach ($image_fields as $field_name) {
      if (!$node->hasField($field_name) || $node->get($field_name)->isEmpty()) {
        continue;
      }
      $entity = $node->get($field_name)->entity;
      if (!$entity) {
        continue;
      }

      // Media entity — resolve to the underlying File first.
      if ($entity instanceof Media) {
        $file = $this->getFileFromMedia($entity);
        if ($file) {
          return $this->fileUrlGenerator->generateAbsoluteString($file->getFileUri());
        }
        continue;
      }

      // Direct File entity reference.
      if (method_exists($entity, 'getFileUri')) {
        return $this->fileUrlGenerator->generateAbsoluteString($entity->getFileUri());
      }
    }
    return NULL;
  }

  /**
   * Extract the File entity from a Media entity.
   *
   * Checks the most common media image/file field names in order.
   *
   * @param \Drupal\media\Entity\Media $media
   *   The media entity.
   *
   * @return \Drupal\file\Entity\File|null
   *   The file entity or NULL if not found.
   */
  protected function getFileFromMedia(Media $media) {
    foreach (['field_media_image', 'field_media_file', 'thumbnail'] as $field) {
      if ($media->hasField($field) && !$media->get($field)->isEmpty()) {
        $file = $media->get($field)->entity;
        if ($file && method_exists($file, 'getFileUri')) {
          return $file;
        }
      }
    }
    return NULL;
  }

  /**
   * Get a short summary/teaser text for a node.
   *
   * Checks fields in order of preference: field_teaser_text, field_subtitle,
   * then falls back to the body field summary or trimmed body value.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node entity.
   *
   * @return string
   *   Plain-text summary, HTML-escaped and newline-converted.
   */
  protected function getNodeSummary(NodeInterface $node) {
    $text = '';

    // Preferred: dedicated teaser/subtitle fields.
    foreach (['field_teaser_text', 'field_subtitle'] as $field_name) {
      if ($node->hasField($field_name) && !$node->get($field_name)->isEmpty()) {
        $text = (string) $node->get($field_name)->value;
        break;
      }
    }

    // Fall back to plain body field.
    if (empty($text) && $node->hasField('body') && !$node->get('body')->isEmpty()) {
      $body = $node->get('body')->first();
      $text = $body->summary ?: strip_tags($body->value);
    }

    // Last resort: extract text from the first paragraph with field_body/field_text.
    if (empty($text)) {
      foreach (['field_paragraphs', 'field_content'] as $para_field) {
        if (!$node->hasField($para_field) || $node->get($para_field)->isEmpty()) {
          continue;
        }
        foreach ($node->get($para_field) as $para_ref) {
          $para = $para_ref->entity;
          if (!$para) {
            continue;
          }
          $body_fields = [
            'field_body',
            'field_text',
            'field_lead',
            'field_description',
          ];
          foreach ($body_fields as $tf) {
            if ($para->hasField($tf) && !$para->get($tf)->isEmpty()) {
              $text = strip_tags((string) $para->get($tf)->value);
              break 3;
            }
          }
        }
      }
    }

    if (empty($text)) {
      return '';
    }

    if (strlen($text) > 300) {
      $text = substr($text, 0, 297) . '...';
    }

    return nl2br(htmlspecialchars($text));
  }

  /**
   * Get a formatted event date string for a node.
   *
   * Checks common date field names used by event content types. Returns NULL
   * when no recognised date field is found, so non-event items are unaffected.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node entity.
   *
   * @return string|null
   *   Formatted date string (e.g. "Monday, 23. April 2026, 14:00") or NULL.
   */
  protected function getNodeDate(NodeInterface $node) {
    $date_fields = [
      'field_start_date',
      'field_event_date',
      'field_date',
      'field_ding_event_date',
    ];

    foreach ($date_fields as $field_name) {
      if (!$node->hasField($field_name) || $node->get($field_name)->isEmpty()) {
        continue;
      }

      $field_item = $node->get($field_name)->first();
      $value = $field_item->value ?? NULL;
      if (empty($value)) {
        continue;
      }

      try {
        $timestamp = (new \DateTime($value, new \DateTimeZone('UTC')))->getTimestamp();
        return $this->dateFormatter->format($timestamp, 'custom', 'l, j. F Y, H:i');
      }
      catch (\Exception $e) {
        // Unparseable value — skip this field.
        continue;
      }
    }

    return NULL;
  }

  /**
   * Get the teaser image URL for an eventinstance entity.
   *
   * @param \Drupal\Core\Entity\EntityInterface $event
   *   The event instance entity.
   *
   * @return string|null
   *   Absolute image URL or NULL.
   */
  protected function getEventImageUrl(EntityInterface $event) {
    $image_fields = [
      'field_teaser_image',
      'event_teaser_image',
      'field_event_image',
      'event_image',
    ];
    foreach ($image_fields as $field_name) {
      if (!$event->hasField($field_name) || $event->get($field_name)->isEmpty()) {
        continue;
      }
      $entity = $event->get($field_name)->entity;
      if (!$entity) {
        continue;
      }

      if ($entity instanceof Media) {
        $file = $this->getFileFromMedia($entity);
        if ($file) {
          return $this->fileUrlGenerator->generateAbsoluteString($file->getFileUri());
        }
        continue;
      }

      if (method_exists($entity, 'getFileUri')) {
        return $this->fileUrlGenerator->generateAbsoluteString($entity->getFileUri());
      }
    }

    return NULL;
  }

  /**
   * Get a short summary/teaser text for an eventinstance entity.
   *
   * @param \Drupal\Core\Entity\EntityInterface $event
   *   The event instance entity.
   *
   * @return string
   *   Plain-text summary, HTML-escaped and newline-converted.
   */
  protected function getEventSummary(EntityInterface $event) {
    $text = '';

    $summary_fields = [
      'field_teaser_text',
      'event_teaser_text',
      'field_description',
      'event_description',
    ];
    foreach ($summary_fields as $field_name) {
      if ($event->hasField($field_name) && !$event->get($field_name)->isEmpty()) {
        $text = (string) $event->get($field_name)->value;
        break;
      }
    }

    if (empty($text) && $event->hasField('body') && !$event->get('body')->isEmpty()) {
      $text = strip_tags((string) $event->get('body')->value);
    }

    if (empty($text)) {
      return '';
    }

    if (strlen($text) > 300) {
      $text = substr($text, 0, 297) . '...';
    }

    return nl2br(htmlspecialchars($text));
  }

  /**
   * Get a formatted date string from an eventinstance entity.
   *
   * Reads the base 'date' daterange field (start value). Returns NULL when no
   * date is set. Omits the time portion when the event is marked as all-day.
   *
   * @param \Drupal\Core\Entity\EntityInterface $event
   *   The event instance entity.
   *
   * @return string|null
   *   Formatted date string or NULL.
   */
  protected function getEventDate(EntityInterface $event) {
    if ($event->get('date')->isEmpty()) {
      return NULL;
    }

    $date_item = $event->get('date')->first();
    $start_value = $date_item->value ?? NULL;

    if (empty($start_value)) {
      return NULL;
    }

    $all_day = FALSE;
    foreach (['field_event_all_day', 'event_all_day'] as $field_name) {
      if ($event->hasField($field_name) && !$event->get($field_name)->isEmpty()) {
        $all_day = (bool) $event->get($field_name)->value;
        break;
      }
    }

    try {
      $timestamp = (new \DateTime($start_value, new \DateTimeZone('UTC')))->getTimestamp();
      $format = $all_day ? 'l, j. F Y' : 'l, j. F Y, H:i';
      return $this->dateFormatter->format($timestamp, 'custom', $format);
    }
    catch (\Exception $e) {
      return NULL;
    }
  }

}
