# easyEmail

Newsletter management for Drupal 10/11. Editors compose newsletters in the CMS, subscribers are stored locally, and outbound mail goes through an external provider (Peytz Mailer by default, with SendGrid and a dummy provider for testing).

The module keeps its own newsletter and subscriber entities, syncs mailing lists and subscriptions to the remote service via a database queue, and renders HTML mail from Twig templates.

## Requirements

- Drupal 10 or 11
- Paragraphs, Entity Reference Revisions, Taxonomy, Node, Image, Text, Options, Views
- For material search in newsletter paragraphs: `dpl_fbi` and the DPL React material-search app (optional, only if you use the newsletter material paragraph type)

## Installation

```bash
drush en easyemail -y
drush cr
```

Optional paragraph and field config ships in `config/optional/` and is imported when dependencies are present.

Grant permissions under **People → Permissions**:

- **Manage newsletters** — mailing lists, newsletters, subscribers, settings
- **Send newsletter** — preview, test, send, schedule

Admin UI: `/admin/easyemail`

## Configuration

**Settings** tab at `/admin/easyemail/settings` (also reachable from the easyEmail admin local tasks)

- Choose a mailer provider (Peytz, SendGrid, or Dummy)
- Provider-specific API credentials and options
- Site prefix (used when grouping mailing lists on Peytz)
- Appearance colours for rendered mail
- Instant execution vs queue (whether API calls run immediately or via cron)
- Debug logging

**Sender info** and **Template tokens** (library name, address, phone, etc.) have their own config forms under the same menu.

Cron must run regularly when queue mode is enabled. `hook_cron()` processes the operation queue and dispatches scheduled newsletters whose send time has passed.

## Main concepts

### Mailing lists

Mailing lists are taxonomy terms in the `mailinglist` vocabulary. Each term has extra metadata in `easyemail_mailinglists` (remote ID, sync state, access rules, suppression group for SendGrid). Creating a term queues a remote `createMailingList` call.

Access rules on a list control which roles may subscribe.

### Newsletters

Custom entity `easyemail_newsletter`. Content is built from paragraph sections (text, articles, events, materials, etc.) plus optional body, header image, and footer fields.

Typical flow:

1. Create newsletter and assign a mailing list → queued create on remote → state becomes `draft`
2. Preview locally, then **Test** → sends a test mail to the current user's email
3. After a successful test (`tested`), **Send** or **Schedule sendout**
4. Editing content after testing resets the newsletter to `draft` and requires testing again

Common states: `draft`, `awaiting_test`, `tested`, `test_failed`, `scheduled`, `awaiting_sending`, `sending`, `archived`, `failed`. While a test or send is in progress, editing is blocked. Content changes after a successful test always reset to `draft` so mail is never sent untested.

### Subscribers

Custom entity `easyemail_subscriber` with email, status, subscriptions (entity references to mailing list terms), sync state, and optional remote subscriber ID.

Saving a subscriber queues subscribe/unsubscribe operations for added or removed lists. Do not call the queue directly from form code — entity hooks handle that.

### Operation queue

Pending API work is stored in `easyemail_queue`. Each row has a method name (e.g. `subscribe`, `createNewsletter`), entity ID, serialized arguments, status, and attempt count.

Success and failure invoke hooks named `easyemail_{operation}_success` and `easyemail_{operation}_failure` (operation name converted to snake_case). Implementations live in `easyemail.module`.

Failed operations can be reviewed at `/admin/easyemail/syncerrors`.

## Mailer providers

Providers implement `MailerProviderInterface` and are selected in settings. `MailerService` delegates to the active plugin; `OperationQueue` calls the same methods asynchronously.

| Plugin ID       | Purpose                          |
|-----------------|----------------------------------|
| `peytz_mailer`  | Peytz Mailer REST API (default)  |
| `sendgrid`      | SendGrid Marketing API           |
| `dummy`         | Logs only, no external calls     |

Add a new provider by creating a class in `src/Plugin/MailerProvider/` with a `@MailerProvider` annotation. Implement `buildSettingsForm()` for any config fields the provider needs.

## Public-facing pieces

- **Subscribe block** — authenticated users manage list subscriptions
- **Guest subscription block** — anonymous subscription (where configured)
- **Unsubscribe** — tokenised URL per mailing list (`/easyemail/unsubscribe/...`)

Place blocks via the block layout UI.

## Rendering

`NewsletterBuilder` assembles header, body sections, and footer into HTML using theme hooks `easyemail_newsletter`, `easyemail_newsletter_header`, `easyemail_newsletter_body`, and `easyemail_newsletter_footer`.

Preview in admin: `/admin/easyemail/newsletter/{id}/preview`

A clean preview without admin chrome exists at `/easyemail/newsletter/{id}/preview` (same permission).

## Services

| Service                         | Role                                      |
|---------------------------------|-------------------------------------------|
| `easyemail.mailer`              | Facade over mailer provider plugins       |
| `easyemail.operation_queue`     | Queue dispatch and cron processing        |
| `easyemail.newsletter_builder`  | HTML rendering                            |
| `easyemail.mailinglist_manager` | Mailing list metadata and access checks   |
| `easyemail.subscriber_manager`  | Subscribe/unsubscribe helpers             |

## Project layout

```
src/
  Controller/     Admin actions (preview, test, send, unsubscribe, sync errors)
  Entity/         Newsletter and Subscriber entities
  Form/           Settings, newsletter/subscriber forms, subscription UI
  Plugin/         Mailer providers and subscription blocks
  Service/        Queue, builder, managers
templates/        Twig email templates
config/           Install and optional field/paragraph config
```

## Logging

Watch the `easyemail` log channel. Enable debug mode in settings for API request/response detail from Peytz and SendGrid plugins.
