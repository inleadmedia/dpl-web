/**
 * @file
 * Admin UI JavaScript for easyEmail.
 */

(function ($, Drupal) {
  'use strict';

  Drupal.behaviors.easyemail = {
    attach: function (context, settings) {
    }
  };

})(jQuery, Drupal);
