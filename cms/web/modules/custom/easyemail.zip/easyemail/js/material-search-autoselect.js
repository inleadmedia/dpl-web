/**
 * @file
 * Auto-select the only result in the newsletter material picker.
 */

(function (Drupal, once) {
  'use strict';

  function setupAutoSelect(app) {
    var lastSelectedLabel = null;
    var clicking = false;

    function tryAutoSelect() {
      if (clicking) {
        return;
      }

      var list = app.querySelector('.material-search-list__results');
      if (!list) {
        lastSelectedLabel = null;
        return;
      }

      if (list.querySelector('.material-search-list__loading')) {
        return;
      }

      var buttons = list.querySelectorAll('.material-search-list__button');
      if (buttons.length !== 1) {
        lastSelectedLabel = null;
        return;
      }

      // Require counter === 1 so paginated result sets are not auto-selected.
      var counter = app.querySelector('.material-search-list__header span');
      if (counter && counter.textContent.trim() !== '1') {
        return;
      }

      var button = buttons[0];
      var label = button.getAttribute('aria-label') || '';
      if (label === lastSelectedLabel) {
        return;
      }

      lastSelectedLabel = label;
      clicking = true;
      button.click();
      window.setTimeout(function () {
        clicking = false;
      }, 0);
    }

    var observer = new MutationObserver(tryAutoSelect);
    observer.observe(app, { childList: true, subtree: true });
    tryAutoSelect();
  }

  Drupal.behaviors.easyemailMaterialAutoselect = {
    attach: function (context) {
      once(
        'easyemail-material-autoselect',
        '[data-dpl-app="material-search"]',
        context
      ).forEach(setupAutoSelect);
    }
  };

})(Drupal, once);
